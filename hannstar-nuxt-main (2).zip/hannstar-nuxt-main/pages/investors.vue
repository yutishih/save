<template>
    <div>
        <NuxtPage :page-key="route => route.fullPath"></NuxtPage>
    </div>
</template>
<style lang="scss">
</style>
