<script setup>
const { data } = useSitemap();
const { t } = useI18n();
const { report2022Data, reportHistoryData } = useReport2022Data();

//meta data
useMeta({ title: t("esg-menu06") });
</script>

<template>
  <div class="sustainability-report">
    <div>
      <Breadcrumbs
        :level-second="{ text: data[2].mainMenu, link: data[2].mainMenuLink }"
        :level-third="{
          text: data[2].subMenu[5].text,
          link: data[2].subMenu[5].link,
        }"
      ></Breadcrumbs>
    </div>

    <div class="sustainability-report-container">
      <div class="title">
        <h1>{{ t("sustainability-report-mail-title") }}</h1>
      </div>
      <table>
        <tr>
          <th>{{ t("sustainability-report-table01-head01") }}</th>
          <th>{{ t("sustainability-report-table01-head02") }}</th>
        </tr>
        <tr v-for="(item, index) in report2022Data" :key="index">
          <td>{{ item.title }}</td>
          <td>
            <a
              v-if="item.downloadLink && item.downloadLink !== ''"
              :href="item.downloadLink"
              target="_blank"
            >
              <img
                src="https://media.hannstar.com/Image/hannstar/download-PDF.png"
                alt=""
              />
            </a>
          </td>
        </tr>
      </table>

      <table>
        <tr>
          <th>{{ t("sustainability-report-table02-head01") }}</th>
          <th>{{ t("sustainability-report-table02-head02") }}</th>
        </tr>
        <tr v-for="(item, index) in reportHistoryData" :key="index">
          <td>{{ item.title }}</td>
          <td>
            <a
              v-if="item.downloadLink && item.downloadLink !== ''"
              :href="item.downloadLink"
              target="_blank"
            >
              <img
                src="https://media.hannstar.com/Image/hannstar/download-PDF.png"
                alt=""
              />
            </a>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-report {
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
  }
  table {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto;

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      min-height: 30px;

      img {
        display: block;
        margin: 0 auto;
        max-width: 35px;
      }
    }
  }
}
</style>
