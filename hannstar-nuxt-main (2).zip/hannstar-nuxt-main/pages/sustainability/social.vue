<script setup>
import { ref } from "vue";
import { useRoute, useRouter } from "vue-router";

const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("esg-menu05") });

const tabItems = [
  {
    text: t("sustainability-social-tab01"),
    queryTab: "Equality",
  },
  {
    text: t("sustainability-social-tab02"),
    queryTab: "Talents",
  },
  {
    text: t("sustainability-social-tab03"),
    queryTab: "Profession",
  },
  {
    text: t("sustainability-social-tab04"),
    queryTab: "Society",
  },
  {
    text: t("sustainability-social-tab05"),
    queryTab: "Foundation",
  },
  {
    text: t("sustainability-social-tab06"),
    queryTab: "RBA",
  },
  {
    text: t("sustainability-social-tab07"),
    queryTab: "Labor",
  },
  {
    text: t("sustainability-social-tab08"),
    queryTab: "EnvironmentSecurity",
  },
];

// const tabChoose = ref(0);
// 根據tab自動跳轉
// onMounted(() => {
//   const urlParams = new URLSearchParams(window.location.search);
//   const tabParam = urlParams.get("esgTab");
//   if (tabParam) {
//     const tabIndex = tabItems.findIndex((item) => item.queryTab === tabParam);
//     if (tabIndex !== -1) {
//       tabChoose.value = tabIndex;
//     }
//   }
// });

// const getTabChooseIndex = (index) => {
//   tabChoose.value = index;
// };

const router = useRouter();
const route = useRoute();

// 獲取 URL 查詢參數中的 Tab 值
const getInitialTab = () => {
  const tabParam = route.query.Tab;
  if (tabParam) {
    const tabIndex = tabItems.findIndex((item) => item.queryTab === tabParam);
    return tabIndex !== -1 ? tabIndex : 0;
  }
  return 0;
};

// 在創建時設定初始 Tab
const tabChoose = ref(getInitialTab());

const updateQueryParam = (index) => {
  const selectedTab = tabItems[index].queryTab;
  router.push({ query: { Tab: selectedTab } });
};

const getTabChooseIndex = (i) => {
  tabChoose.value = parseInt(i);
  updateQueryParam(tabChoose.value);
};
</script>

<template>
  <div class="sustainability-social esg-page-container">
    <div class="sustainability-social-container">
      <TopBanner
        :img-link="'https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/topbanner2.png'"
        :banner-title="t('sustainability-social-top-banner-text01')"
        :banner-text="t('sustainability-social-top-banner-text02')"
        :banner-height-max="400"
        class="text-align-left"
      ></TopBanner>

      <Breadcrumbs
        :level-second="{ text: data[2].mainMenu, link: data[2].mainMenuLink }"
        :level-third="{
          text: data[2].subMenu[4].text,
          link: data[2].subMenu[4].link,
        }"
        :level-forth="tabItems[tabChoose].text"
      ></Breadcrumbs>
      <TabEsg
        :tab-navigation="tabItems"
        @update:tab-choose="getTabChooseIndex"
      ></TabEsg>
    </div>

    <div class="sustainability-tab-content">
      <SustainabilitySocialTab01
        v-if="tabChoose === 0"
      ></SustainabilitySocialTab01>
      <SustainabilitySocialTab02
        v-if="tabChoose === 1"
      ></SustainabilitySocialTab02>
      <SustainabilitySocialTab03
        v-if="tabChoose === 2"
      ></SustainabilitySocialTab03>
      <SustainabilitySocialTab04
        v-if="tabChoose === 3"
      ></SustainabilitySocialTab04>
      <SustainabilitySocialTab05
        v-if="tabChoose === 4"
      ></SustainabilitySocialTab05>
      <SustainabilitySocialTab06
        v-if="tabChoose === 5"
      ></SustainabilitySocialTab06>
      <SustainabilitySocialTab07
        v-if="tabChoose === 6"
      ></SustainabilitySocialTab07>
      <SustainabilitySocialTab08
        v-if="tabChoose === 7"
      ></SustainabilitySocialTab08>
    </div>

    <div class="sustainability-corporation-bottom esg-bottom">
      <div class="bottom-download-report">
        <div class="flex-wrap">
          <div class="text">
            <h4>{{ t("sustainability-social-bottom-download-text") }}</h4>
            <p>{{ t("sustainability-social-bottom-download-chapter") }}</p>
            <a
              :href="t('sustainability-social-bottom-download-report-link')"
              target="_blank"
              >{{ t("sustainability-social-bottom-download-readmore") }}</a
            >
          </div>
          <div class="image">
            <div class="img-padding">
              <img
                src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/Supplier2.png"
                alt="請參閱瀚宇彩晶2022年度永續報告書"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.esg-bottom {
  background-color: #f6f6f6;
  margin-top: 30px;
  .bottom-download-report {
    max-width: 1400px;
    width: 100%;
    margin: 0 auto;
    .flex-wrap {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 0 10px;
      @media screen and (max-width: 980px) {
        flex-direction: column-reverse;
        padding-bottom: 10px;
      }
      .text {
        width: 50%;
        text-align: left;
        @media screen and (max-width: 980px) {
          width: 90%;
          padding: 30px 0;
        }
        h4 {
          font-size: 24px;
          font-weight: 400;
          line-height: 36px;
          letter-spacing: 1px;
          padding-bottom: 30px;
        }
        p {
          font-size: 16px;
          line-height: 28px;
          font-weight: 400;
          letter-spacing: 1px;
          margin-bottom: 40px;
        }
        a {
          background-color: #039be5;
          border-radius: 4px;
          color: #fff;
          font-size: 16px;
          line-height: 1;
          padding: 12px 16px;
          word-break: keep-all;
          cursor: pointer;
          transition: all 0.1s ease-out;
          &:hover {
            background-color: #0959a2;
          }
        }
      }
      .image {
        width: 50%;
        padding-left: 60px;
        @media screen and (max-width: 980px) {
          width: 100%;
          padding: 30px 10px 0 10px;
        }
        .img-padding {
          padding: 60px 100px;
          @media screen and (max-width: 980px) {
            padding: 0;
          }
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
      }
    }
  }
}
</style>
