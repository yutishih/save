<script setup>
import { ref } from "vue";
definePageMeta({ path: "index", alias: [""] });
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("esg-menu01") });

const sustainabilityKeypoint = ref([
  {
    id: 1,
    type: "governance",
    typeText: t("sustainability-index-point-type01"),
    mainNTD: t("sustainability-index-point-mainNTD01"),
    mainTitle: t("sustainability-index-point-mainTitle01"),
    mainText: t("sustainability-index-point-mainText01"),
    arrow: "",
    subTitle: t("sustainability-index-point-subTitle01"),
  },
  {
    id: 2,
    type: "environment",
    typeText: t("sustainability-index-point-type02"),
    mainNTD: t("sustainability-index-point-mainNTD02"),
    mainTitle: t("sustainability-index-point-mainTitle02"),
    mainText: t("sustainability-index-point-mainText02"),
    arrow: "\u2193",
    subTitle: t("sustainability-index-point-subTitle02"),
  },
  {
    id: 3,
    type: "environment",
    typeText: t("sustainability-index-point-type03"),
    mainNTD: t("sustainability-index-point-mainNTD03"),
    mainTitle: t("sustainability-index-point-mainTitle03"),
    mainText: t("sustainability-index-point-mainText03"),
    arrow: "",
    subTitle: t("sustainability-index-point-subTitle03"),
  },
  {
    id: 4,
    type: "environment",
    typeText: t("sustainability-index-point-type04"),
    mainNTD: t("sustainability-index-point-mainNTD04"),
    mainTitle: t("sustainability-index-point-mainTitle04"),
    mainText: t("sustainability-index-point-mainText04"),
    arrow: "",
    subTitle: t("sustainability-index-point-subTitle04"),
  },
  {
    id: 5,
    type: "governance",
    typeText: t("sustainability-index-point-type05"),
    mainNTD: t("sustainability-index-point-mainNTD05"),
    mainTitle: t("sustainability-index-point-mainTitle05"),
    mainText: t("sustainability-index-point-mainText05"),
    arrow: "",
    subTitle: t("sustainability-index-point-subTitle05"),
  },
  {
    id: 6,
    type: "society",
    typeText: t("sustainability-index-point-type06"),
    mainNTD: t("sustainability-index-point-mainNTD06"),
    mainTitle: t("sustainability-index-point-mainTitle06"),
    mainText: t("sustainability-index-point-mainText06"),
    arrow: "\u2191",
    subTitle: t("sustainability-index-point-subTitle06"),
  },
  {
    id: 7,
    type: "society",
    typeText: t("sustainability-index-point-type07"),
    mainNTD: t("sustainability-index-point-mainNTD07"),
    mainTitle: t("sustainability-index-point-mainTitle07"),
    mainText: t("sustainability-index-point-mainText07"),
    arrow: "",
    subTitle: t("sustainability-index-point-subTitle07"),
  },
  {
    id: 8,
    type: "society",
    typeText: t("sustainability-index-point-type08"),
    mainNTD: t("sustainability-index-point-mainNTD08"),
    mainTitle: t("sustainability-index-point-mainTitle08"),
    mainText: t("sustainability-index-point-mainText08"),
    arrow: "\u2191",
    subTitle: t("sustainability-index-point-subTitle08"),
  },
]);

//sustainabilityKeypoint顏色分類
const colorDetector = (type) => {
  switch (type) {
    case "governance":
      return "#227FC4";
    case "environment":
      return "#00AB98";
    case "society":
      return "#A66BAB";
    default:
      return "#227FC4";
  }
};
</script>

<template>
  <div class="sustainability-index esg-page-container">
    <div class="sustainability-index-container">
      <div class="top-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/index/topbanner.png"
          alt="綠色創新 友善環境 共創永續價值"
        />
        <div class="main-banner-text main-banner-text-middle">
          <h2 class="title">{{ t("sustainability-index-top-banner-text") }}</h2>
        </div>
      </div>

      <Breadcrumbs
        :level-second="{
          text: data[2].subMenu[0].text,
          link: data[2].subMenu[0].link,
        }"
      ></Breadcrumbs>

      <div class="section-container">
        <div v-if="$i18n.locale === 'tw'">
          <EsgNewsLetter></EsgNewsLetter>
        </div>
        <section class="esg-page-title">
          <h1>{{ t("sustainability-index-main-title") }}</h1>
        </section>

        <section class="index-eight-squares">
          <div class="index-eight-squares-container">
            <div
              class="squares"
              v-for="(item, index) in sustainabilityKeypoint"
              :key="index"
              :style="{ backgroundColor: colorDetector(item.type) }"
              data-aos="flip-up"
              :data-aos-delay="`${index * 100}`"
            >
              <div>
                <div class="round-corner"></div>
                <p
                  class="subtitle"
                  :style="{ color: colorDetector(item.type) }"
                >
                  {{ item.typeText }}
                </p>
              </div>
              <div class="main-title">
                <h2>
                  <span> {{ item.mainNTD }}</span>
                  {{ item.mainTitle }}
                  <span> {{ item.mainText }} {{ item.arrow }} </span>
                </h2>
                <p class="main-sub-text">{{ item.subTitle }}</p>
              </div>
            </div>
          </div>
        </section>

        <section class="left-image-right-text" data-aos="fade-up">
          <div class="flex-wrap margin-left-right-10px">
            <div class="image">
              <img
                src="https://media.hannstar.com/Image/hannstar/sustainability/Rectangle2914.png"
                alt="Sustainalytics ESG 風險評級 無風險"
              />
            </div>
            <div class="text">
              <h4>{{ t("sustainability-index-subtitle01") }}</h4>
              <p>
                {{ t("sustainability-index-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section class="right-image-left-text" data-aos="fade-up">
          <div class="flex-wrap margin-left-right-10px">
            <div class="text">
              <h4>{{ t("sustainability-index-subtitle02") }}</h4>
              <p>
                {{ t("sustainability-index-text02") }}
              </p>
            </div>
            <div class="image">
              <img
                src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/index/bronze.png"
                alt="EcoVadis 永續評比 銅獎"
              />
            </div>
          </div>
        </section>

        <section class="left-image-right-text" data-aos="fade-up">
          <div class="flex-wrap">
            <div class="image">
              <img
                src="https://media.hannstar.com/Image/hannstar/sustainability/Rectangle2503.png"
                alt="TCSA 永續報告書 銀獎"
              />
            </div>
            <div class="text">
              <h4>{{ t("sustainability-index-subtitle03") }}</h4>
              <p>
                {{ t("sustainability-index-text03") }}
              </p>
            </div>
          </div>
        </section>

        <section class="right-image-left-text" data-aos="fade-up">
          <div class="flex-wrap margin-left-right-10px">
            <div class="text">
              <h4>{{ t("sustainability-index-subtitle04") }}</h4>
              <p>
                {{ t("sustainability-index-text04") }}
              </p>
            </div>
            <div class="image">
              <img
                src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/index/awardgroupphoto.png"
                alt="資誠永續影響力獎"
              />
            </div>
          </div>
        </section>

        <section class="video-section" data-aos="fade-up">
          <div class="video-section-container margin-left-right-10px">
            <div class="title">
              <h3>{{ t("sustainability-index-subtitle05") }}</h3>
              <p>
                {{ t("sustainability-index-text05") }}
              </p>
            </div>
            <div class="video">
              <video
                controls
                poster="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/index/2023_ESG_Report_0719_final_poster.png"
              >
                <source
                  src="https://media.hannstar.com/Video/hannstar/sustainability/2023_ESG_Report_0719_final.mp4"
                  type="video/mp4"
                />
              </video>
            </div>
          </div>
        </section>

        <section class="video-section" data-aos="fade-up">
          <div class="video-section-container margin-left-right-10px">
            <div class="title">
              <h3>{{ t("sustainability-index-subtitle06") }}</h3>
              <p>
                {{ t("sustainability-index-text06") }}
              </p>
            </div>
            <div class="video">
              <video
                controls
                poster="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/index/2022_hannstarfoundation_Disturbance.png"
              >
                <source
                  src="https://media.hannstar.com/Video/hannstar/sustainability/2022_hannstarfoundation_Disturbance.mp4"
                  type="video/mp4"
                />
              </video>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-index {
  .section-container {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    @media screen and (max-width: 980px) {
      width: 95%;
    }

    section {
      padding-bottom: 30px;
    }
  }
  .top-banner {
    position: relative;
    img {
      max-height: 400px;
      width: 100%;
      object-fit: cover;
    }
    .main-banner-text-middle {
      position: absolute;
      width: 100%;
      top: 50%;
      bottom: auto;
      left: 50%;
      transform: translate(-50%, -50%);
      h2 {
        color: #fff;
        text-align: center;
        text-shadow: 1px 1px 2px #363636;
      }
    }
  }
  .esg-page-title {
    text-align: center;
    padding: 30px 0;
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      margin: 0 auto;
      grid-template-columns: auto auto auto auto;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        width: 90%;
        height: 90%;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 50%;
          left: 50%;
          width: inherit;
          text-align: center;
          transform: translate(-50%, -40%);
          h2 {
            font-size: 2.5em;
            color: #fff;
            margin: 0;
            padding-bottom: 10px;
            @media (max-width: 1400px) {
              font-size: 2em;
            }
            @media (max-width: 980px) {
              font-size: 2.4em;
            }
            span {
              font-size: 24px;
              @media (max-width: 1400px) {
                font-size: 0.5em;
              }
            }
          }
          .main-sub-text {
            color: #fafafa;
            font-size: 1.2em;
            margin: 0;

            @media (max-width: 1400px) {
              font-size: 1em;
            }
            @media (max-width: 980px) {
              font-size: 1.5em;
            }
            @media (max-width: 768px) {
              font-size: 1em;
            }
          }
        }
        .round-corner {
          position: absolute;
          background-color: #f6f6f6;
          top: 2%;
          left: 24%;
          transform: translate(-50%, -50%);
          min-height: 10vw;
          min-width: 10vw;
          width: 50%;
          height: 50%;
          border-radius: 100%;
        }
        .subtitle {
          position: absolute;
          top: 12%;
          left: 24%;
          transform: translate(-50%, -50%);
          color: #111;
          font-size: 1.4rem;
          @media (max-width: 1500px) {
            font-size: 1em;
          }
          @media (max-width: 980px) {
            top: 10%;
            font-size: 1.5em;
          }
          @media (max-width: 768px) {
            font-size: 0.8em;
          }
        }
      }
    }
  }
  .right-image-left-text {
    .flex-wrap {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 10px;
      @media (max-width: 980px) {
        flex-direction: column-reverse;
      }
      .image {
        width: 50%;
        padding-left: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 0 10px;
        }
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }
      .text {
        width: 50%;
        text-align: left;
        padding-right: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 10px;
        }
        h4 {
          font-weight: 400;
          line-height: 36px;
          letter-spacing: 1px;
          padding-bottom: 30px;
          @media (max-width: 980px) {
            padding: 30px 0;
          }
        }
        p {
          line-height: 28px;
          font-weight: 400;
          letter-spacing: 1px;
        }
      }
    }
  }

  .left-image-right-text {
    .flex-wrap {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 10px;
      @media (max-width: 980px) {
        flex-direction: column;
      }
      .image {
        width: 50%;
        padding-right: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 0 10px;
        }
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }
      .text {
        width: 50%;
        text-align: left;
        padding-left: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 0 10px;
        }
        h4 {
          font-weight: 400;
          line-height: 36px;
          letter-spacing: 1px;
          padding-bottom: 30px;
          @media (max-width: 980px) {
            padding: 30px 0;
          }
        }
        p {
          line-height: 28px;
          font-weight: 400;
          letter-spacing: 1px;
        }
      }
    }
  }

  .video-section {
    .title {
      @media (max-width: 980px) {
        padding: 0 10px;
      }
      h3 {
        font-weight: 500;
        line-height: 48px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        text-align: center;
        @media (max-width: 980px) {
          font-size: 24px;
          padding-bottom: 0;
        }
      }
      p {
        max-width: 1000px;
        margin: 0 auto;
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
        text-align: left;
        padding-bottom: 30px;
      }
    }
    .video {
      video {
        width: 100%;
        height: auto;
        @media (max-width: 980px) {
          padding: 0 10px;
        }
      }
    }
  }
}
</style>
