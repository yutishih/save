<script setup>
import { ref } from "vue";
import AOS from "aos";
import "aos/dist/aos.css";

const localePath = useLocalePath();
const { t } = useI18n();

//meta data
useMeta({});

//動畫
onMounted(() => {
  AOS.init({
    duration: 1200,
  });
});

const serviceProduct = ref([
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/01.jpg",
    link: "products-detail-automotive",
    title: t("home-product01"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/02.jpg",
    link: "products-detail-industrial",
    title: t("home-product02"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/03.jpg",
    link: "products-detail-mobile",
    title: t("home-product03"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/04.jpg",
    link: "products-detail-wearable",
    title: t("home-product04"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/05.jpg",
    link: "products-detail-tablet",
    title: t("home-product05"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/06.jpg",
    link: "products-detail-touch",
    title: t("home-product06"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/07.jpg",
    link: "products-detail-monitor",
    title: t("home-product07"),
  },
  {
    img: "https://media.hannstar.com/Image/hannstar/oldpics/08.jpg",
    link: "products-detail-green-display",
    title: t("home-product08"),
  },
]);
</script>

<template>
  <div class="home-container">
    <div class="hannstar-main-page-banner">
      <img
        src="https://media.hannstar.com/Image/hannstar/index/banner1.jpg"
        alt=""
      />
      <div class="hannstar-main-page-banner-h2">
        <h2>{{ $t("home-banner-title") }}</h2>
      </div>
    </div>
    <section class="hannstar-main-section">
      <HomeNewsCenter></HomeNewsCenter>
      <HomeRelatedCompany></HomeRelatedCompany>
    </section>
    <section class="hannstar-product-section">
      <div class="hannstar-product-box">
        <div
          v-for="(item, index) in serviceProduct"
          :key="index"
          class="box-item"
          data-aos="flip-up"
          :data-aos-delay="`${index * 100}`"
        >
          <NuxtLink :to="localePath(item.link)">
            <div class="bg-color">
              <img :src="item.img" alt="" /> <span>{{ item.title }}</span>
            </div>
          </NuxtLink>
        </div>
      </div>
    </section>
    <section class="hannstar-main-hr" data-aos="fade-up">
      <img
        src="https://media.hannstar.com/Image/hannstar/index/career_banner_2.png"
        alt=""
      />
      <div class="hr-box">
        <h2>{{ $t("home-join-title") }}</h2>
        <p>{{ $t("home-join-text") }}</p>
        <a>{{ $t("home-join-more") }}</a>
      </div>
    </section>
    <section class="hannstar-main-hr" data-aos="fade-up">
      <img
        src="https://media.hannstar.com/Image/hannstar/index/esg_banner.jpg"
        alt=""
      />
      <div class="hr-box">
        <h2>
          {{ $t("home-esg-title") }}
        </h2>
        <p>{{ $t("home-esg-text") }}</p>
        <a>{{ $t("home-esg-more") }}</a>
      </div>
    </section>
    <section class="hannstar-full-rc">
      <div class="hannstar-full-rc-container">
        <h2>{{ $t("home-company-related") }}</h2>
        <div class="hannstar-rc-wrapper">
          <div class="full-rc-box" data-aos="fade-up" data-aos-delay="0">
            <a href="https://www.hannstar.com/tw/about/family#HannTouch">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/btn_hsd_index_rc_hss.png"
                alt=""
              />
              <h6 class="title">{{ $t("home-company01") }}</h6>
            </a>
          </div>
          <div class="full-rc-box" data-aos="fade-up" data-aos-delay="100">
            <a href="https://www.hannstar.com/tw/about/family#HannTouch">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/btn_hsd_index_rc_hsp.png"
                alt=""
              />
              <h6 class="title">{{ $t("home-company02") }}</h6>
            </a>
          </div>
          <div class="full-rc-box" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.hannstar.com/tw/about/family#HannTouch">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/btn_hsd_index_rc_hsf.png"
                alt=""
              />
              <h6 class="title">
                {{ $t("home-company03_1") }}<br />{{ $t("home-company03_2") }}
              </h6>
            </a>
          </div>
          <div class="full-rc-box" data-aos="fade-up" data-aos-delay="300">
            <a href="https://www.hannstar.com/tw/about/family#HannTouch">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/btn_hsd_index_rc_hsh.png"
                alt=""
              />
              <h6 class="title">{{ $t("home-company04") }}</h6>
            </a>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.hannstar-main-page-banner {
  margin-bottom: 35px;
  position: relative;

  .hannstar-main-page-banner-h2 {
    position: absolute;
    transform: translate(-50%, 0);
    left: 50%;
    width: 90%;
    max-width: 1600px;
    padding: 40px 0;
    bottom: 0;
    white-space-collapse: break-spaces;
  }

  h2 {
    font-size: 32px;
    font-weight: 400;
    line-height: 48px;
    letter-spacing: 1px;
    color: #fff;
    padding-bottom: 10px;
    text-shadow: 1px 1px 2px #363636;
  }

  img {
    display: block;
    width: 100%;
    min-height: 300px;
    object-fit: cover;
  }
}

.hannstar-main-section {
  width: 90%;
  max-width: 1600px;
  margin: 0 auto 50px auto;
  display: flex;

  @media (max-width: $mobileDeviceWidth) {
    flex-direction: column;
  }
}

.hannstar-product-section {
  width: 90%;
  max-width: 1400px;
  margin: 0 auto 35px auto;
}

.hannstar-product-box {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;

  .box-item {
    position: relative;
    padding: 5px 5px;
    margin: 10px 0;
    width: 25%;
    @media (max-width: $mobileDeviceWidth) {
      width: 50%;
      margin: 0;
    }
    .bg-color {
      position: relative;
      z-index: 10;
      display: block;
      background: rgba(0, 0, 0, 0);
      &:hover {
        &::before {
          opacity: 1;
        }
      }
      &::before {
        content: "";
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(
          to bottom,
          rgba(0, 148, 218, 0.7),
          rgba(0, 148, 218, 0)
        );
        opacity: 0;
        transition: opacity 0.3s ease;
        z-index: 1;
        img {
          object-fit: contain;
        }
      }

      span {
        position: absolute;
        left: 5%;
        bottom: 5%;
        color: #fff;
        font-size: 1.5em;
      }
    }
  }
}

.hannstar-main-hr {
  width: 90%;
  max-width: 1400px;
  margin: 0 auto 35px auto;
  position: relative;

  img {
    width: 100%;
  }

  .hr-box {
    position: absolute;
    left: 5%;
    bottom: 10%;
    text-align: left;
    color: #fff;

    @media (max-width: $mobileDeviceWidth) {
      position: relative;
      left: 0;
      padding: 15px;
      box-sizing: border-box;
      background-color: #a0ddff;
    }

    h2 {
      font-size: 32px;
      font-weight: 400;
      line-height: 48px;
      letter-spacing: 1px;
      color: #fff;
      padding-bottom: 10px;
      text-shadow: 1px 1px 2px #363636;
    }

    p {
      @media (max-width: $mobileDeviceWidth) {
        color: #000;
      }
    }

    a {
      display: inline-block;
      background-color: #0959a2;
      border-radius: 4px;
      color: #fff;
      font-size: 16px;
      line-height: 1;
      padding: 12px 16px;
      word-break: keep-all;
      cursor: pointer;
      margin-top: 20px;
      text-align: center;
    }
  }
}

.hannstar-full-rc {
  width: 100%;
  background-color: rgb(246, 246, 246);

  .hannstar-full-rc-container {
    width: 90%;
    max-width: 1400px;
    margin: 0px auto;
    padding: 25px 0;

    .hannstar-rc-wrapper {
      display: flex;
      align-items: flex-start;
      justify-content: center;
      margin: 35px 0 0 0;

      @media (max-width: $mobileDeviceWidth) {
        flex-wrap: wrap;
      }
    }

    h2 {
      font-size: 32px;
      text-align: center;
    }

    h6 {
      color: #363636;
      font-size: 16px;
      line-height: 28px;
      font-weight: 400;
      letter-spacing: 1px;
      margin: 5px;
      text-align: left;
    }

    .full-rc-box {
      display: inline-block;
      margin: 0 20px;

      @media (max-width: $mobileDeviceWidth) {
        width: 40%;
      }

      img {
        width: 100%;
      }

      a {
        text-decoration: none;
      }
    }
  }
}
</style>
