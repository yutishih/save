<script setup>
const { t } = useI18n();
</script>
<template>
  <div>
    <NuxtPage :page-key="(route) => route.fullPath"></NuxtPage>
  </div>
</template>
<style></style>
