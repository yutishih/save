<script setup>
import AOS from "aos";
import "aos/dist/aos.css";

//動畫
onMounted(() => {
  AOS.init({
    duration: 1200,
  });
});
</script>
<template>
  <div>
    <NuxtPage :page-key="(route) => route.fullPath"></NuxtPage>
  </div>
</template>
<style lang="scss">
.hannstar-careers-body {
  h1 {
    text-align: center;
    max-width: 1400px;
    width: 100%;
    margin: 0 auto 50px auto;
  }
}

.hannstar-careers-body {
  max-width: 1400px;
  margin: 0 auto;
  width: 90%;

  .careers-team-img {
    max-width: 1200px;
    width: 100%;
    margin: 0 auto;
  }
}
</style>
