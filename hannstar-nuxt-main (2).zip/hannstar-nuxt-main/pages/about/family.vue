<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("hannstar-related") });
</script>

<template>
  <div class="about-container">
    <Breadcrumbs
      :level-second="{ text: data[0].mainMenu, link: data[0].mainMenuLink }"
      :level-third="{
        text: data[0].subMenu[2].text,
        link: data[0].subMenu[2].link,
      }"
    ></Breadcrumbs>

    <div class="hannstar-about-body">
      <h1>{{ t("about-family-main-title") }}</h1>
      <div class="family-section">
        <section>
          <div class="family-section-content">
            <h2>{{ t("about-family-title01") }}</h2>
            <div class="about-family-logo">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/hannstar_logo.jpg"
                alt=""
              />
            </div>
            <p>
              {{ t("about-family-text01") }}
            </p>
            <h3>{{ t("about-family-contact") }}</h3>
            <div class="about-family-info">
              <div>{{ t("about-family-phone01") }}</div>
              <div>{{ t("about-family-fax01") }}</div>
              <div>{{ t("about-family-address01") }}</div>
            </div>
          </div>
          <div class="family-section-img">
            <img
              src="https://media.hannstar.com/Image/hannstar/about/family/hannstar.jpg"
              alt=""
            />
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="family-section-content">
            <h2>{{ t("about-family-title02") }}</h2>
            <div class="about-family-logo">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/hannstouch_logo.jpg"
                alt=""
              />
            </div>
            <p>
              {{ t("about-family-text02") }}
            </p>
            <h3>{{ t("about-family-contact") }}</h3>
            <div class="about-family-info">
              <div>{{ t("about-family-phone02") }}</div>
              <div>{{ t("about-family-fax02") }}</div>
              <div>{{ t("about-family-address02") }}</div>
              <a href="https://www.hannstouch.com" target="_blank">
                <div>LEARN MORE ></div>
              </a>
            </div>
          </div>
          <div class="family-section-img">
            <img
              src="https://media.hannstar.com/Image/hannstar/about/family/hannstouch.jpg"
              alt=""
            />
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="family-section-content">
            <h2>{{ t("about-family-title03") }}</h2>
            <div class="about-family-logo">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/hsnnspree_logo.jpg"
                alt=""
              />
            </div>
            <p>
              {{ t("about-family-text03") }}
            </p>
            <h3>{{ t("about-family-contact") }}</h3>
            <div class="about-family-info">
              <div>{{ t("about-family-phone03") }}</div>
              <div>{{ t("about-family-address03") }}</div>
              <a href="https://www.hannspree.eu/" target="_blank">
                <div>LEARN MORE ></div>
              </a>
            </div>
          </div>
          <div class="family-section-img">
            <img
              src="https://media.hannstar.com/Image/hannstar/about/family/hannspree.jpg"
              alt=""
            />
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="family-section-content">
            <h2>{{ t("about-family-title04") }}</h2>
            <div class="about-family-logo">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/hannshouse_logo.png"
                alt=""
              />
            </div>
            <p>
              {{ t("about-family-text04") }}
            </p>
            <h3>{{ t("about-family-contact") }}</h3>
            <div class="about-family-info">
              <div>{{ t("about-family-phone04") }}</div>
              <div>{{ t("about-family-address04") }}</div>
              <div>{{ t("about-family-email04") }}</div>
              <a href="https://hannshouse.com/about.php" target="_blank">
                <div>LEARN MORE ></div>
              </a>
            </div>
          </div>
          <div class="family-section-img">
            <img
              src="https://media.hannstar.com/Image/hannstar/about/family/hannshouse.jpg"
              alt=""
            />
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="family-section-content">
            <h2>{{ t("about-family-title05") }}</h2>
            <div class="about-family-logo">
              <img
                src="https://media.hannstar.com/Image/hannstar/index/foundation_logo.jpg"
                alt=""
              />
            </div>
            <p>
              {{ t("about-family-text05") }}
            </p>
            <h3>{{ t("about-family-contact") }}</h3>
            <div class="about-family-info">
              <div>{{ t("about-family-phone05") }}</div>
              <div>{{ t("about-family-address05") }}</div>
              <div>{{ t("about-family-email05") }}</div>
              <a href="https://hannstarfoundation.org" target="_blank">
                <div>LEARN MORE ></div>
              </a>
            </div>
          </div>
          <div class="family-section-img">
            <img
              src="https://media.hannstar.com/Image/hannstar/about/family/foundation.jpg"
              alt=""
            />
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.hannstar-about-body {
  .family-section {
    section {
      display: flex;
      margin-bottom: 75px;

      @media (max-width: $mobileDeviceWidth) {
        flex-direction: column;
      }

      .family-section-content {
        width: 50%;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
        }

        .about-family-logo {
          margin: 15px 0;
        }

        p {
          color: #363636;
          font-size: 16px;
          line-height: 28px;
          font-weight: 400;
          letter-spacing: 1px;
          padding-bottom: 10px;
          border-bottom: 1px solid #b9b9b9;
          margin-bottom: 25px;
        }

        h3 {
          margin-bottom: 25px;
        }
      }

      .about-family-info {
        div {
          margin: 10px 0;
        }

        a {
          color: $textLinkColor;

          div {
            margin-top: 25px;
          }
        }
      }

      .family-section-img {
        width: 50%;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
        }

        img {
          width: 100%;
          display: block;
        }
      }

      &:nth-child(2n - 1) {
        .family-section-content {
          order: 1;

          @media (max-width: $mobileDeviceWidth) {
            order: 2;
          }
        }

        .family-section-img {
          padding-left: 35px;
          box-sizing: border-box;
          order: 2;

          @media (max-width: $mobileDeviceWidth) {
            padding-left: 0;
            order: 1;
            margin-bottom: 25px;
          }
        }
      }

      &:nth-child(2n) {
        .family-section-content {
          order: 2;
          box-sizing: border-box;
          padding-left: 35px;

          @media (max-width: $mobileDeviceWidth) {
            padding-left: 0;
            order: 2;
          }
        }

        .family-section-img {
          padding-right: 35px;
          box-sizing: border-box;
          order: 1;

          @media (max-width: $mobileDeviceWidth) {
            padding-right: 0;
            order: 1;
            margin-bottom: 25px;
          }
        }
      }
    }
  }
}
</style>
