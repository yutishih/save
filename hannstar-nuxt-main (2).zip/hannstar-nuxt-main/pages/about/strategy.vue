<script setup>
import { ref } from "vue";
import { useRoute, useRouter } from "vue-router";

const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("hannstar-quality") });

const tabItems = [
  {
    text: t("about-strategy-tab01"),
    queryTab: "QualityManagementStrategy",
  },
  {
    text: t("about-strategy-tab02"),
    queryTab: "GreenProductPolicy",
  },
  {
    text: t("about-strategy-tab03"),
    queryTab: "GreenEnvironment",
  },
  {
    text: t("about-strategy-tab04"),
    queryTab: "GreenManagementandCertification",
  },
  {
    text: t("about-strategy-tab05"),
    queryTab: "GreenProductEvents",
  },
];

const router = useRouter();
const route = useRoute();

// 獲取 URL 查詢參數中的 Tab 值
const getInitialTab = () => {
  const tabParam = route.query.Tab;
  if (tabParam) {
    const tabIndex = tabItems.findIndex((item) => item.queryTab === tabParam);
    return tabIndex !== -1 ? tabIndex : 0;
  }
  return 0;
};

// 在創建時設定初始 Tab
const tabChoose = ref(getInitialTab());

const updateQueryParam = (index) => {
  const selectedTab = tabItems[index].queryTab;
  router.push({ query: { Tab: selectedTab } });
};

const getTabChooseIndex = (i) => {
  tabChoose.value = parseInt(i);
  updateQueryParam(tabChoose.value);
};
</script>
<template>
  <div class="about-container">
    <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/about/strategy/img_strategy_top_banner.png'"
      :banner-title="t('about-strategy-main-title')"
      :banner-text="''"
      :banner-height-max="400"
    ></TopBanner>

    <Breadcrumbs
      :level-second="{ text: data[0].mainMenu, link: data[0].mainMenuLink }"
      :level-third="{
        text: data[0].subMenu[3].text,
        link: data[0].subMenu[3].link,
      }"
      :level-forth="tabItems[tabChoose].text"
    ></Breadcrumbs>
    <Tab
      :tab-navigation="tabItems"
      @update:tab-choose="getTabChooseIndex"
    ></Tab>

    <div class="about-tab-content">
      <AboutStrategyTab01 v-if="tabChoose === 0"></AboutStrategyTab01>
      <AboutStrategyTab02 v-if="tabChoose === 1"></AboutStrategyTab02>
      <AboutStrategyTab03 v-if="tabChoose === 2"></AboutStrategyTab03>
      <AboutStrategyTab04 v-if="tabChoose === 3"></AboutStrategyTab04>
      <AboutStrategyTab05 v-if="tabChoose === 4"></AboutStrategyTab05>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.about-tab-content {
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;
}
</style>
