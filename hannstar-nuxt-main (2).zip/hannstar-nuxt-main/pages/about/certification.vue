<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("hannstar-cert") });

const toggleIndex = ref(null);
const openCollapse = (i) => {
  if (toggleIndex.value === i) {
    toggleIndex.value = null;
  } else {
    toggleIndex.value = i;
  }
};

const certData = [
  {
    pin: "ISO 9001:2015",
    name: t("about-certification-content-table-system-name01"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "20001189 QM15",
        first: "2005/3/1 (~2023/12/14)",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "20006449 QM15",
        first: "2011/9/22 (~2024/1/27)",
      },
    ],
  },
  {
    pin: "IATF 16949:2016",
    name: t("about-certification-content-table-system-name02"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "20001189 IATF16",
        first: "2017/12/23 (~2023/12/14)",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "20006449 IATF16",
        first: "2018/1/28 (~2024/7/7)",
      },
    ],
  },
  {
    pin: "IECQ QC 080000:2017",
    name: t("about-certification-content-table-system-name03"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "IECQ-H ULTW 16.0003-01",
        first: "2020/1/14",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "IECQ-H ULTW 16.0003",
        first: "2010/3/18",
      },
    ],
  },
  {
    pin: "AS9100:D / JISQ 9100:2016 / EN 9100:2018",
    name: t("about-certification-content-table-system-name04"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "9650/0",
        first: "2019/9/26",
      },
    ],
  },
  {
    pin: "IEC-61340-5-1:2016",
    name: t("about-certification-content-table-system-name05"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW20/10621",
        first: "2018/11/14",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "10000505133-MSC-ESD-CHN",
        first: "2022/2/23",
      },
    ],
  },
  {
    pin: "ANSI ESD S20.20:2014",
    name: t("about-certification-content-table-system-name06"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW20/10620",
        first: "2018/11/14",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "10000505133-MSC-ESD-CHN",
        first: "2022/2/23",
      },
    ],
  },
  {
    pin: "ISO/IEC 17025:2017",
    name: t("about-certification-content-table-system-name07"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "IECQ-L ULTW 19.0008",
        first: "2019/12/3",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "IECQ-L ULTW 20.0002",
        first: "2020/1/10",
      },
    ],
  },
  {
    pin: "ISO 28000:2007",
    name: t("about-certification-content-table-system-name08"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW19/00359",
        first: "2019/10/14",
      },
    ],
  },
  {
    pin: "ISO 27001:2013",
    name: t("about-certification-content-table-system-name09"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW18/00703",
        first: "2018/12/21 (~2024/12/21)",
      },
    ],
  },
  {
    pin: "ISO 14001:2015",
    name: t("about-certification-content-table-system-name10"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW00/18866",
        first: "2000/11/28 (~2024/11/28)",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "59446-2009-AE-RGC-RVA",
        first: "2009/8/18 (~2024/8/18)",
      },
    ],
  },
  {
    pin: "ISO 45001:2018",
    name: t("about-certification-content-table-system-name11"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW16/01145",
        first: "2020/1/6 (~2024/11/28)",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "59447-2009-ASA-RGC-RVA",
        first: "2020/11/3 (~2024/8/17)",
      },
    ],
  },
  {
    pin: "ISO 50001:2018",
    name: t("about-certification-content-table-system-name12"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TW19/10702",
        first: "2019/12/8 (~2025/12/8)",
      },
    ],
  },
  {
    pin: "SONY GP",
    name: t("about-certification-content-table-system-name13"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "FC014891",
        first: "2019/5/30",
      },
      {
        area: t("about-certification-content-table-Nanjing"),
        code: "FC014890",
        first: "2019/6/12",
      },
    ],
  },
  {
    pin: "AEO",
    name: t("about-certification-content-table-system-name14"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "TWAEO-10700005",
        first: "2018/7/6",
      },
    ],
  },
  {
    pin: "RBA",
    name: t("about-certification-content-table-system-name15"),
    section: [
      {
        area: t("about-certification-content-table-Tainan"),
        code: "VAR-20190521-886-02A01",
        first: "2019/5/21",
      },
    ],
  },
];
</script>
<template>
  <div class="about-container">
    <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/about/Certificate/certificateTopBanner.png'"
      :banner-title="t('about-certification-main-title')"
      :banner-text="''"
      :banner-height-max="400"
    ></TopBanner>

    <Breadcrumbs
      :level-second="{ text: data[0].mainMenu, link: data[0].mainMenuLink }"
      :level-third="{
        text: data[0].subMenu[4].text,
        link: data[0].subMenu[4].link,
      }"
    ></Breadcrumbs>

    <div class="about-strategy">
      <h1>{{ t("about-certification-content-title") }}</h1>
      <p>
        {{ t("about-certification-content-text01") }}
      </p>
      <img
        src="https://media.hannstar.com/Image/hannstar/document360/about/strategy/strategy4.jpg"
        alt=""
      />
      <p>{{ t("about-certification-content-location") }}</p>
      <table class="pc-display">
        <tbody>
          <tr>
            <th>{{ t("about-certification-content-table-head01") }}</th>
            <th>{{ t("about-certification-content-table-head02") }}</th>
            <th>{{ t("about-certification-content-table-head03") }}</th>
            <th>{{ t("about-certification-content-table-head04") }}</th>
            <th>{{ t("about-certification-content-table-head05") }}</th>
          </tr>

          <template v-for="item in certData">
            <tr
              v-for="(subItem, index) in item.section"
              :key="index"
              class="pc-table-style"
            >
              <td colspan="1" :rowspan="item.section.length" v-if="index === 0">
                {{ item.pin }}
              </td>
              <td colspan="1" :rowspan="item.section.length" v-if="index === 0">
                {{ item.name }}
              </td>
              <td>{{ subItem.area }}</td>
              <td>{{ subItem.code }}</td>
              <td>{{ subItem.first }}</td>
            </tr>
          </template>
        </tbody>
      </table>

      <!-- Mobile Table Components -->
      <div class="mb-table-wrapper table-mobile-component mb-display">
        <div class="table-collapse">
          <div
            v-for="(item, index) in certData"
            :key="index"
            class="table-list"
            @click="openCollapse(index)"
          >
            <div class="list-flex">
              <span>{{ item.pin }} {{ item.name }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleIndex === index }"
              ></span>
            </div>
            <div
              class="list-collapse"
              :class="{ active: toggleIndex === index }"
            >
              <div>
                <ul v-for="(subItem, index) in item.section" :key="index">
                  <li>
                    <span
                      >{{
                        t("about-certification-content-table-head03")
                      }}: </span
                    ><span>{{ subItem.area }}</span>
                  </li>
                  <li>
                    <span
                      >{{
                        t("about-certification-content-table-head04")
                      }}:</span
                    ><span>{{ subItem.code }}</span>
                  </li>
                  <li>
                    <span
                      >{{
                        t("about-certification-content-table-head05")
                      }}:</span
                    ><span>{{ subItem.first }}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.about-container {
  margin-bottom: 35px;
}

.about-strategy {
  max-width: 1000px;
  width: 90%;
  margin: 0 auto;

  h1 {
    text-align: center;
    margin-bottom: 35px;
  }

  p {
    margin-bottom: 35px;
    line-height: 2;
  }

  img {
    width: 100%;
    margin-bottom: 25px;
  }
}

table {
  width: 100%;
  margin-bottom: 50px;

  tbody {
    tr {
      &:nth-child(1) {
        text-size-adjust: none;
        box-sizing: border-box;
        margin: 0px;
        outline: 0px;
        font-size: 16px;
        vertical-align: middle;
        background: rgb(0, 148, 218);

        th {
          border: 1px solid rgb(232, 232, 232);
          padding: 15px;
          color: rgb(255, 255, 255);
        }
      }

      td {
        text-size-adjust: none;
        box-sizing: border-box;
        margin: 0px;
        padding: 15px;
        border: 1px solid rgb(232, 232, 232);
        outline: 0px;
        font-size: 16px;
        vertical-align: middle;
        background: rgb(255, 255, 255);
        text-align: center;
      }
    }

    tr.grey-bg-color {
      td {
        background: rgb(238, 238, 238);
      }
    }
  }
}

.mb-table-wrapper {
  padding: 15px 20px 20px 20px;
  border: 1px solid #b9b9b9;
  box-sizing: border-box;
  display: flex;

  .table-collapse {
    display: block;
    width: 100%;
  }

  .table-list {
    width: 100%;
    display: block;
    padding: 15px 0;
    border-bottom: 1px solid #b9b9b9;
    cursor: pointer;

    .list-flex {
      display: flex;
      justify-content: space-between;
      span {
        max-width: 300px;
      }
    }
  }

  .list-collapse {
    height: 0;
    transition: 0.5s;
    overflow: hidden;

    ul {
      padding-left: 20px;
      &:first-child {
        margin-top: 25px;
      }

      &:not(:last-child) {
        margin-bottom: 25px;
      }

      li {
        margin: 5px 0;
      }
    }

    div {
      opacity: 0;
      transition: 0.5s;
    }

    &.active {
      height: auto;

      div {
        opacity: 1;
      }
    }
  }
}

.pc-table-style {
  td,
  th {
    &:nth-child(1) {
    }

    &:nth-child(2) {
      width: 25%;
    }

    &:nth-child(3) {
      width: 10%;
    }

    &:nth-child(4) {
      width: 25%;
    }

    &:nth-child(5) {
      width: 15%;
    }
  }
}

@media screen and (max-width: $mobileDeviceWidth) {
  .table-pc-component {
    display: none;
  }
}

@media screen and (min-width: $mobileDeviceWidth) {
  .table-mobile-component {
    display: none;
  }
}

.plus-icon {
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}
</style>
