<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("hannstar-team") });

const tableHead = [
  {
    text: t("about-team-position-title"),
    width: 15,
    align: "center",
  },
  {
    text: t("about-team-name-title"),
    width: 15,
    align: "center",
  },
  {
    text: t("about-team-experience-title"),
    width: "",
    align: "left",
  },
];

const teamData = [
  {
    title: t("about-team-position01"),
    name: t("about-team-name01"),
    jobs: [t("about-team-experience01_1"), t("about-team-experience01_2")],
  },
  {
    title: t("about-team-position02"),
    name: t("about-team-name02"),
    jobs: [
      t("about-team-experience02_1"),
      t("about-team-experience02_2"),
      t("about-team-experience02_3"),
    ],
  },
  {
    title: t("about-team-position03"),
    name: t("about-team-name03"),
    jobs: [
      t("about-team-experience03_1"),
      t("about-team-experience03_2"),
      t("about-team-experience03_3"),
      t("about-team-experience03_4"),
      t("about-team-experience03_5"),
      t("about-team-experience03_6"),
    ],
  },
  {
    title: t("about-team-position04"),
    name: t("about-team-name04"),
    jobs: [
      t("about-team-experience04_1"),
      t("about-team-experience04_2"),
      t("about-team-experience04_3"),
      t("about-team-experience04_4"),
      t("about-team-experience04_5"),
      t("about-team-experience04_6"),
    ],
  },
  {
    title: t("about-team-position05"),
    name: t("about-team-name05"),
    jobs: [
      t("about-team-experience05_1"),
      t("about-team-experience05_2"),
      t("about-team-experience05_3"),
    ],
  },
  {
    title: t("about-team-position06"),
    name: t("about-team-name06"),
    jobs: [
      t("about-team-experience06_1"),
      t("about-team-experience06_2"),
      t("about-team-experience06_3"),
    ],
  },
  // {
  //   title: t("about-team-position07"),
  //   name: t("about-team-name07"),
  //   jobs: [t("about-team-experience07_1"), t("about-team-experience07_2")],
  // },
  {
    title: t("about-team-position08"),
    name: t("about-team-name08"),
    jobs: [
      t("about-team-experience08_1"),
      t("about-team-experience08_2"),
      t("about-team-experience08_3"),
      t("about-team-experience08_4"),
      t("about-team-experience08_5"),
    ],
  },
  {
    title: t("about-team-position09"),
    name: t("about-team-name09"),
    jobs: [
      t("about-team-experience09_1"),
      t("about-team-experience09_2"),
      t("about-team-experience09_3"),
      t("about-team-experience09_4"),
    ],
  },
];
</script>
<template>
  <div class="about-container">
    <Breadcrumbs
      :level-second="{ text: data[0].mainMenu, link: data[0].mainMenuLink }"
      :level-third="{
        text: data[0].subMenu[1].text,
        link: data[0].subMenu[1].link,
      }"
    ></Breadcrumbs>

    <div class="hannstar-about-body">
      <h1>{{ t("about-team-title") }}</h1>
      <div class="about-team-img">
        <img :src="t('about-team-banner_pc')" alt="" class="pc-display" />
        <img
          :src="t('about-team-banner_mobile')"
          alt=""
          class="mb-team-img mb-display"
        />
      </div>
      <div class="hannstar-table">
        <Table :table-head-data="tableHead" :table-body-data="teamData"></Table>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.mb-team-img {
  max-width: 600px;
  width: 100%;
  margin: 0 auto;
}
</style>
