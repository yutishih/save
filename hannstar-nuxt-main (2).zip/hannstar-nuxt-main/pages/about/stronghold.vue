<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("hannstar-global") });
</script>

<template>
  <div class="about-container">
    <Breadcrumbs
      :level-second="{ text: data[0].mainMenu, link: data[0].mainMenuLink }"
      :level-third="{
        text: data[0].subMenu[5].text,
        link: data[0].subMenu[5].link,
      }"
    ></Breadcrumbs>
    <div class="map-container">
      <h1>{{ t("about-stronghold-main-title") }}</h1>
      <div class="map-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/about/GlobalLocation/map.jpg"
            alt=""
          />
        </div>
        <div class="map-text">
          <div class="map-section">
            <h4>{{ t("about-stronghold-location01") }}</h4>
            <p>
              <span>{{ t("about-stronghold-address") }}: </span>
              {{ t("about-stronghold-address01") }}
            </p>
            <p>
              <strong>{{ t("about-stronghold-contact") }}: </strong>
              {{ t("about-stronghold-number01") }}
            </p>
          </div>

          <div class="map-section">
            <h4>{{ t("about-stronghold-location02") }}</h4>
            <p>
              <span>{{ t("about-stronghold-address") }}: </span>
              {{ t("about-stronghold-address02") }}
            </p>
            <p>
              <strong>{{ t("about-stronghold-contact") }}: </strong>
              {{ t("about-stronghold-number02") }}
            </p>
          </div>

          <div class="map-section">
            <h4>{{ t("about-stronghold-location03") }}</h4>
            <p>
              <span>{{ t("about-stronghold-address") }}: </span>
              {{ t("about-stronghold-address03") }}
            </p>
            <p>
              <strong>{{ t("about-stronghold-contact") }}: </strong>
              {{ t("about-stronghold-number03") }}
            </p>
          </div>

          <div class="map-section">
            <h4>{{ t("about-stronghold-location04") }}</h4>
            <p>
              <span>{{ t("about-stronghold-address") }}: </span>
              {{ t("about-stronghold-address04") }}
            </p>
            <p>
              <strong>{{ t("about-stronghold-contact") }}: </strong>
              {{ t("about-stronghold-number04") }}
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.map-container {
  max-width: 1400px;
  width: 90%;
  margin: 0 auto 50px auto;
}

.map-box {
  display: flex;

  @media screen and (max-width: $mobileDeviceWidth) {
    flex-direction: column;
  }

  div {
    width: 50%;

    @media screen and (max-width: $mobileDeviceWidth) {
      width: 100%;
    }
  }

  img {
    width: 100%;
  }

  .map-text {
    padding-left: 35px;
    box-sizing: border-box;

    @media screen and (max-width: $mobileDeviceWidth) {
      padding: 0;
      margin-top: 35px;
    }

    .map-section {
      width: 100%;
      position: relative;
      border-bottom: 1px solid #ddd;
      padding: 0 0 15px 0;
      margin-bottom: 35px;
      h4 {
        margin-bottom: 15px;
      }

      p {
        margin-bottom: 15px;
      }
    }
  }
}
</style>
