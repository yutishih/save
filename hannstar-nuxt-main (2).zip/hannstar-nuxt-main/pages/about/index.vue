<script setup>
// 改寫 Index 路徑
definePageMeta({
  path: "index",
  alias: [""],
});

const { t } = useI18n();
const { data } = useSitemap();
const { mileStoneData } = useMilestone();

//meta data
useMeta({ title: t("title-about") });
</script>

<template>
  <div class="about-container">
    <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/about/Profile/HannStarVision.jpg'"
      :banner-title="t('about-index-banner-title')"
      :banner-text="t('about-index-banner-text')"
      :banner-height-max="500"
    ></TopBanner>
    <Breadcrumbs
      :level-second="{ text: data[0].mainMenu, link: data[0].mainMenuLink }"
      :level-third="{
        text: data[0].subMenu[0].text,
        link: data[0].subMenu[0].link,
      }"
    ></Breadcrumbs>
    <div class="hannstar-about-body">
      <h1>{{ $t("about-index-main-title") }}</h1>
      <div class="intro-section" data-aos="fade-up">
        <div class="intro-section-text">
          <h2>{{ $t("about-index-title1") }}</h2>
          <p>
            {{ $t("about-index-text1") }}
          </p>
        </div>
        <div class="intro-section-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/about/Profile/Managementphilosophy.jpg"
            alt="瀚宇彩晶經營理念"
          />
        </div>
      </div>
      <div class="intro-section" data-aos="fade-up">
        <div class="intro-section-text">
          <h2>{{ $t("about-index-title2") }}</h2>
          <p>
            {{ $t("about-index-text2") }}
          </p>
        </div>
        <div class="intro-section-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/about/Profile/HannStarMission.jpg"
            alt="瀚宇彩晶使命"
          />
        </div>
      </div>
    </div>
    <div class="hannstar-history milestoneBlock" data-aos="fade-up">
      <h2 class="title">{{ $t("about-index-milestone-title") }}</h2>
      <ul class="historyList">
        <li v-for="(item, index) in mileStoneData" :key="index">
          <div class="item">
            <div class="historyDate">{{ item.date }}</div>
            <div v-if="item.img !== ''" class="imgBlock">
              <img :src="item.img" :alt="item.text" />
            </div>
            <h3>{{ item.text }}</h3>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.intro-section {
  display: flex;
  max-width: 1400px;
  width: 100%;
  margin: 0 auto 75px auto;

  @media (max-width: $mobileDeviceWidth) {
    flex-direction: column;
  }

  .intro-section-text {
    width: 50%;
    padding: 0 15px;
    box-sizing: border-box;

    @media (max-width: $mobileDeviceWidth) {
      width: 100%;
      order: 2;
    }

    h2 {
      font-size: 2em;
      margin-bottom: 25px;
    }

    p {
      font-size: 1.15em;
      line-height: 2;
      margin: 15px 0 0 0;
    }
  }

  .intro-section-img {
    width: 50%;
    padding: 0 15px;
    box-sizing: border-box;

    @media (max-width: $mobileDeviceWidth) {
      width: 100%;
      order: 1;
      margin-bottom: 20px;
    }

    img {
      width: 100%;
    }
  }
}

.intro-section:nth-child(2n + 1) {
  .intro-section-text {
    order: 2;
  }
  .intro-section-img {
    order: 1;
  }
}

.milestoneBlock {
  width: 100%;
  padding: 60px 0;
}

.milestoneBlock .title {
  color: #363636;
  font-size: 32px;
  font-weight: 400;
  line-height: 48px;
  letter-spacing: 1px;
  text-align: center;
  font-size: 40px;
  line-height: 60px;
}

.milestoneBlock .historyList {
  position: relative;
  display: flex;
  flex-direction: column;
  max-width: 880px;
  margin-left: auto;
  margin-right: auto;
  padding-top: 80px;
  padding-bottom: 80px;
  background: linear-gradient(to bottom, #b1b1b1 2px, transparent 0) 50% 0/2px
    8px repeat-y;

  @media (max-width: $mobileDeviceWidth) {
    width: 90%;
    margin: 0 auto;
  }
}

.milestoneBlock .historyList::before {
  content: "";
  position: absolute;
  left: 50%;
  top: 0;
  width: 6px;
  height: 6px;
  margin-left: -3px;
  border-radius: 50%;
  background-color: #039be5;
}

.milestoneBlock .historyList li {
  position: relative;
  display: flex;
  width: 50%;
  box-sizing: border-box;
}

.milestoneBlock .historyList li .item {
  width: 100%;
}

.milestoneBlock .historyList li .item .historyDate {
  display: flex;
  align-items: center;
  justify-content: initial;
  margin-bottom: 10px;
}

.milestoneBlock .historyList li .item .imgBlock {
  margin-bottom: 10px;
  border: 6px solid #fff;
  box-shadow: 0 0 29px rgba(0, 0, 0, 0.1);
  transition: all 0.5s ease-out;
  width: fit-content;
}

.milestoneBlock .historyList li .item .imgBlock img {
  display: block;
  max-width: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
}

.milestoneBlock .historyList li .item h3 {
  color: #363636;
  font-size: 16px;
  font-weight: 400;
  line-height: 1.8;
}

.milestoneBlock .historyList li:nth-child(odd) {
  margin-left: auto;
  padding-left: 60px;
}

.milestoneBlock .historyList li:nth-child(odd)::before {
  left: -15px;
}

.milestoneBlock .historyList li:nth-child(odd)::after {
  left: -3px;
}

.milestoneBlock .historyList li:nth-child(odd) .historyDate::before {
  content: "";
  font-size: 20px;
  margin-right: 10px;
}

.milestoneBlock .historyList li:nth-child(even) {
  margin-right: auto;
  padding-right: 60px;
  text-align: right;
}

.milestoneBlock .historyList li:nth-child(even) .historyDate {
  justify-content: flex-end;
}

.milestoneBlock .historyList li:nth-child(even) .historyDate::after {
  content: "";
  font-size: 20px;
  margin-right: 10px;
}

.milestoneBlock .historyList li:nth-child(even) h3 {
  text-align: right;
}

.milestoneBlock .historyList li:nth-child(even)::before {
  right: -15px;
}

.milestoneBlock .historyList li:nth-child(even)::after {
  right: -3px;
}

.milestoneBlock .historyList li::before {
  content: "";
  position: absolute;
  z-index: 1;
  border-radius: 50%;
  top: 5px;
  width: 30px;
  height: 30px;
  border: 1px solid #9adbfa;
  background-color: #fff;
  box-sizing: border-box;
}

.milestoneBlock .historyList li::after {
  content: "";
  position: absolute;
  z-index: 1;
  border-radius: 50%;
  top: 17px;
  width: 6px;
  height: 6px;
  background-color: #0094da;
  box-sizing: border-box;
}

.milestoneBlock .historyList li .item .historyDate {
  display: flex;
  align-items: center;
  color: #363636;
  font-size: 32px;
  font-weight: 400;
  line-height: 48px;
  letter-spacing: 1px;
  color: #039be5;
}

@media (max-width: 980px) {
  .milestoneBlock .historyList {
    background-position-x: 1.5px;
  }

  .milestoneBlock .historyList::before {
    left: 0;
    margin-left: 0;
  }

  .milestoneBlock .historyList li {
    width: 100%;
    margin-top: 30px;
  }

  .milestoneBlock .historyList li:nth-child(odd) {
    padding-left: 25px;
  }

  .milestoneBlock .historyList li:nth-child(odd)::before {
    left: -12px;
  }

  .milestoneBlock .historyList li:nth-child(odd)::after {
    left: 0px;
  }

  .milestoneBlock .historyList li:nth-child(even) {
    padding-left: 25px;
    padding-right: 0px;
  }

  .milestoneBlock .historyList li:nth-child(even)::before {
    left: -12px;
  }

  .milestoneBlock .historyList li:nth-child(even)::after {
    left: 0;
  }

  .milestoneBlock .historyList li:nth-child(even) .item .historyDate::before {
    content: ">";
    font-size: 20px;
    margin-right: 10px;
  }

  .milestoneBlock .historyList li:nth-child(even) .item .historyDate::after {
    content: "";
    font-size: 20px;
    margin-right: 10px;
  }

  .milestoneBlock .historyList li .item .historyDate {
    justify-content: left;
  }

  .milestoneBlock .historyList li .item h3 {
    text-align: left;
    line-height: 1.4;
  }

  .milestoneBlock .historyList li::before {
    top: 10px;
  }

  .milestoneBlock .historyList li::after {
    top: 22px;
  }
}
</style>
