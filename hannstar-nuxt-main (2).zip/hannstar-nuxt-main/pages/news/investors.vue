<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("news-menu01") });

//投資人關係數據
const { investorData } = useInvestorData();

const filterData = ref(investorData);
const selectYear = ref("");

const yearChange = (y) => {
  console.log(y.target.value);

  if (y.target.value !== "") {
    filterData.value = investorData.filter((x) => {
      return x.year === y.target.value;
    });
  } else {
    filterData.value = investorData;
  }
};
</script>

<template>
  <div class="news-container">
    <Breadcrumbs
      :level-second="{ text: data[5].mainMenu, link: data[5].mainMenuLink }"
      :level-third="{
        text: data[5].subMenu[0].text,
        link: data[5].subMenu[0].link,
      }"
    ></Breadcrumbs>
    <TabNews :tab-active="0"></TabNews>

    <h1>{{ t("news-investors-main-title") }}</h1>
    <div class="investors-year">
      <select v-model="selectYear" @change="yearChange($event)">
        <option value="">Years</option>
        <option value="2024">2024</option>
        <option value="2023">2023</option>
        <option value="2022">2022</option>
        <option value="2021">2021</option>
        <option value="2020">2020</option>
      </select>
    </div>
    <div class="news-list-container">
      <div class="list-grid" v-for="(item, index) in filterData" :key="index">
        <a
          class="articleBlock"
          :href="item.link"
          target="_blank"
          rel="noreferrer"
        >
          <div class="imgBlock"></div>
          <div class="contentWrap">
            <div class="dateBlock">
              <div class="day">{{ item.day }}</div>
              <div class="bottomBlock">
                <div class="year">{{ item.year }}.</div>
                <div class="month">{{ item.month }}</div>
              </div>
            </div>
            <div class="titleBlock">
              <div class="tag only">{{ item.tag }}</div>
              <div class="articleTitle">{{ item.title }}</div>
            </div>
          </div>
        </a>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.news-container {
  h1 {
    text-align: center;
    margin: 35px 0;
  }

  .news-list-container {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto 50px auto;

    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 80px;

    @media (max-width: $mobileDeviceWidth) {
      width: 90%;
      margin: 25px auto 35px auto;
      grid-gap: 30px;
      grid-template-columns: repeat(1, 1fr);
    }

    .list-grid {
      .articleBlock {
        display: inline-block;
        padding-bottom: 10px;
        border-bottom: 1px solid #b9b9b9;

        @media (max-width: $mobileDeviceWidth) {
          display: block;
          margin: 0 auto;
        }

        .imgBlock {
          position: relative;
          padding-bottom: 10px;
        }

        .tag {
          position: absolute;
          color: #363636;
          font-size: 14px;
          line-height: 21px;
          font-weight: 400;
          letter-spacing: 1px;
          background-color: #a0ddff;
          color: #363636;
          text-align: center;
          padding: 3px 5px;
        }

        .tag.only {
          position: initial;
          display: initial;
        }

        img {
          width: 100%;
        }
      }
    }
  }
}

.contentWrap {
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
}

.articleBlock .contentWrap .dateBlock {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px 10px 10px 0px;
  margin-right: 10px;
  border-right: 1px solid #b9b9b9;
}

.articleBlock .contentWrap .dateBlock .day {
  font-size: 30px;
  font-weight: bolder;
  color: #363636;
}

.articleBlock .contentWrap .dateBlock .bottomBlock {
  display: flex;
  font-size: 12px;
  color: #363636;
}

.articleBlock .contentWrap .titleBlock .tag.only {
  color: #363636;
  font-size: 14px;
  line-height: 21px;
  font-weight: 400;
  letter-spacing: 1px;
  background-color: #a0ddff;
  color: #363636;
  text-align: center;
  padding: 3px 5px;
  width: 90px;
}

.articleBlock .contentWrap .titleBlock .articleTitle {
  color: #363636;
  font-size: 16px;
  line-height: 28px;
  font-weight: 400;
  letter-spacing: 1px;
}

.investors-year {
  max-width: 1400px;
  margin: 0 auto;
  width: 90%;

  select {
    display: block;
    width: 150px;
    box-sizing: border-box;
    text-align: left;
    padding: 5px 10px;
    border: solid 1px #b9b9b9;
    border-radius: 3px;
  }
}
</style>
