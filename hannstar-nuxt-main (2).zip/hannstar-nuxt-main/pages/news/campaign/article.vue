<script setup>
import { useRoute } from "vue-router";
import { computed } from "vue";
import { useSingleNews } from "../../../composables/news/useSingleNews";
import { useNewsList } from "../../../composables/news/useNewsList";

const { data } = useSitemap();
const { t, locale } = useI18n();

//meta data
useMeta({ title: t("news-menu03") });

//抓當前語言
const language = computed(() => {
  switch (locale.value) {
    case "en":
      return "en";
    case "tw":
      return "zh-hant";
    case "cn":
      return "zh";
    default:
      return "tw";
  }
});

//抓當前語言來翻譯tag
const tagText = computed(() => {
  switch (locale.value) {
    case "en":
      return "Campaign";
    case "tw":
      return "活動訊息";
    case "cn":
      return "活动讯息";
    default:
      return "活動訊息";
  }
});

//從url抓取articleId
const route = useRoute();
const articleId = computed(() => route.query.articleId);

//post api打入的資料
const { fetchNews, news: newsList } = useNewsList();
const { singleNews, isLoading, error, fetchSingleNews } = useSingleNews();
const selectedData = ref(null);
// console.log(selectedData);

onMounted(async () => {
  await fetchNews("Campaign");
  // 用 articleId 找 postId 且 過濾語言
  const matchedArticle = newsList.value.data.find(
    (article) =>
      article.article_id === articleId.value &&
      article.language === language.value
  );
  // console.log(language.value);
  if (matchedArticle) {
    await fetchSingleNews(matchedArticle.id); // 使用 postId 調用 fetchSingleNews
    selectedData.value = singleNews.value;
    // console.log(matchedArticle.id);
  } else {
    console.error("No matching news found");
  }
});
</script>

<template>
  <div class="news-campaign-article-container">
    <Breadcrumbs
      :level-second="{ text: data[5].mainMenu, link: data[5].mainMenuLink }"
      :level-third="{
        text: data[5].subMenu[2].text,
        link: data[5].subMenu[2].link,
      }"
    ></Breadcrumbs>
    <!-- <TabNews :tab-active="2"></TabNews> -->

    <h1>{{ t("news-campaign-main-title") }}</h1>
    <div v-if="isLoading" class="loading"><img src="/loading.gif" /></div>
    <div v-else-if="error">{{ error.message }}</div>

    <div v-else-if="selectedData" class="content-container">
      <div class="content-tag">
        <div class="tag">{{ tagText }}</div>
        <div class="title-box">
          <div class="date">
            <div class="day">
              {{ new Date(selectedData.create_time).getDate() }}
            </div>
            <div class="ym">
              {{ new Date(selectedData.create_time).getFullYear() }}.{{
                String(
                  new Date(selectedData.create_time).getMonth() + 1
                ).padStart(2, "0")
              }}
            </div>
          </div>
          <h2>{{ selectedData.title }}</h2>
        </div>
      </div>
      <div class="content-text" v-html="selectedData.content"></div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.news-campaign-article-container {
  min-height: 1000px;
  padding-bottom: 30px;
  h1 {
    text-align: center;
    margin: 35px 0;
  }
  .content-container {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    .content-tag {
      padding-bottom: 20px;
      .tag {
        display: inline-block;
        background-color: #a0ddff;
        padding: 5px;
        border-radius: 8px;
        margin-bottom: 10px;
      }
      .title-box {
        display: flex;
        align-items: flex-start;
        .date {
          border-right: 2px solid #d3d3d3;
          padding-right: 10px;
          margin-right: 10px;
          .day {
            color: #878787;
            font-size: 2.5em;
          }
          .ym {
            color: #878787;
            font-size: 0.8em;
          }
        }
        h2 {
          font-size: 1.5em;
        }
      }
    }
    .content-text {
      padding: 15px 0;
    }
  }
  .loading {
    max-width: 100px;
    width: 100%;
    margin: 0 auto;
    min-height: 500px;
    padding: 200px 0;
  }
}
</style>
../../../composables/news/useNewsList
