<script setup>
import { useNewsList } from "../../../composables/news/useNewsList";

const { data } = useSitemap();
const { t, locale } = useI18n();

//meta data
useMeta({ title: t("news-menu03") });

//抓當前語言
const language = computed(() => {
  switch (locale.value) {
    case "en":
      return "en";
    case "tw":
      return "zh-hant";
    case "cn":
      return "zh";
    default:
      return "tw";
  }
});

//抓當前語言來翻譯tag
const tagText = computed(() => {
  switch (locale.value) {
    case "en":
      return "Campaign";
    case "tw":
      return "活動訊息";
    case "cn":
      return "活动讯息";
    default:
      return "活動訊息";
  }
});

//post api打入的資料
const { news, isLoading, error, fetchNews } = useNewsList();
const filterData = ref([]);

// 按日期排序
const sortData = (data) => {
  return data.sort((a, b) => {
    const dateA = new Date(a.create_time);
    const dateB = new Date(b.create_time);
    return dateB - dateA;
  });
};

// 打API並呼叫過濾功能
const fetchAndFilterNews = async () => {
  await fetchNews("Campaign");
  applyFilters();
};

// 語言與年份過濾
const applyFilters = () => {
  let filtered = news.value.data.filter(
    (item) => item.language === language.value
  );
  if (selectYear.value) {
    filtered = filtered.filter(
      (item) =>
        new Date(item.create_time).getFullYear().toString() === selectYear.value
    );
  }
  filterData.value = sortData(filtered);
};

onMounted(fetchAndFilterNews);

// 捕捉語言變換
watch(locale, fetchAndFilterNews);

// 年份過濾
const selectYear = ref("");
watch(selectYear, applyFilters);
</script>

<template>
  <div class="news-container">
    <Breadcrumbs
      :level-second="{ text: data[5].mainMenu, link: data[5].mainMenuLink }"
      :level-third="{
        text: data[5].subMenu[2].text,
        link: data[5].subMenu[2].link,
      }"
    ></Breadcrumbs>
    <TabNews :tab-active="2"></TabNews>

    <h1>{{ t("news-campaign-main-title") }}</h1>
    <div class="campaign-year">
      <select v-model="selectYear" @change="yearChange($event)">
        <option value="">Years</option>
        <option value="2024">2024</option>
        <option value="2023">2023</option>
        <option value="2022">2022</option>
        <option value="2021">2021</option>
        <option value="2020">2020</option>
      </select>
    </div>

    <div v-if="isLoading" class="loading"><img src="/loading.gif" /></div>
    <div v-else-if="error" class="error-message">{{ error.message }}</div>
    <div class="news-list-container">
      <div class="list-grid" v-for="(item, index) in filterData" :key="index">
        <a
          :href="`/${locale}/news/campaign/article?articleId=${item.article_id}`"
          class="articleBlock"
          rel="noreferrer"
        >
          <div class="imgBlock">
            <img :src="item.preview_image" />
            <div :class="`tag${item.preview_image ? '' : ' only'}`">
              {{ tagText }}
            </div>
          </div>
          <div class="contentWrap">
            <div class="dateBlock">
              <div class="day">{{ new Date(item.create_time).getDate() }}</div>
              <div class="bottomBlock">
                <div class="year">
                  {{ new Date(item.create_time).getFullYear() }}.
                </div>
                <div class="month">
                  {{
                    String(new Date(item.create_time).getMonth() + 1).padStart(
                      2,
                      "0"
                    )
                  }}
                </div>
              </div>
            </div>
            <div class="titleBlock">
              <div class="articleTitle">{{ item.title }}</div>
            </div>
          </div>
        </a>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.news-container {
  min-height: 1000px;
  h1 {
    text-align: center;
    margin: 35px 0;
  }

  .news-list-container {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto 50px auto;

    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 80px;

    @media (max-width: $mobileDeviceWidth) {
      width: 90%;
      margin: 25px auto 35px auto;
      grid-gap: 30px;
      grid-template-columns: repeat(1, 1fr);
    }

    .list-grid {
      .articleBlock {
        display: inline-block;
        padding-bottom: 10px;
        border-bottom: 1px solid #b9b9b9;

        @media (max-width: $mobileDeviceWidth) {
          display: block;
          margin: 0 auto;
        }

        .imgBlock {
          position: relative;
          padding-bottom: 10px;
        }

        .tag {
          position: absolute;
          top: 0;
          left: 0;
          color: #363636;
          font-size: 14px;
          line-height: 21px;
          font-weight: 400;
          letter-spacing: 1px;
          background-color: #a0ddff;
          color: #363636;
          text-align: center;
          padding: 3px 5px;
        }

        .tag.only {
          position: initial;
          display: initial;
        }

        img {
          width: 100%;
          max-height: 235px;
          object-fit: cover;
        }
      }
    }
  }
  .loading {
    max-width: 100px;
    width: 100%;
    margin: 0 auto;
    min-height: 500px;
    padding: 200px 0;
  }
}

.contentWrap {
  display: flex;
  align-items: flex-start;
}

.articleBlock .contentWrap .dateBlock {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px 10px 10px 0px;
  margin-right: 10px;
  border-right: 1px solid #b9b9b9;
}

.articleBlock .contentWrap .dateBlock .day {
  font-size: 30px;
  font-weight: bolder;
  color: #363636;
}

.articleBlock .contentWrap .dateBlock .bottomBlock {
  display: flex;
  font-size: 12px;
  color: #363636;
}

.articleBlock .contentWrap .titleBlock .tag.only {
  color: #363636;
  font-size: 14px;
  line-height: 21px;
  font-weight: 400;
  letter-spacing: 1px;
  background-color: #a0ddff;
  color: #363636;
  text-align: center;
  padding: 3px 5px;
  width: 90px;
}

.articleBlock .contentWrap .titleBlock .articleTitle {
  color: #363636;
  font-size: 16px;
  line-height: 28px;
  font-weight: 400;
  letter-spacing: 1px;
}

.campaign-year {
  max-width: 1400px;
  margin: 0 auto;
  width: 90%;

  select {
    display: block;
    width: 150px;
    box-sizing: border-box;
    text-align: left;
    padding: 5px 10px;
    border: solid 1px #b9b9b9;
    border-radius: 3px;
  }
}
.error-message {
  display: flex;
  justify-content: center;
}
</style>
