<template>
    <div>
        <NuxtPage></NuxtPage>
    </div>
</template>
<style lang="scss">
.hannstar-news-body {
    h1 {
        text-align: center;
        max-width: 1400px;
        width: 100%;
        margin: 0 auto 50px auto;
    }
}
</style>
