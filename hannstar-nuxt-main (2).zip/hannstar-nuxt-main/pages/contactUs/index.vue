<script setup>
import { useContactUs } from "#imports";

definePageMeta({ path: "index", alias: [""] });
const { t, locale } = useI18n();

//meta data
useMeta({ title: t("contact-us") });

const { postContactUsApi } = useContactUs();

const contactType = ref("");
const contactName = ref("");
const contactSex = ref("");
const contactPhone = ref("");
const contactMobile = ref("");
const contactEmail = ref("");
const contactComment = ref("");
const isLoading = ref(false);
const isError = ref(false);
const showErrorMessage = ref("");

// Google Recaptcha Script
const siteKey = "6LdMYQ4nAAAAAOCTV3KCU3KcFtK7gtAn33G_m1bC";
onMounted(() => {
  if (process.client) {
    const googleRecaptchaScript = document.createElement("script");
    googleRecaptchaScript.src = `https://www.google.com/recaptcha/enterprise.js?render=${siteKey}`;
    googleRecaptchaScript.async = true;
    document.body.appendChild(googleRecaptchaScript);
  }
});

//抓當前語言來call api
const language = computed(() => {
  switch (locale.value) {
    case "en":
      return "en";
    case "tw":
      return "zh-hant";
    case "cn":
      return "zh";
    default:
      return "tw";
  }
});

const validateEmail = () => {
  const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
  if (!emailRegex.test(contactEmail.value)) {
    // setEmailError(true);
    return false;
  } else {
    // setEmailError(false);
    return true;
  }
};

const postContactUs = async () => {
  let postData = {
    functionName: "initProcessData",
    packageName: "custom.WebCom.WebRESTful",
    keyValue: [
      { processId: "PRO09661690945266954" },
      { opener: "Administrator" },
      { "api-key": "ABxGGEDBsd6123DXjdX1xdXX1" },
      {
        data: {
          DataCategoryTitle: contactType.value,
          Language: language.value,
          DataName: contactName.value,
          DataSex: contactSex.value,
          DataTelephone: contactPhone.value,
          DataMobiePhone: contactMobile.value,
          DataEmail: contactEmail.value,
          DataExp: contactComment.value,
        },
      },
    ],
  };

  if (
    contactType.value === "" ||
    contactName.value === "" ||
    contactMobile.value === "" ||
    contactEmail.value === "" ||
    contactComment.value === ""
  ) {
    isError.value = true;
    showErrorMessage.value = t("contactUs-index-error-massage01");
    console.log("錯誤: ", showErrorMessage.value);
    return;
  } else if (!validateEmail()) {
    isError.value = true;
    showErrorMessage.value = t("contactUs-index-error-massage02");
    console.log("錯誤: ", showErrorMessage.value);
    return;
  } else if (contactMobile.value.length !== 10) {
    isError.value = true;
    showErrorMessage.value = t("contactUs-index-error-massage03");
    console.log("錯誤: ", showErrorMessage.value);
    return;
  }

  const postKey = "LAmsduWSX36T7Z7sXTtKW6YdVuBWQwHcQ8KbCRA2";

  if (validateEmail() && contactMobile.value.length === 10) {
    isLoading.value = true;
    try {
      await postContactUsApi(postData, postKey);
      // console.log("ALL: ", postData);
      // console.log("key:", postKey);
      // console.log("傳輸數據: ", postData.keyValue[3]);
    } catch (error) {
      isError.value = true;
      showErrorMessage.value = t("contactUs-index-error-massage05");
      console.log("錯誤: ", error);
    } finally {
      isLoading.value = false;
    }
  }
};
</script>
<template>
  <div class="contactUs-container">
    <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/contact/banner1.png'"
      :banner-title="''"
      :banner-text="''"
      :banner-height-max="400"
    ></TopBanner>
    <div class=""></div>

    <div class="contactUs-mian-title">
      <div class="title-wrapper">
        <h1 class="ph-15">{{ t("contactUs-index-main-title") }}</h1>
      </div>
    </div>

    <section>
      <div class="ph-15">
        <div class="form-message">
          <p>{{ t("contactUs-index-main-text") }}</p>
        </div>
      </div>
      <div v-if="isError" class="error-message">{{ showErrorMessage }}</div>
      <form @submit.prevent="postContactUs">
        <div class="ph-15">
          <div class="form-field type-field">
            <label class="min-width-wrap"
              >{{ t("contactUs-index-field01") }}*</label
            >
            <select v-model="contactType">
              <option disabled selected value="">
                {{ t("contactUs-index-field01-option01") }}
              </option>
              <option :value="t('contactUs-index-field01-option02')">
                {{ t("contactUs-index-field01-option02") }}
              </option>
              <option :value="t('contactUs-index-field01-option03')">
                {{ t("contactUs-index-field01-option03") }}
              </option>
              <option :value="t('contactUs-index-field01-option04')">
                {{ t("contactUs-index-field01-option04") }}
              </option>
              <option :value="t('contactUs-index-field01-option05')">
                {{ t("contactUs-index-field01-option05") }}
              </option>
              <option :value="t('contactUs-index-field01-option06')">
                {{ t("contactUs-index-field01-option06") }}
              </option>
              <option :value="t('contactUs-index-field01-option07')">
                {{ t("contactUs-index-field01-option07") }}
              </option>
            </select>
          </div>
        </div>

        <div class="flex-wrap">
          <div class="input-wrap">
            <div class="form-field name-field">
              <label class="min-width-wrap"
                >{{ t("contactUs-index-field02") }}*</label
              >
              <input type="text" v-model="contactName" required />
              <div class="gender-wrap">
                <label class="no-border-right"
                  ><input
                    type="radio"
                    name="data_sex"
                    v-model="contactSex"
                    value="Mr"
                  />
                  <p>{{ t("contactUs-index-field02-gender01") }}</p></label
                >
                <label class="no-border-right"
                  ><input
                    type="radio"
                    name="data_sex"
                    v-model="contactSex"
                    value="Ms"
                  />
                  <p>{{ t("contactUs-index-field02-gender02") }}</p></label
                >
              </div>
            </div>
            <div class="form-field mobile-field">
              <label>{{ t("contactUs-index-field03") }}*</label>
              <input type="text" v-model="contactMobile" required />
            </div>
          </div>
          <div class="input-wrap">
            <div class="form-field contact-field">
              <label class="min-width-wrap">{{
                t("contactUs-index-field04")
              }}</label>
              <input type="text" v-model="contactPhone" />
            </div>
            <div class="form-field email-field">
              <label class="min-width-wrap"
                >{{ t("contactUs-index-field05") }}*</label
              >
              <input type="text" v-model="contactEmail" required />
            </div>
          </div>
        </div>
        <div class="ph-15">
          <div class="form-field-no-flex description-field">
            <div class="label w-100">{{ t("contactUs-index-field06") }}*</div>
            <div class="p-5">
              <textarea
                class="w-100"
                type="text"
                v-model="contactComment"
              ></textarea>
            </div>
          </div>
        </div>

        <div class="button-wrap">
          <button type="submit">{{ t("contactUs-index-button") }}</button>
        </div>
      </form>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.contactUs-container {
  section {
    max-width: 1400px;
    width: 100%;
    margin: 0 auto;
    .form-message {
      padding: 40px 0;
    }
    form {
      margin-bottom: 60px;
      .flex-wrap {
        display: flex;
        align-items: center;
        width: 100%;
        .input-wrap {
          width: 50%;
          padding: 0 15px;
          @media screen and (max-width: 980px) {
            width: 100%;
          }
        }
      }
      .button-wrap {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 30px 0;
        button {
          padding: 10px 30px;
          color: #0094da;
          background-color: #fff;
          border: 1px solid #0094da;
          transition: all 0.5s ease-out;
          &:hover {
            color: #fff;
            background-color: #0094da;
          }
        }
      }
    }
    .form-field {
      display: flex;
      border: 1px solid #ddd;
      padding: 5px 10px;
      align-items: center;
      margin-bottom: 15px;
      .gender-wrap {
        display: flex;
        align-items: center;
        @media screen and (max-width: 480px) {
          position: absolute;
          right: 20px;
        }
      }
      select {
        height: 2.5em;
        flex-grow: 1;
        padding-left: 10px;
        outline: none;
      }
      input {
        height: 2.5em;
        flex-grow: 1;
        padding-left: 10px;
        outline: none;
      }
      label {
        display: flex;
        align-items: center;
        border-right: 1px solid #ddd;
        padding-right: 10px;
        &.min-width-wrap {
          min-width: 82px;
        }
        &.no-border-right {
          border: none;
        }
        p {
          padding-left: 5px;
        }
      }
    }
    .form-field-no-flex {
      border: 1px solid #ddd;
      padding: 10px;
      align-items: center;
      .label {
        padding-bottom: 10px;
      }
      textarea {
        height: 200px;
        border: 1px solid #fff;
        outline: none;
        transition: all 0.5s ease-out;
        &:focus {
          box-shadow: 0 0 3px 1px #68a8e0;
        }
      }
    }
  }
  .contactUs-mian-title {
    border-bottom: 1px solid #e2e2e3;
    .title-wrapper {
      max-width: 1400px;
      width: 100%;
      margin: 0 auto;
      h1 {
        @media screen and (max-width: 980px) {
          text-align: center;
          font-size: 1.5em;
        }
      }
    }
  }
}
.error-message {
  color: red;
  padding: 0 15px 15px 15px;
}
.w-100 {
  width: 100%;
}
.w-50 {
  width: 50%;
}
.p-5 {
  padding: 5px;
}
.ph-15 {
  padding: 0 15px;
}
.mb-15 {
  margin-bottom: 15px;
}
</style>
