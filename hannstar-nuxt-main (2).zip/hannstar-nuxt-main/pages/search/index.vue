<script setup>
//搜尋功能使用fuse.js
import Fuse from "fuse.js";
import list_tw from "./list_tw.json";
import list_cn from "./list_cn.json";
import list_en from "./list_en.json";
import { ref, computed } from "vue";
import { useI18n } from "vue-i18n";

const localePath = useLocalePath();
const { t, locale } = useI18n();

//meta data
useMeta({ title: t("site-search") });

const fuseOptions = {
  // isCaseSensitive: false,
  // includeScore: false,
  // shouldSort: true,
  // includeMatches: false,
  // findAllMatches: false,
  // minMatchCharLength: 1,
  // location: 0,
  // threshold: 0.6,
  // distance: 100,
  // useExtendedSearch: false,
  // ignoreLocation: false,
  // ignoreFieldNorm: false,
  // fieldNormWeight: 1,
  keys: ["page", "keywords", "content"],
};

const dataList = computed(() => {
  switch (locale.value) {
    case "en":
      return list_en;
    case "cn":
      return list_cn;
    case "tw":
    default:
      return list_tw;
  }
});

const fuse = computed(() => new Fuse(dataList.value, fuseOptions));

const searchInput = ref("");

// 根據input輸出搜尋結果
const searchResult = computed(() => {
  return searchInput.value
    ? fuse.value.search(searchInput.value).map((result) => result.item)
    : [];
});

//分頁: 六筆數據為一頁
const itemsPerPage = 6;
const currentPage = ref(1);

const totalItems = computed(() => {
  return searchResult.value.length;
});

const totalPages = computed(() => {
  return Math.ceil(totalItems.value / itemsPerPage);
});

const paginatedResult = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return searchResult.value.slice(start, end);
});

function goToPage(page) {
  currentPage.value = page;
}

//頁籤: 至多五頁
const visiblePages = computed(() => {
  let pages = [];
  let start = Math.max(currentPage.value - 2, 1);
  let end = Math.min(start + 4, totalPages.value);

  if (end === totalPages.value) {
    start = Math.max(1, end - 4);
  }

  for (let i = start; i <= end; i++) {
    pages.push(i);
  }

  return pages;
});
</script>

<template>
  <div class="search-page-container">
    <div>
      <div class="search-top-banner">
        <div class="image" :class="searchInput ? ' active' : ''">
          <img
            src="https://media.hannstar.com/Image/hannstar/about/Profile/HannStarVision.jpg"
            alt="Hannstar Search"
          />
        </div>
        <div class="text" :class="searchInput ? ' active' : ''">
          <h1>{{ t("search-main-title") }}</h1>
        </div>
        <div class="search-field" :class="searchInput ? ' active' : ''">
          <form>
            <input
              type="text"
              id="searchPhrase"
              placeholder="Search HannStar"
              v-model="searchInput"
            />
            <button
              v-if="searchInput"
              class="clear-input"
              type="button"
              @click="searchInput = ''"
            >
              ✖
            </button>
          </form>
        </div>
      </div>

      <div class="search-result">
        <div v-if="searchInput" class="search-result-title">
          <h3>{{ t("search-search-result") }}</h3>
        </div>
        <div
          v-if="searchInput && searchResult.length === 0"
          class="no-result-found"
        >
          <img
            src="https://media.hannstar.com/Image/algolia/img_cs_search_nrf.png"
            alt="no result found"
          />
        </div>
        <div v-else>
          <ul>
            <li v-for="(v, index) in paginatedResult" :key="index">
              <NuxtLink :to="localePath(`${v.link}`)">
                <h4>{{ v.page }}</h4>
                <p>{{ v.content }}</p>
                <p class="read-more">{{ t("search-read-more") }} ›</p>
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="pagination" v-if="searchResult.length !== 0">
      <button @click="goToPage(1)" :disabled="currentPage === 1">‹‹</button>
      <button @click="goToPage(currentPage - 1)" :disabled="currentPage <= 1">
        ‹
      </button>
      <button
        v-for="page in visiblePages"
        :key="page"
        :class="{ active: currentPage === page }"
        @click="goToPage(page)"
      >
        {{ page }}
      </button>

      <button
        @click="goToPage(currentPage + 1)"
        :disabled="currentPage >= totalPages"
      >
        ›
      </button>
      <button
        @click="goToPage(totalPages)"
        :disabled="currentPage === totalPages"
      >
        ››
      </button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.search-page-container {
  .search-top-banner {
    .text {
      position: absolute;
      top: 30%;
      left: 50%;
      transform: translate(-50%, -50%);
      transition: top 0.5s ease-in-out;
      @media screen and (max-width: 980px) {
        top: 25%;
      }
      &.active {
        top: 20%;
      }
      h1 {
        color: #fff;
        @media screen and (max-width: 768px) {
          font-size: 1.5em;
        }
      }
    }
    .search-field {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      transition: top 0.5s ease-in-out;
      &::before {
        content: "";
        position: absolute;
        left: 20px;
        top: 50%;
        transform: translateY(-50%);
        width: 24px;
        height: 24px;
        background-image: url("https://media.hannstar.com/Image/hannstar/scope-gray.png");
        background-size: cover;
      }
      &.active {
        top: 30%;
        @media screen and (max-width: 980px) {
          top: 28%;
        }
      }
      @media screen and (max-width: 980px) {
        top: 48%;
      }
      input {
        width: 1000px;
        height: 60px;
        outline: none;
        border: 1px solid #fafafa;
        border-radius: 50px;
        padding: 0 30px 0 60px;
        box-shadow: 0 4px 11px -2px rgba(37, 44, 97, 0.15),
          0 1px 3px 0 rgba(93, 100, 148, 0.2);
        @media screen and (max-width: 1080px) {
          width: 500px;
        }
        @media screen and (max-width: 768px) {
          width: 300px;
        }
      }
      .clear-input {
        position: absolute;
        top: 15px;
        right: 20px;
        color: #666;
        font-size: 1.5em;
      }
    }
    .image {
      position: relative;
      &::before {
        content: "";
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: linear-gradient(
          280deg,
          rgba(3, 155, 229, 0.5) 0%,
          rgba(9, 89, 162, 0.5) 60%,
          rgba(8, 46, 116, 0.5) 100%
        );
      }
      &.active {
        img {
          height: 20vh;
        }
      }
      img {
        width: 100%;
        object-fit: cover;
        height: 40vh;
        z-index: -1;
        transition: height 0.5s ease-in-out;
      }
    }
  }
  .search-result {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    min-height: 550px;
    padding: 60px 120px;
    @media screen and (max-width: 768px) {
      padding: 60px 0;
    }
    .search-result-title {
      padding-bottom: 20px;
      margin-bottom: 40px;
      border-bottom: 2px solid #e3d9d9;
      @media screen and (max-width: 980px) {
        padding-top: 20px;
      }
    }
    ul {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      grid-gap: 30px;
      @media screen and (max-width: 768px) {
        grid-template-columns: repeat(1, 1fr);
      }
      li {
        h4 {
          line-height: 1.8;
          word-break: break-all;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          overflow: hidden;
          padding-bottom: 10px;
          &::before {
            content: "•";
            color: #1781cd;
            margin-right: 5px;
          }
        }
        p {
          line-height: 1.8;
          word-break: break-all;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
          padding-left: 25px;
        }
        .read-more {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          color: #1781cd;
          &:hover {
            text-decoration: underline;
          }
        }
      }
    }
    .no-result-found {
      display: flex;
      justify-content: center;
      align-items: center;
      img {
        padding: 30px 0;
      }
    }
  }

  .pagination {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    text-align: right;
    padding: 0 120px 40px 0;
    @media screen and (max-width: 768px) {
      text-align: center;
      padding: 0 0 40px 0;
    }
    button {
      background-color: #f6f6f6;
      margin: 0 10px;
      padding: 8px 10px;
      border: 1px solid #f6f6f6;
      border-radius: 5px;
      box-shadow: 0 4px 11px -2px rgba(37, 44, 97, 0.15),
        0 1px 3px 0 rgba(93, 100, 148, 0.2);
      &.active {
        color: #fff;
        background-color: #039be5;
        border: 1px solid #039be5;
      }
      @media screen and (max-width: 768px) {
        margin: 0 8px;
      }
    }
  }
}
</style>
