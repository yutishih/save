<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("career-menu01") });
</script>

<template>
  <div class="careers-container">
    <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/careers/work/Group6341.png'"
      :banner-title="t('careers-work-top-banner-text')"
      :banner-text="''"
      :banner-height-max="400"
    ></TopBanner>

    <Breadcrumbs
      :level-second="{ text: data[4].mainMenu, link: data[4].mainMenuLink }"
      :level-third="{
        text: data[4].subMenu[0].text,
        link: data[4].subMenu[0].link,
      }"
    ></Breadcrumbs>

    <h1>{{ t("careers-work-main-title") }}</h1>
    <h5>{{ t("careers-work-main-text") }}</h5>
    <section class="section-wrapper section-one" data-aos="fade-up">
      <div class="item content-0">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1903.png"
          alt="生態綠化環境"
        />
        <span class="text">{{ t("careers-work-block01") }}</span>
      </div>
      <div class="item content-1">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1902.png"
          alt="員工餐廳與便利商店"
        />
        <span class="text">{{ t("careers-work-block02") }}</span>
      </div>
      <div class="item content-2">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1901.png"
          alt="優質團膳"
        />
        <span class="text">{{ t("careers-work-block03") }}</span>
      </div>
      <div class="item content-3">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1904.png"
          alt="員工宿舍"
        />
        <span class="text">{{ t("careers-work-block04") }}</span>
      </div>
      <div class="item content-4">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1905.png"
          alt="社團活動"
        />
        <span class="text">{{ t("careers-work-block05") }}</span>
      </div>
      <div class="item content-5">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1906.png"
          alt="交通路網"
        />
        <span class="text">{{ t("careers-work-block06") }}</span>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="careers-page-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1888.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2>{{ t("careers-work-subtitle01") }}</h2>
          <p>
            {{ t("careers-work-text01") }}
          </p>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="careers-page-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/Rectangle1889.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2>{{ t("careers-work-subtitle02") }}</h2>
          <p>
            {{ t("careers-work-text02") }}
          </p>
        </div>
      </div>
    </section>

    <h2>{{ t("careers-work-subtitle03") }}</h2>

    <section class="careers-page-flex" data-aos="fade-up">
      <div class="careers-flexbox">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/image514.png"
          alt=""
        />
        <div class="careers-flexbox-content">
          <h5>{{ t("careers-work-subtitle03-point01-title") }}</h5>
          <p>{{ t("careers-work-subtitle03-point01-text") }}</p>
        </div>
      </div>
      <div class="careers-flexbox">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/image515.png"
          alt=""
        />
        <div class="careers-flexbox-content">
          <h5>{{ t("careers-work-subtitle03-point02-title") }}</h5>
          <p>
            {{ t("careers-work-subtitle03-point02-text") }}
          </p>
        </div>
      </div>
      <div class="careers-flexbox">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/work/image516.png"
          alt=""
        />
        <div class="careers-flexbox-content">
          <h5>{{ t("careers-work-subtitle03-point03-title") }}</h5>
          <p>
            {{ t("careers-work-subtitle03-point03-text") }}
          </p>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.careers-container {
  h1 {
    text-align: center;
    margin-bottom: 50px;
  }

  h2 {
    text-align: center;
    margin-bottom: 50px;
  }

  h5 {
    margin-bottom: 50px;
    text-align: center;
  }

  section {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto 50px auto;
    gap: 40px;
  }

  .section-one {
    display: grid;
    grid-template-columns: 3fr 1fr 1fr 1fr 1fr 1fr 1fr;
    grid-template-rows: 250px 200px;
    gap: 20px 20px;
    grid-template-areas:
      "content-0 content-1 content-1 content-1 content-2 content-2 content-2"
      "content-0 content-3 content-3 content-4 content-4 content-5 content-5";

    @media (max-width: $mobileDeviceWidth) {
      grid-template-rows: auto auto auto;
      grid-template-columns: 1fr 1fr;
      gap: 10px 10px;
      grid-template-rows: repeat(3, 30%);
      grid-template-areas:
        "content-0 content-1 "
        "content-2 content-3 "
        "content-4 content-5";
    }

    .item {
      display: flex;
      position: relative;

      img {
        width: 100%;
        object-fit: cover;
      }

      span.text {
        color: #363636;
        font-size: 20px;
        font-weight: 400;
        line-height: 30px;
        letter-spacing: 1px;
        color: #fff;
        position: absolute;
        bottom: 20px;
        left: 10px;
        text-shadow: 1px 1px 2px #363636;
      }
    }

    .content-0 {
      grid-area: content-0;
    }

    .content-1 {
      grid-area: content-1;
    }

    .content-2 {
      grid-area: content-2;
    }

    .content-3 {
      grid-area: content-3;
    }

    .content-4 {
      grid-area: content-4;
    }

    .content-5 {
      grid-area: content-5;
    }
  }

  .careers-page-banner {
    position: relative;

    img {
      width: 100%;
      object-fit: cover;
      max-height: 400px;
    }

    .hannstar-page-banner-text {
      position: absolute;
      width: 700px;
      box-sizing: border-box;
      left: 7.5%;
      bottom: 15%;

      @media (max-width: $mobileDeviceWidth) {
        background-color: #a0ddff;
        position: relative;
        width: 100%;
        left: 0;
        bottom: 0;
        padding: 20px;
        box-sizing: border-box;
      }

      h2 {
        color: #000;
        margin-bottom: 25px;
        line-height: 1.5;
        text-shadow: 1px 1px 2px #fff;
        text-align: left;

        &.black-color {
          color: #000;
          text-shadow: 1px 1px 2px #fff;
        }
      }

      p {
        color: #000;
        line-height: 24px;
        letter-spacing: 0.14px;
      }

      button {
        display: inline-block;
        background-color: #039be5;
        border-radius: 4px;
        color: #fff;
        font-size: 16px;
        line-height: 1;
        padding: 12px 16px;
        word-break: keep-all;
        cursor: pointer;
        margin-top: 20px;
        text-align: center;
      }
    }
  }

  .careers-page-flex {
    display: flex;
    justify-content: space-between;

    @media (max-width: $mobileDeviceWidth) {
      flex-direction: column;
    }

    .careers-flexbox {
      max-width: 400px;
      box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2);
      width: 100%;
      margin: 0 auto;

      .careers-flexbox-content {
        padding: 40px 20px;
        box-sizing: border-box;

        h5 {
          font-size: 1.2em;
          text-align: center;
          margin: 15px auto;
          color: $textLinkColor;
        }

        p {
          font-size: 0.9em;
        }
      }
    }
  }
}
</style>
