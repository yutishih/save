<script setup>
definePageMeta({ path: "index" });
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("careers-title") });
</script>

<template>
  <div class="careers-container">
    <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/careers/recruit/Group6338.png'"
      :banner-title="t('careers-index-top-banner-text')"
      :banner-text="''"
      :banner-height-max="400"
    ></TopBanner>

    <Breadcrumbs
      :level-second="{ text: data[4].mainMenu, link: data[4].mainMenuLink }"
    ></Breadcrumbs>
    <h1>{{ t("careers-index-main-title") }}</h1>

    <section data-aos="fade-up">
      <div class="careers-page-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/recruit/Group6339.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2>
            {{ t("careers-index-banner-text01") }}
          </h2>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="careers-page-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/recruit/image503.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2>
            {{ t("careers-index-banner-text02") }}
          </h2>
          <button>{{ t("careers-index-banner-cta02") }}</button>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="careers-page-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/recruit/Group6340.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2 class="black-color">
            {{ t("careers-index-banner-text03") }}
          </h2>
          <button>{{ t("careers-index-banner-cta03") }}</button>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="careers-page-banner">
        <img
          src="https://media.hannstar.com/Image/hannstar/careers/recruit/image501.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2 class="black-color">
            {{ t("careers-index-banner-text04") }}
          </h2>
          <button>{{ t("careers-index-banner-cta04") }}</button>
        </div>
      </div>
    </section>
  </div>
</template>
<style lang="scss" scoped>
.careers-container {
  h1 {
    text-align: center;
    margin: 35px auto 50px auto;
  }

  section {
    max-width: 1400px;
    width: 100%;
    margin: 0 auto 50px auto;
  }
}

.careers-page-banner {
  position: relative;
  width: 90%;
  margin: 0 auto;

  img {
    width: 100%;
    object-fit: cover;
  }

  .hannstar-page-banner-text {
    position: absolute;
    width: 700px;
    box-sizing: border-box;
    left: 7.5%;
    bottom: 10%;

    @media screen and (max-width: $mobileDeviceWidth) {
      position: relative;
      background-color: #a0ddff;
      left: 0;
      bottom: 0;
      width: 100%;
      padding: 20px 20px;
      box-sizing: border-box;
    }

    h2 {
      color: #fff;
      margin-bottom: 25px;
      text-shadow: 1px 1px 1px #000;
      line-height: 1.5;

      &.black-color {
        color: #000;
        text-shadow: none;
      }

      @media screen and (max-width: $mobileDeviceWidth) {
        font-size: 1.3em;
        margin: 0;
      }
    }

    p {
      color: #fff;
      line-height: 24px;
      letter-spacing: 0.14px;
      text-shadow: 1px 1px 1px #8f8f8f;
    }

    button {
      display: inline-block;
      background-color: #039be5;
      border-radius: 4px;
      color: #fff;
      font-size: 16px;
      line-height: 1;
      padding: 12px 16px;
      word-break: keep-all;
      cursor: pointer;
      margin-top: 20px;
      text-align: center;
    }
  }
}
</style>
