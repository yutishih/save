<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("career-menu03") });

const chooseTab = ref(0);

const chooseTabEvent = (i) => {
  chooseTab.value = i;
};
</script>

<template>
  <div class="careers-container">
    <!-- <TopBanner
      :img-link="'https://media.hannstar.com/Image/hannstar/careers/join/Group6344.png'"
      :banner-title="'人才，是企業面對激烈競爭環境時，最能展現力量的優勢之一，期待創新、熱情、勇於突破的你加入我們的團隊'"
      :banner-text="''"
      :banner-height-max="300"
    ></TopBanner> -->
    <div class="careers-top-banner">
      <h1>
        {{ t("careers-join-top-banner-text") }}
      </h1>
    </div>

    <Breadcrumbs
      :level-second="{ text: data[4].mainMenu, link: data[4].mainMenuLink }"
      :level-third="{
        text: data[4].subMenu[2].text,
        link: data[4].subMenu[2].link,
      }"
    ></Breadcrumbs>

    <section data-aos="fade-up">
      <div class="section-flex">
        <div class="join-body-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle2504sm.png"
            alt=""
          />
        </div>
        <div class="join-body-content">
          <h2>{{ t("careers-join-subtitle01") }}</h2>
          <p>
            {{ t("careers-join-text01") }}
          </p>

          <a
            href="https://www.104.com.tw/company/7k27b1c?roleJobCat=0_0&area=0&page=2&pageSize=40&tab=job"
            target="_blank"
          >
            {{ t("careers-join-cta01") }}
          </a>
        </div>
      </div>
    </section>
    <section data-aos="fade-up">
      <div class="section-flex">
        <div class="join-body-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle1918.png"
            alt=""
          />
        </div>
        <div class="join-body-content">
          <h2>{{ t("careers-join-subtitle02") }}</h2>
          <p>
            {{ t("careers-join-text02") }}
          </p>

          <a
            href="https://www.104.com.tw/company/7k27b1c?roleJobCat=0_0&area=0&page=2&pageSize=40&tab=job"
            target="_blank"
          >
            {{ t("careers-join-cta02") }}
          </a>
        </div>
      </div>
    </section>

    <h2>{{ t("careers-join-subtitle03") }}</h2>
    <section class="interview-process" data-aos="fade-up">
      <a class="process-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/image503.png"
            alt=""
          />
          <div class="contentWrap">
            <div class="articleTitle">{{ t("careers-join-step01-title") }}</div>
            <div class="date">{{ t("careers-join-step01-subtitle") }}</div>
            <div class="description">
              <ul class="content">
                <li>{{ t("careers-join-step01-text") }}</li>
              </ul>
            </div>
          </div>
        </div>
      </a>
      <a class="process-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/image506.png"
            alt=""
          />
          <div class="contentWrap">
            <div class="articleTitle">{{ t("careers-join-step02-title") }}</div>
            <div class="date">{{ t("careers-join-step02-subtitle") }}</div>
            <div class="description">
              <ul class="content">
                <li>
                  {{ t("careers-join-step02-text") }}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </a>
      <a class="process-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/image509.png"
            alt=""
          />
          <div class="contentWrap">
            <div class="articleTitle">{{ t("careers-join-step03-title") }}</div>
            <div class="date"></div>
            <div class="description">
              <ul class="content">
                <li>{{ t("careers-join-step03-text_1") }}</li>
                <li>{{ t("careers-join-step03-text_2") }}</li>
                <li>{{ t("careers-join-step03-text_3") }}</li>
              </ul>
            </div>
          </div>
        </div>
      </a>
      <a class="process-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/image512.png"
            alt=""
          />
          <div class="contentWrap">
            <div class="articleTitle">{{ t("careers-join-step04-title") }}</div>
            <div class="date"></div>
            <div class="description">
              <ul class="content">
                <li></li>
              </ul>
            </div>
          </div>
        </div>
      </a>
      <a class="process-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/image513.png"
            alt=""
          />
          <div class="contentWrap">
            <div class="articleTitle">{{ t("careers-join-step05-title") }}</div>
            <div class="date"></div>
            <div class="description">
              <ul class="content">
                <li>{{ t("careers-join-step05-text") }}</li>
              </ul>
            </div>
          </div>
        </div>
      </a>
      <a class="process-box">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/image514.png"
            alt=""
          />
          <div class="contentWrap">
            <div class="articleTitle">{{ t("careers-join-step06-title") }}</div>
            <div class="date"></div>
            <div class="description">
              <ul class="content">
                <li>
                  {{ t("careers-join-step06-text") }}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </a>
    </section>

    <h2>{{ t("careers-join-subtitle04") }}</h2>

    <div class="join-tab" data-aos="fade-up">
      <span
        :class="chooseTab === 0 ? 'active' : ''"
        @click="chooseTabEvent(0)"
        >{{ t("careers-join-tab01") }}</span
      >
      <span
        :class="chooseTab === 1 ? 'active' : ''"
        @click="chooseTabEvent(1)"
        >{{ t("careers-join-tab02") }}</span
      >
    </div>

    <!-- TAB 臺北 -->
    <section v-show="chooseTab === 0" class="list-wrapper" data-aos="fade-up">
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle292.png"
            alt="全球車載業務"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab01-job01-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab01-job01-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7ygzu?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7ygzu?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle293.png"
            alt="全球工控業務"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab01-job02-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab01-job02-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7g16l?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7g16l?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle296.png"
            alt="工控/車載PM工程師"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab01-job03-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab01-job03-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7c95v?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7c95v?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle295.png"
            alt="系統軟體工程師"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab01-job04-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab01-job04-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7dvi8?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7dvi8?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
    </section>
    <!-- TAB 臺南 -->
    <section v-show="chooseTab === 1" class="list-wrapper" data-aos="fade-up">
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle296.png"
            alt="全球車載業務"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab02-job01-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab02-job01-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7tq0l?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7tq0l?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle295.png"
            alt="全球工控業務"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab02-job02-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab02-job02-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7tq0l?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7tq0l?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle296.png"
            alt="工控/車載PM工程師"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab02-job03-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab02-job03-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7tprs?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7tprs?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
      <div class="productBlock">
        <div class="imgBlock">
          <img
            src="https://media.hannstar.com/Image/hannstar/careers/join/Rectangle295.png"
            alt="系統軟體工程師"
          />
        </div>
        <div class="contentWrap">
          <div class="productTitle">
            {{ t("careers-join-tab02-job04-title") }}
          </div>
          <div class="productContent">
            {{ t("careers-join-tab02-job04-text") }}
          </div>
          <div class="btnBlock">
            <a
              class="btn1"
              href="https://www.104.com.tw/job/7tpvd?jobsource=company_job"
              >{{ t("careers-join-tab-check") }}</a
            ><a
              class="btn2"
              href="https://www.104.com.tw/job/7tpvd?jobsource=company_job"
              >{{ t("careers-join-tab-apply") }}</a
            >
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.careers-container {
  h1 {
    text-align: center;
    margin-bottom: 50px;
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
  }

  section {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto 50px auto;
  }

  .careers-top-banner {
    background-image: url("https://media.hannstar.com/Image/hannstar/careers/join/Group6344.png");
    height: 400px;
    display: block;
    width: 100%;
    background-size: cover;
    background-position: center;
    position: relative;

    h1 {
      position: absolute;
      bottom: 2.5%;
      left: 5%;
      max-width: 550px;
      text-align: left;
      font-size: 2em;
      line-height: 1.5;
      width: 90%;
      color: #363636;
      text-shadow: 1px 1px 2px #fff;

      @media (max-width: $mobileDeviceWidth) {
        font-size: 1.5em;
      }
    }
  }

  section {
    .section-flex {
      max-width: 1400px;
      margin: 0 auto;
      width: 90%;
      display: flex;
      justify-content: space-between;
      box-sizing: border-box;
      align-items: center;

      @media (max-width: $mobileDeviceWidth) {
        flex-direction: column;
      }
    }

    .join-body-img {
      width: 50%;

      @media (max-width: $mobileDeviceWidth) {
        width: 100%;
        order: 1;
      }

      img {
        width: 100%;
      }
    }

    .join-body-content {
      padding-right: 50px;
      padding-left: 15px;
      order: 1;
      text-align: left;
      width: 50%;

      @media (max-width: $mobileDeviceWidth) {
        width: 100%;
        order: 2;
      }

      h2 {
        width: 100%;
        display: block;
        margin-bottom: 35px;
        text-align: left;
      }

      p {
        line-height: 2;
        font-size: 1.1em;
        padding-bottom: 25px;
        text-align: left;
      }

      a {
        display: inline-block;
        background-color: #039be5;
        border-radius: 4px;
        color: #fff;
        font-size: 16px;
        line-height: 1;
        padding: 12px 16px;
        word-break: keep-all;
        cursor: pointer;
      }
    }

    &:nth-child(2n) {
      .join-body-content {
        padding-left: 50px;
        padding-right: 15px;
        order: 2;
        text-align: left;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
          order: 2;
          padding: 0;
        }
      }

      .join-body-img {
        order: 1;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
          order: 1;
          margin-bottom: 25px;
        }
      }
    }

    &:nth-child(2n - 1) {
      .join-body-content {
        padding-right: 50px;
        padding-left: 15px;
        order: 1;
        text-align: left;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
          order: 2;
          padding: 0;
        }
      }

      .join-body-img {
        order: 2;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
          order: 1;
          margin-bottom: 25px;
        }
      }
    }
  }

  .interview-process {
    display: grid;
    grid-gap: 80px;
    grid-template-columns: repeat(3, 1fr);
    padding: 30px 0;

    @media (max-width: $mobileDeviceWidth) {
      margin: 0 auto;
      max-width: 500px;
      width: 90%;
      grid-gap: 30px;
      grid-template-columns: repeat(1, 1fr);
    }

    .process-box {
      background-color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;

      img {
        max-height: 215px;
        width: 100%;
        object-fit: cover;
      }

      .articleTitle {
        color: #363636;
        font-size: 20px;
        font-weight: 400;
        line-height: 30px;
        letter-spacing: 1px;
        padding-top: 10px;
      }

      .contentWrap {
        display: flex;
        flex-direction: column;
        height: 100%;
      }

      .date {
        font-size: 13px;
        line-height: 20px;
        font-weight: 400;
        letter-spacing: 1px;
        color: #ff6b00;
        padding: 10px 0;
      }

      li {
        line-height: 1.5;
      }
    }
  }
}

.join-tab {
  max-width: 1400px;
  width: 90%;
  border-bottom: 4px solid #0959a2;
  margin: 30px auto;

  span {
    margin-right: 15px;
    padding: 10px 25px;
    box-sizing: border-box;
    display: inline-block;
    width: 150px;
    text-align: center;
    background-color: #b9b9b9;
    color: #0959a2;
    cursor: pointer;

    &:hover {
      background-color: #0959a2;
      color: #fff;
    }

    &.active {
      background-color: #0959a2;
      color: #fff;
    }
  }
}

.list-wrapper {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(20%, 1fr));
  grid-gap: 10px;

  @media (max-width: $mobileDeviceWidth) {
    margin: 0 auto;
    max-width: 500px;
    width: 90%;
    grid-gap: 30px;
    grid-template-columns: repeat(1, 1fr);
  }

  .imgBlock {
    margin-bottom: 10px;
    border: 6px solid #fff;
    box-shadow: 0 0 29px rgba(0, 0, 0, 0.1);

    img {
      width: 100%;
    }

    @media (max-width: $mobileDeviceWidth) {
      max-height: 300px;
      overflow: hidden;
    }
  }

  .contentWrap {
    padding: 16px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 320px;
  }

  .productTitle {
    font-weight: 500;
    font-size: 20px;
    margin-bottom: 10px;
  }

  .productContent {
    font-size: 16px;
    word-wrap: break-word;
    list-style: circle;
    line-height: 1.6;
  }

  .btnBlock {
    align-items: center;
    text-align: center;
    margin-top: 20px;
    font-size: 16px;
  }

  .contentWrap .btnBlock .btn1 {
    width: 100%;
    display: inline-block;
    background-color: #fff;
    border-radius: 4px;
    border: 1px solid #039be5;
    color: #039be5;
    font-size: 16px;
    line-height: 1.6;
    padding: 8px 16px;
    word-break: keep-all;
    cursor: pointer;
    margin: 5px 0;
  }

  .contentWrap .btnBlock .btn2 {
    width: 100%;
    display: inline-block;
    background-color: #fff;
    border-radius: 4px;
    border: 1px solid #039be5;
    color: #039be5;
    font-size: 16px;
    line-height: 1.6;
    padding: 8px 16px;
    word-break: keep-all;
    cursor: pointer;
    margin: 5px 0;
  }
}
</style>
