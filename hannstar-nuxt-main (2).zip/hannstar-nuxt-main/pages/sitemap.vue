<script setup>
const { data } = useSitemap();
const { t } = useI18n();
const localePath = useLocalePath();

//meta data
useMeta({ title: t("site-map") });
</script>

<template>
  <div class="sitemap-container">
    <h1>{{ t("sitemap-main-title") }}</h1>

    <section v-for="(item, index) in data" :key="index">
      <h3>{{ item.mainMenu }}</h3>

      <div class="map-submenu">
        <span v-for="(mainMenu, index) in item.subMenu" :key="index">
          <NuxtLink :to="localePath(mainMenu.link)">
            {{ mainMenu.text }}
          </NuxtLink>
        </span>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sitemap-container {
  max-width: 1000px;
  width: 90%;
  margin: 0 auto;

  h1 {
    text-align: left;
    margin-bottom: 75px;
  }

  section {
    margin-bottom: 100px;
  }

  h3 {
    margin-bottom: 35px;
    border-bottom: 1px solid #d2d2d2;
    display: block;
    padding: 0 0 35px 0;
  }

  .map-submenu {
    display: flex;
    flex-wrap: nowrap;

    span {
      margin-right: 35px;

      a {
        color: #09387e;
      }
    }
  }
}
</style>
