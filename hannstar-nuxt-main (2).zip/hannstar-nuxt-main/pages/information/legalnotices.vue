<script setup>
const { t } = useI18n();

//meta data
useMeta({ title: t("legal-announcement") });
</script>
<template>
  <div class="legal-container">
    <h1>{{ t("information-legalnotices-main-title") }}</h1>

    <div class="content-wrapper">
      <div>
        <h2>{{ t("information-legalnotices-subtitle01") }}</h2>
        <ul>
          <li>
            {{ t("information-legalnotices-text01_1") }}
          </li>
          <li>
            {{ t("information-legalnotices-text01_2") }}
          </li>
        </ul>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle02") }}</h2>
        <p>
          {{ t("information-legalnotices-text02") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle03") }}</h2>
        <p>
          {{ t("information-legalnotices-text03") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle04") }}</h2>
        <p>
          {{ t("information-legalnotices-text04") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle05") }}</h2>
        <p>
          {{ t("information-legalnotices-text05_1") }}
        </p>
        <ul>
          <li>
            {{ t("information-legalnotices-text05_2") }}
          </li>
          <li>
            {{ t("information-legalnotices-text05_3") }}
          </li>
          <li>{{ t("information-legalnotices-text05_4") }}</li>
          <li>{{ t("information-legalnotices-text05_5") }}</li>
          <li>{{ t("information-legalnotices-text05_6") }}</li>
          <li>{{ t("information-legalnotices-text05_7") }}</li>
        </ul>
        <p></p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle06") }}</h2>
        <ul>
          <li>
            {{ t("information-legalnotices-text06_1") }}
          </li>
          <li>
            {{ t("information-legalnotices-text06_2") }}
          </li>
          <li>
            {{ t("information-legalnotices-text06_3") }}
          </li>
          <li>
            {{ t("information-legalnotices-text06_4") }}
          </li>
        </ul>
        <p></p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle07") }}</h2>
        <p>
          {{ t("information-legalnotices-text07") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-legalnotices-subtitle08") }}</h2>
        <p>
          {{ t("information-legalnotices-text08") }}
        </p>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.legal-container {
  max-width: 1000px;
  width: 90%;
  margin: 0 auto 50px auto;

  h1 {
    text-align: left;
    margin-bottom: 50px;
  }

  h2 {
    font-size: 18px;
    line-height: 27px;
    font-weight: 500;
    color: rgba(0, 148, 218);
  }

  ul {
    margin-top: 0rem;
    margin-bottom: 15px;
    list-style-type: decimal;
    padding-left: 35px;

    li {
      color: #777;
    }
  }

  p {
    color: #777;
  }
}
.pb-20 {
  padding-bottom: 20px;
}
</style>
