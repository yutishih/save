<script setup>
const { t } = useI18n();

//meta data
useMeta({ title: t("private-policy") });
</script>
<template>
  <div class="legal-container">
    <h1>{{ t("information-privacy-main-title") }}</h1>

    <p class="pb-20">
      {{ t("information-privacy-main-text") }}
    </p>
    <div class="content-wrapper">
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle01") }}</h2>
        <p>
          {{ t("information-privacy-text01") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle02") }}</h2>
        <p>
          {{ t("information-privacy-text02") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle03") }}</h2>
        <p>
          {{ t("information-privacy-text03") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle04") }}</h2>
        <p class="pb-20">
          {{ t("information-privacy-text04_1") }}
        </p>
        <ul>
          <li>{{ t("information-privacy-text04_2") }}</li>
          <li>
            {{ t("information-privacy-text04_3") }}
          </li>
          <li>
            {{ t("information-privacy-text04_4") }}
          </li>
          <li>
            {{ t("information-privacy-text04_5") }}
          </li>
          <li>
            {{ t("information-privacy-text04_6") }}
          </li>
          <li>
            {{ t("information-privacy-text04_7") }}
          </li>
        </ul>
        <p>
          {{ t("information-privacy-text04_8") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle05") }}</h2>
        <p>
          {{ t("information-privacy-text05") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle06") }}</h2>
        <p>
          {{ t("information-privacy-text06") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle07") }}</h2>
        <p>
          {{ t("information-privacy-text07") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle08") }}</h2>
        <p>
          {{ t("information-privacy-text08") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle09") }}</h2>
        <p>
          {{ t("information-privacy-text09") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle10") }}</h2>
        <p>
          {{ t("information-privacy-text10") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle11") }}</h2>
        <p class="pb-20">{{ t("information-privacy-text11_1") }}</p>
        <ul>
          <li>
            {{ t("information-privacy-text11_2") }}
          </li>
          <li>{{ t("information-privacy-text11_3") }}</li>
          <li>
            {{ t("information-privacy-text11_4") }}
          </li>
          <li>
            {{ t("information-privacy-text11_5") }}
          </li>
          <li>
            {{ t("information-privacy-text11_6") }}
          </li>
          <li>
            {{ t("information-privacy-text11_7") }}
          </li>
          <li>
            {{ t("information-privacy-text11_8") }}
          </li>
        </ul>
        <p class="pb-20">
          {{ t("information-privacy-text11_9") }}
        </p>
        <h3>{{ t("information-privacy-text11_10") }}</h3>
        <ul>
          <li>
            {{ t("information-privacy-text11_11") }}
          </li>
          <li>
            {{ t("information-privacy-text11_12") }}
          </li>
        </ul>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle12") }}</h2>
        <p>
          {{ t("information-privacy-text12") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle13") }}</h2>
        <p>
          {{ t("information-privacy-text13") }}
        </p>
      </div>
      <div class="pb-20">
        <h2>{{ t("information-privacy-subtitle14") }}</h2>
        <p>{{ t("information-privacy-text14_1") }}</p>
        <p>{{ t("information-privacy-text14_2") }}</p>
        <p>{{ t("information-privacy-text14_3") }}</p>
        <p>{{ t("information-privacy-text14_4") }}</p>
        <p></p>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.legal-container {
  max-width: 1000px;
  width: 90%;
  margin: 0 auto 50px auto;

  h1 {
    text-align: left;
    margin-bottom: 50px;
  }

  h2 {
    font-size: 18px;
    line-height: 27px;
    font-weight: 500;
    color: rgba(0, 148, 218);
  }

  h3 {
    font-size: 18px;
    line-height: 27px;
    font-weight: 500;
    color: rgba(0, 148, 218);
  }

  ul {
    margin-top: 0rem;
    margin-bottom: 15px;
    list-style-type: decimal;
    padding-left: 35px;

    li {
      color: #777;
    }
  }

  p {
    color: #777;
  }
}
.pb-20 {
  padding-bottom: 20px;
}
</style>
