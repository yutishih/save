<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("investors-menu08") });
</script>

<template>
  <div class="contacts-container">
    <Breadcrumbs
      :level-second="{ text: data[3].mainMenu, link: data[3].mainMenuLink }"
      :level-third="{
        text: data[3].subMenu[7].text,
        link: data[3].subMenu[7].link,
      }"
      :level-forth="''"
    ></Breadcrumbs>

    <h1>{{ t("investors-contacts-main-title") }}</h1>
    <div class="contacts-body">
      <div class="contacts-body-text">
        {{ t("investors-contacts-subtitle01") }}
      </div>
      <table>
        <tr>
          <td>{{ t("investors-contacts-table01-head01") }}</td>
          <td>{{ t("investors-contacts-table01-text01") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table01-head02") }}</td>
          <td>{{ t("investors-contacts-table01-text02") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table01-head03") }}</td>
          <td>{{ t("investors-contacts-table01-text03") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table01-head04") }}</td>
          <td>
            <a href="http://stock.walsin.com" target="_blank">
              {{ t("investors-contacts-table01-text04") }}
            </a>
          </td>
        </tr>
      </table>

      <div class="contacts-body-text">
        {{ t("investors-contacts-subtitle02") }}
      </div>
      <table>
        <tr>
          <td>{{ t("investors-contacts-table02-head01") }}</td>
          <td>{{ t("investors-contacts-table02-text01") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table02-head02") }}</td>
          <td>{{ t("investors-contacts-table02-text02") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table02-head03") }}</td>
          <td>{{ t("investors-contacts-table02-text03") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table02-head04") }}</td>
          <td>{{ t("investors-contacts-table02-text04") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table02-head05") }}</td>
          <td>{{ t("investors-contacts-table02-text05") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table02-head06") }}</td>
          <td>{{ t("investors-contacts-table02-text06") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table02-head07") }}</td>
          <td>{{ t("investors-contacts-table02-text07") }}</td>
        </tr>
      </table>

      <div class="contacts-body-text">
        {{ t("investors-contacts-subtitle03") }}
      </div>
      <table>
        <tr>
          <td>{{ t("investors-contacts-table03-head01") }}</td>
          <td>{{ t("investors-contacts-table03-text01") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table03-head02") }}</td>
          <td>{{ t("investors-contacts-table03-text02") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table03-head03") }}</td>
          <td>{{ t("investors-contacts-table03-text03") }}</td>
        </tr>
        <tr>
          <td>{{ t("investors-contacts-table03-head04") }}</td>
          <td>
            <a href="https://www.citi.com/dr" target="_blank">
              {{ t("investors-contacts-table03-text04") }}
            </a>
          </td>
        </tr>
        <tr>
          <td>Email</td>
          <td>citibank@shareholders-online.com</td>
        </tr>
      </table>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.contacts-container {
  h1 {
    text-align: center;
    margin-bottom: 50px;
  }

  .contacts-body {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;

    .contacts-body-text {
      margin-bottom: 15px;
    }
  }

  table {
    width: 100%;
    margin-bottom: 50px;
    tr {
      td {
        padding: 15px 20px;
        border: 1px solid #b9b9b9;

        &:nth-child(2n -1) {
          width: 15%;
          text-align: center;
          background-color: rgb(0, 148, 218);
          color: #fff;
        }

        &:nth-child(2n) {
          text-align: left;
        }
      }
    }
  }
}
</style>
