<script setup>
const { data } = useSitemap();
const { t } = useI18n();
const { dividendData } = useDividendData();

//meta data
useMeta({ title: t("investors-menu06") });

const contentDetect = (i) => {
  if (i !== "") {
    return i;
  } else {
    return "-";
  }
};

const toggleIndex = ref(null);
const openCollapse = (i) => {
  if (toggleIndex.value === i) {
    toggleIndex.value = null;
  } else {
    toggleIndex.value = i;
  }
};
</script>
<template>
  <div class="dividend-container">
    <Breadcrumbs
      :level-second="{ text: data[3].mainMenu, link: data[3].mainMenuLink }"
      :level-third="{
        text: data[3].subMenu[5].text,
        link: data[3].subMenu[5].link,
      }"
      :level-forth="''"
    ></Breadcrumbs>

    <h1>{{ t("investors-dividend-main-title") }}</h1>
    <div class="table-unit">{{ t("investors-dividend-table-unit") }}</div>
    <table class="pc-display">
      <tr>
        <th colspan="1" rowspan="2">
          {{ t("investors-dividend-table-head01") }}
        </th>
        <th colspan="1" rowspan="2">
          {{ t("investors-dividend-table-head02") }}
        </th>
        <th colspan="3" rowspan="1">
          {{ t("investors-dividend-table-head03") }}
        </th>
        <th colspan="3" rowspan="1">
          {{ t("investors-dividend-table-head07") }}
        </th>
      </tr>
      <tr>
        <th>{{ t("investors-dividend-table-head04") }}</th>
        <th>{{ t("investors-dividend-table-head05") }}</th>
        <th>{{ t("investors-dividend-table-head06") }}</th>
        <th>{{ t("investors-dividend-table-head08") }}</th>
        <th>{{ t("investors-dividend-table-head09") }}</th>
        <th>{{ t("investors-dividend-table-head10") }}</th>
      </tr>

      <tr v-for="(item, index) in dividendData" :key="index">
        <td v-html="contentDetect(item.year)"></td>
        <td v-html="contentDetect(item.date)"></td>
        <td v-html="contentDetect(item.interest)"></td>
        <td v-html="contentDetect(item.tradeDate)"></td>
        <td v-html="contentDetect(item.issueDate)"></td>
        <td v-html="contentDetect(item.shareInterest)"></td>
        <td v-html="contentDetect(item.exDividendDate)"></td>
        <td v-html="contentDetect(item.listDate)"></td>
      </tr>
    </table>

    <!-- Mobile Table Components -->
    <div class="mb-table-wrapper table-mobile-component mb-display">
      <div class="table-collapse">
        <div
          v-for="(list, index) in dividendData"
          class="table-list"
          @click="openCollapse(index)"
        >
          <div class="list-flex">
            <span>
              {{ t("investors-dividend-table-head01") }}: {{ list.year }} <br />
              {{ t("investors-dividend-table-head02") }}: {{ list.date }}
            </span>
            <span
              class="plus-icon"
              :class="{ open: toggleIndex === index }"
            ></span>
          </div>
          <div class="list-collapse" :class="{ active: toggleIndex === index }">
            <div class="list-collapse-style">
              <div class="style-title">
                <strong>[{{ t("investors-dividend-table-head03") }}]</strong>
              </div>
              <div>
                {{ t("investors-dividend-table-head04") }}: {{ list.interest }}
              </div>
              <div>
                {{ t("investors-dividend-table-head05") }}: {{ list.tradeDate }}
              </div>
              <div>
                {{ t("investors-dividend-table-head06") }}: {{ list.issueDate }}
              </div>

              <div class="style-title">
                <strong>[{{ t("investors-dividend-table-head07") }}]</strong>
              </div>
              <div>
                {{ t("investors-dividend-table-head08") }}:
                {{ list.shareInterest }}
              </div>
              <div>
                {{ t("investors-dividend-table-head09") }}:
                {{ list.exDividendDate }}
              </div>
              <div>
                {{ t("investors-dividend-table-head10") }}: {{ list.listDate }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="dividend-text">
      <p>{{ t("investors-dividend-subtitle01") }}</p>
      <p>
        {{ t("investors-dividend-text01") }}
      </p>
      <p>
        {{ t("investors-dividend-text02") }}
      </p>
      <p>
        {{ t("investors-dividend-text03") }}
      </p>
    </div>
  </div>
</template>
<style lang="scss" scoped>
.dividend-container {
  h1 {
    text-align: center;
  }

  .table-unit {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto 15px auto;
    text-align: right;
    padding: 0 2.5px;
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;

    tr {
      th {
        text-align: center;
        background-color: rgb(0, 148, 218);
        border: 1px solid rgb(238, 238, 238);
        color: #fff;
        padding: 10px 0;
        box-sizing: border-box;
      }

      td {
        text-align: center;
        padding: 10px 0;
        box-sizing: border-box;
        border: 1px solid rgb(238, 238, 238);
      }

      &:nth-child(2n + 2) {
        td {
          background-color: rgb(247, 247, 247);
        }
      }
    }
  }

  .dividend-text {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto;

    p:first-child {
      color: $textLinkColor;
    }
  }
}

.plus-icon {
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}

.mb-table-wrapper {
  padding: 15px 20px 20px 20px;
  border: 1px solid #b9b9b9;
  box-sizing: border-box;
  display: flex;
  width: 90%;
  margin: 0 auto;

  .table-collapse {
    display: block;
    width: 100%;
  }

  .table-list {
    width: 100%;
    display: block;
    padding: 15px 0;
    border-bottom: 1px solid #b9b9b9;
    cursor: pointer;

    .list-flex {
      display: flex;
      justify-content: space-between;
    }
  }

  .list-collapse {
    height: 0;
    transition: 0.5s;
    overflow: hidden;

    ul {
      list-style: disc;
      padding-left: 25px;

      li {
        margin: 5px 0;
      }
    }

    div {
      opacity: 0;
      transition: 0.5s;
    }

    &.active {
      height: auto;

      div {
        opacity: 1;
      }
    }
  }
}

@media screen and (max-width: $mobileDeviceWidth) {
  .table-pc-component {
    display: none;
  }
}

@media screen and (min-width: $mobileDeviceWidth) {
  .table-mobile-component {
    display: none;
  }
}

.list-collapse-style {
  .style-title {
    margin-top: 15px;
  }
}
</style>
