<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";

const { data } = useSitemap();
const { t } = useI18n();
const route = useRoute();
const router = useRouter();

//meta data
useMeta({ title: t("investors-menu01") });

const tabItems = [
  {
    text: t("investors-summary-tab01"),
    queryTab: "1",
  },
  {
    text: t("investors-summary-tab02"),
    queryTab: "2",
  },
  {
    text: t("investors-summary-tab03"),
    queryTab: "3",
  },
];

// 獲取 URL 查詢參數中的 Tab 值
const getInitialTab = () => {
  const tabParam = route.query.Tab;
  if (tabParam) {
    const tabIndex = tabItems.findIndex((item) => item.queryTab === tabParam);
    return tabIndex !== -1 ? tabIndex : 0;
  }
  return 0;
};

// 在創建時設定初始 Tab
const tabChoose = ref(getInitialTab());

const updateQueryParam = (index) => {
  const selectedTab = tabItems[index].queryTab;
  router.push({ query: { Tab: selectedTab } });
};

const getTabChooseIndex = (i) => {
  tabChoose.value = parseInt(i);
  updateQueryParam(tabChoose.value);
};

onMounted(() => {
  // 確保 URL 查詢參數與當前 Tab 同步
  updateQueryParam(tabChoose.value);
});
</script>

<template>
  <div class="investors-container">
    <Breadcrumbs
      :level-second="{ text: data[3].mainMenu, link: data[3].mainMenuLink }"
      :level-third="{
        text: data[3].subMenu[0].text,
        link: data[3].subMenu[0].link,
      }"
      :level-forth="''"
    ></Breadcrumbs>

    <h1>{{ t("investors-summary-main-title") }}</h1>
    <Tab
      :tab-navigation="tabItems"
      @update:tab-choose="getTabChooseIndex"
    ></Tab>

    <InvestorsSummaryTab01 v-if="tabChoose === 0"></InvestorsSummaryTab01>
    <InvestorsSummaryTab02 v-if="tabChoose === 1"></InvestorsSummaryTab02>
    <InvestorsSummaryTab03 v-if="tabChoose === 2"></InvestorsSummaryTab03>
  </div>
</template>

<style lang="scss" scoped>
.investors-container {
  h1 {
    text-align: center;
    margin: 35px 0;
  }
}
</style>
