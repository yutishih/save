<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("investors-menu04") });

const { conferenceData } = useConferenceData();
</script>

<template>
  <div class="investors-container">
    <Breadcrumbs
      :level-second="{ text: data[3].mainMenu, link: data[3].mainMenuLink }"
      :level-third="{
        text: data[3].subMenu[3].text,
        link: data[3].subMenu[3].link,
      }"
      :level-forth="''"
    ></Breadcrumbs>

    <h1>{{ t("investors-conference-main-title") }}</h1>

    <table>
      <tr>
        <th>{{ t("investors-conference-table-head01") }}</th>
        <th>{{ t("investors-conference-table-head02") }}</th>
        <th>{{ t("investors-conference-table-head03") }}</th>
      </tr>
      <tr v-for="(item, index) in conferenceData" :key="index">
        <td>{{ item.date }}</td>
        <td>{{ item.title }}</td>
        <td>
          <a
            v-if="item.downloadLink && item.downloadLink !== ''"
            :href="item.downloadLink"
            target="_blank"
          >
            <img
              src="https://media.hannstar.com/Image/hannstar/download-PDF.png"
              alt=""
            />
          </a>
        </td>
      </tr>
    </table>
  </div>
</template>

<style lang="scss" scoped>
.investors-container {
  h1 {
    text-align: center;
    margin: 35px 0;
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto;

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      width: 33.33%;
      min-height: 30px;

      img {
        display: block;
        margin: 0 auto;
        max-width: 35px;
      }
    }
  }
}
</style>
