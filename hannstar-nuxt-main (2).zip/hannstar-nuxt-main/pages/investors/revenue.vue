<script setup>
import { ref } from "vue";
import { useRoute } from "vue-router";

const { data } = useSitemap();
const { t } = useI18n();
const { revenueData2024 } = useRevenueData2024();
const { revenueData2023 } = useRevenueData2023();
const { revenueData2022 } = useRevenueData2022();
const { revenueData2021 } = useRevenueData2021();
const { revenueData2020 } = useRevenueData2020();
const { revenueData2019 } = useRevenueData2019();
const { revenueData2018 } = useRevenueData2018();

//meta data
useMeta({ title: t("investors-menu02") });
const tabItems = [
  {
    text: "2024",
    queryTab: "2024",
  },
  {
    text: "2023",
    queryTab: "2023",
  },
  {
    text: "2022",
    queryTab: "2022",
  },
  {
    text: "2021",
    queryTab: "2021",
  },
  {
    text: "2020",
    queryTab: "2020",
  },
  {
    text: "2019",
    queryTab: "2019",
  },
  {
    text: "2018",
    queryTab: "2018",
  },
];

const route = useRoute();

const revenueDataMap = {
  2024: revenueData2024,
  2023: revenueData2023,
  2022: revenueData2022,
  2021: revenueData2021,
  2020: revenueData2020,
  2019: revenueData2019,
  2018: revenueData2018,
};

const getInitialRevenueData = () => {
  const tabParam = route.query.Tab || "2024";
  const year = tabParam;
  const data = revenueDataMap[year] || revenueData2024;
  return { year, data };
};

const initialRevenue = getInitialRevenueData();
const revenueYear = ref(initialRevenue.year);
const revenueData = ref(initialRevenue.data);

const getTabChooseIndex = (i) => {
  switch (i) {
    case 0:
      revenueYear.value = 2024;
      revenueData.value = revenueData2023;
      break;

    case 1:
      revenueYear.value = 2023;
      revenueData.value = revenueData2023;
      break;

    case 2:
      revenueYear.value = 2022;
      revenueData.value = revenueData2022;
      break;

    case 3:
      revenueYear.value = 2021;
      revenueData.value = revenueData2021;
      break;

    case 4:
      revenueYear.value = 2020;
      revenueData.value = revenueData2020;
      break;

    case 5:
      revenueYear.value = 2019;
      revenueData.value = revenueData2019;
      break;

    case 6:
      revenueYear.value = 2018;
      revenueData.value = revenueData2018;
      break;

    default:
      revenueYear.value = 2024;
      revenueData.value = revenueData2023;
      break;
  }
};

//手機板
const toggleIndex = ref(null);
const openCollapse = (i) => {
  if (toggleIndex.value === i) {
    toggleIndex.value = null;
  } else {
    toggleIndex.value = i;
  }
};
</script>

<template>
  <div class="investors-container">
    <Breadcrumbs
      :level-second="{ text: data[3].mainMenu, link: data[3].mainMenuLink }"
      :level-third="{
        text: data[3].subMenu[1].text,
        link: data[3].subMenu[1].link,
      }"
      :level-forth="''"
    ></Breadcrumbs>

    <h1>{{ t("investors-revenue-main-title") }}</h1>
    <Tab
      :tab-navigation="tabItems"
      @update:tab-choose="getTabChooseIndex"
    ></Tab>

    <div class="table-unit">{{ t("investors-revenue-table-unit") }}</div>
    <table class="pc-display">
      <tr>
        <th colspan="7" scope="col">
          {{ revenueYear }} {{ t("investors-revenue-table-title") }}
        </th>
      </tr>
      <tr class="tr-title">
        <td colspan="1" rowspan="3">
          {{ t("investors-revenue-table-head01") }}
        </td>
        <td colspan="2" rowspan="2">
          {{ t("investors-revenue-table-head02") }}
        </td>
        <td colspan="4" rowspan="1">
          {{ t("investors-revenue-table-head03") }}
        </td>
      </tr>

      <tr class="tr-title">
        <td colspan="2" rowspan="1">
          {{ t("investors-revenue-table-head04") }}
        </td>
        <td colspan="2" rowspan="1">
          {{ t("investors-revenue-table-head05") }}
        </td>
      </tr>

      <tr class="tr-title">
        <td>{{ t("investors-revenue-table-head06") }}</td>
        <td>{{ t("investors-revenue-table-head07") }}</td>
        <td>{{ t("investors-revenue-table-head08") }}</td>
        <td>{{ t("investors-revenue-table-head09") }}</td>
        <td>{{ t("investors-revenue-table-head10") }}</td>
        <td>{{ t("investors-revenue-table-head11") }}</td>
      </tr>

      <tr v-for="(item, index) in revenueData" :key="index">
        <td>{{ item.date }}</td>
        <td>{{ item.monthlyIncome }}</td>
        <td>{{ item.yearlyChange }}</td>
        <td>{{ item.countBig }}</td>
        <td>{{ item.countSmall }}</td>
        <td>{{ item.yearlyChangeBig }}</td>
        <td>{{ item.yearlyChangeSmall }}</td>
      </tr>
    </table>

    <!-- Mobile Table Components -->
    <div class="mb-table-wrapper table-mobile-component mb-display">
      <div class="table-collapse">
        <div
          v-for="(list, index) in revenueData"
          class="table-list"
          @click="openCollapse(index)"
        >
          <div class="list-flex">
            <span>{{ list.date }}</span>
            <span
              class="plus-icon"
              :class="{ open: toggleIndex === index }"
            ></span>
          </div>
          <div class="list-collapse" :class="{ active: toggleIndex === index }">
            <div class="list-collapse-style">
              <div class="style-title">
                <strong>[{{ t("investors-revenue-table-head02") }}]</strong>
              </div>
              <div>
                {{ t("investors-revenue-table-head06") }}:
                {{ list.monthlyIncome }}
              </div>
              <div>
                {{ t("investors-revenue-table-head07") }}:
                {{ list.yearlyChange }}
              </div>

              <div class="style-title">
                <strong>[{{ t("investors-revenue-table-head12") }}]</strong>
              </div>
              <div>
                {{ t("investors-revenue-table-head08") }}: {{ list.countBig }}
              </div>
              <div>
                {{ t("investors-revenue-table-head09") }}: {{ list.countSmall }}
              </div>

              <div class="style-title">
                <strong>[{{ t("investors-revenue-table-head13") }}]</strong>
              </div>
              <div>
                {{ t("investors-revenue-table-head10") }}:
                {{ list.yearlyChangeBig }}
              </div>
              <div>
                {{ t("investors-revenue-table-head11") }}:
                {{ list.yearlyChangeSmall }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.investors-container {
  padding-bottom: 50px;
  h1 {
    text-align: center;
    margin: 35px 0;
  }

  .table-unit {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto 15px auto;
    text-align: right;
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto 50px auto;

    tr {
      &:nth-child(2n + 5) {
        td {
          background-color: rgb(247, 247, 247);
        }
      }
    }

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: right;

      &:first-child {
        text-align: center;
      }
    }
  }
}

.plus-icon {
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}

.mb-table-wrapper {
  padding: 15px 20px 20px 20px;
  border: 1px solid #b9b9b9;
  box-sizing: border-box;
  display: flex;
  width: 90%;
  margin: 0 auto;

  .table-collapse {
    display: block;
    width: 100%;
  }

  .table-list {
    width: 100%;
    display: block;
    padding: 15px 0;
    border-bottom: 1px solid #b9b9b9;
    cursor: pointer;

    .list-flex {
      display: flex;
      justify-content: space-between;
    }
  }

  .list-collapse {
    height: 0;
    transition: 0.5s;
    overflow: hidden;

    ul {
      list-style: disc;
      padding-left: 25px;

      li {
        margin: 5px 0;
      }
    }

    div {
      opacity: 0;
      transition: 0.5s;
    }

    &.active {
      height: auto;

      div {
        opacity: 1;
      }
    }
  }
}

@media screen and (max-width: $mobileDeviceWidth) {
  .table-pc-component {
    display: none;
  }
}

@media screen and (min-width: $mobileDeviceWidth) {
  .table-mobile-component {
    display: none;
  }
}

.list-collapse-style {
  .style-title {
    margin-top: 15px;
  }
}
</style>
