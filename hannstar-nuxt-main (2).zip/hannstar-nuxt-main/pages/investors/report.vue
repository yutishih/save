<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";

const { data } = useSitemap();
const { t } = useI18n();
const { reportData2023 } = useReportData2023();
const { reportData2022 } = useReportData2022();
const { reportData2021 } = useReportData2021();
const { reportData2020 } = useReportData2020();
const { reportData2019 } = useReportData2019();
const { reportData2018 } = useReportData2018();

//meta data
useMeta({ title: t("investors-menu03") });

const tabItems = [
  {
    text: "2023",
    queryTab: "2023",
  },
  {
    text: "2022",
    queryTab: "2022",
  },
  {
    text: "2021",
    queryTab: "2021",
  },
  {
    text: "2020",
    queryTab: "2020",
  },
  {
    text: "2019",
    queryTab: "2019",
  },
  {
    text: "2018",
    queryTab: "2018",
  },
];

const route = useRoute();

const reportDataMap = {
  2023: reportData2023,
  2022: reportData2022,
  2021: reportData2021,
  2020: reportData2020,
  2019: reportData2019,
  2018: reportData2018,
};

const getInitialReportData = () => {
  const tabParam = route.query.Tab || "2023";
  const year = tabParam;
  const data = reportDataMap[year] || reportData2023;
  return { year, data };
};

const initialReport = getInitialReportData();
const reportDate = ref(initialReport.year);
const reportData = ref(initialReport.data);

const getTabChooseIndex = (i) => {
  switch (i) {
    case 0:
      reportDate.value = 2023;
      reportData.value = reportData2023;
      break;

    case 1:
      reportDate.value = 2022;
      reportData.value = reportData2022;
      break;

    case 2:
      reportDate.value = 2021;
      reportData.value = reportData2021;
      break;

    case 3:
      reportDate.value = 2020;
      reportData.value = reportData2020;
      break;

    case 4:
      reportDate.value = 2019;
      reportData.value = reportData2019;
      break;

    case 5:
      reportDate.value = 2018;
      reportData.value = reportData2018;
      break;

    default:
      reportDate.value = 2023;
      reportData.value = reportData2023;
      break;
  }
};
</script>

<template>
  <div class="investors-container">
    <Breadcrumbs
      :level-second="{ text: data[3].mainMenu, link: data[3].mainMenuLink }"
      :level-third="{
        text: data[3].subMenu[2].text,
        link: data[3].subMenu[2].link,
      }"
      :level-forth="''"
    ></Breadcrumbs>

    <h1>{{ t("investors-report-main-title") }}</h1>
    <Tab
      :tab-navigation="tabItems"
      @update:tab-choose="getTabChooseIndex"
    ></Tab>

    <table>
      <tr>
        <th>{{ t("investors-report-table-head01") }}</th>
        <th>{{ t("investors-report-table-head02") }}</th>
        <th>{{ t("investors-report-table-head03") }}</th>
      </tr>
      <tr v-for="(item, index) in reportData" :key="index">
        <td>{{ item.year }}</td>
        <td>{{ item.title }}</td>
        <td>
          <a
            v-if="item.downloadLink && item.downloadLink !== ''"
            :href="item.downloadLink"
            target="_blank"
          >
            <img
              src="https://media.hannstar.com/Image/hannstar/download-PDF.png"
              alt=""
            />
          </a>
        </td>
      </tr>
    </table>
  </div>
</template>

<style lang="scss" scoped>
.investors-container {
  h1 {
    text-align: center;
    margin: 35px 0;
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 50px auto;

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      width: 33.33%;
      min-height: 30px;

      img {
        max-width: 35px;
        margin: 0 auto;
      }
    }
  }
}
</style>
