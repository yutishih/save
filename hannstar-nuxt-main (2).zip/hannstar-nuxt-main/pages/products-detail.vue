<script setup>
import AOS from "aos";
import "aos/dist/aos.css";

//動畫
onMounted(() => {
  AOS.init({
    duration: 1200,
  });
});
</script>
<template>
  <div>
    <NuxtPage></NuxtPage>
  </div>
</template>
<style lang="scss">
.hannstar-product-body {
  h1 {
    text-align: center;
    max-width: 1400px;
    width: 100%;
    margin: 0 auto 50px auto;
  }
}

.hannstar-product-body {
  max-width: 1400px;
  margin: 0 auto;
  width: 90%;

  .about-team-img {
    max-width: 1200px;
    width: 100%;
    margin: 0 auto;
  }

  .hannstar-table {
    width: 100%;
    margin: 50px auto;
  }
}

.product-container {
  .product-header {
    margin-bottom: 50px;

    h1 {
      text-align: center;
      display: block;
      margin: 35px auto;
    }

    p {
      max-width: 1000px;
      width: 90%;
      margin: 0 auto 35px auto;
      line-height: 2;
      font-size: 1.1em;
    }

    .product-header-img {
      width: 100%;
      max-width: 1400px;
      margin: 0 auto;
    }
  }

  .product-body {
    margin: 0 auto;
    width: 100%;

    section {
      margin: 0 auto;
      width: 100%;
      padding: 25px 0;

      .section-flex {
        max-width: 1400px;
        margin: 0 auto;
        width: 100%;
        display: flex;
        justify-content: space-between;
        box-sizing: border-box;

        @media (max-width: $mobileDeviceWidth) {
          flex-direction: column;
        }
      }

      .product-body-img {
        width: 50%;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
        }

        img {
          width: 100%;
        }
      }

      .product-body-content {
        width: 50%;
        box-sizing: border-box;
        padding-top: 25px;

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
          margin: 0 auto;
        }

        h2 {
          width: 100%;
          display: block;
          margin-bottom: 35px;
        }

        p {
          line-height: 2;
          font-size: 1.1em;
          border-bottom: 1px solid #bfbfbf;
          padding-bottom: 25px;
        }
      }

      &:nth-child(2n-1) {
        @media (max-width: $mobileDeviceWidth) {
          padding: 0;
        }

        .product-body-content {
          padding-left: 50px;
          padding-right: 15px;
          order: 2;

          @media (max-width: $mobileDeviceWidth) {
            padding: 0;
            width: 90%;
            margin: 25px auto 0 auto;
            order: 1;

            img {
              margin: 0 auto;
            }
          }
        }

        .product-body-img {
          order: 1;
        }
      }

      &:nth-child(2n) {
        background: #f6f6f6;

        @media (max-width: $mobileDeviceWidth) {
          padding: 0;
        }

        .product-body-content {
          padding-right: 50px;
          padding-left: 15px;
          order: 1;

          @media (max-width: $mobileDeviceWidth) {
            padding: 0;
            width: 90%;
            margin: 25px auto 0 auto;
            order: 2;
          }
        }

        .product-body-img {
          order: 2;
        }
      }
    }
  }
}
</style>
