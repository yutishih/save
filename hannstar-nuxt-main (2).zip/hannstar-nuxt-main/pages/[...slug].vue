<script setup>
const { t } = useI18n();
//meta data
useMeta({ title: "404 Not Found" });
</script>

<template>
  <div class="wrong-page-container">
    <div class="text-box">
      <p>{{ t("404-page-title") }}</p>
      <div class="button-box">
        <a href="/">{{ t("404-page-back") }}</a>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.wrong-page-container {
  min-height: 500px;
  display: flex;
  align-items: center;
  .text-box {
    max-width: 1400px;
    width: 100%;
    margin: 0 auto;
    text-align: center;
    .button-box {
      margin-top: 40px;
      a {
        color: #08c;
        border: 1px solid #08c;
        padding: 5px 10px;
        &:hover {
          color: #fff;
          background-color: #08c;
        }
      }
    }
  }
}
</style>
