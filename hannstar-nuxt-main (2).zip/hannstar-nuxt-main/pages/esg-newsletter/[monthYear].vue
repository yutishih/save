<script setup>
import { useSingleNews } from "../../../composables/news/useSingleNews";
import { useNewsList } from "../../../composables/news/useNewsList";

const { t, locale } = useI18n();

//meta data
useMeta({ title: "HannStar ESG Newsletter" });

//抓上一個月份
function getLastMonthAndYear() {
  let currentDate = new Date();
  let year = currentDate.getFullYear();
  let month = currentDate.getMonth();
  if (month === 0) {
    month = 12;
    year -= 1;
  }
  let rocYear = year - 1911;
  return { month, year: rocYear };
}
const { month, year } = getLastMonthAndYear();

//抓當前語言
const language = computed(() => {
  switch (locale.value) {
    case "en":
      return "en";
    case "tw":
      return "zh-hant";
    case "cn":
      return "zh";
    default:
      return "tw";
  }
});

// api打入的資料
const { news, isLoading, error, fetchNews } = useNewsList();
const { singleNews, fetchSingleNews } = useSingleNews();

const filterData = ref([]);
const recentPostsDetails = ref([]);

// 按日期排序
const sortData = (data) => {
  return data.sort((a, b) => {
    const dateA = new Date(a.create_time);
    const dateB = new Date(b.create_time);
    return dateB - dateA;
  });
};

// 用id抓取文章內文
const fetchAndDisplayArticles = async () => {
  await fetchNews("ESG");
  const filteredByLanguage = news.value.data.filter(
    (item) => item.language === "zh-hant"
  );
  filterData.value = sortData(filteredByLanguage);

  recentPostsDetails.value = [];

  for (const item of filterData.value.slice(0, 3)) {
    console.log(item.id);
    await fetchSingleNews(item.id);
    if (singleNews.value) {
      recentPostsDetails.value.push({ ...singleNews.value });
    } else {
      console.error("error: singleNews is undefined");
    }
  }
};

onMounted(fetchAndDisplayArticles);
</script>

<template>
  <div class="newsletter-container">
    <div class="container-background">
      <div class="newsletter-content">
        <div class="content-background">
          <div class="newsletter-top">
            <div class="text">
              <h1>瀚宇彩晶 ESG電子報</h1>
              <p>民國{{ year }}年{{ month }}月</p>
            </div>
            <div class="logo image">
              <img
                src="https://media.hannstar.com/Image/hannstar/newsleopard-images/August/logo_2.png"
              />
            </div>
          </div>
          <div v-if="filterData.length > 0" class="newsletter-highlight-post">
            <img :src="filterData[0].preview_image" />
            <h3 v-html="filterData[0].title"></h3>
            <p v-html="filterData[0].content"></p>
            <a :href="`/news/esg/article?articleId=${filterData[0].article_id}`"
              ><button>查看全文</button></a
            >
          </div>
          <div v-else class="loading"><img src="/loading.gif" /></div>
          <div class="newsletter-recent-post">
            <div
              v-for="(v, index) in recentPostsDetails.slice(1, 3)"
              :key="index"
              class="posts-wrap"
            >
              <img :src="v.preview_image" />
              <div class="text">
                <h4 v-html="v.title"></h4>
                <p v-html="v.content"></p>
                <a :href="`/news/esg/article?articleId=${v.article_id}`"
                  ><button>繼續閱讀</button></a
                >
              </div>
            </div>
            <div class="readmore-wrap">
              <a href="/news/esg"
                ><button class="readmore">瀏覽更多文章</button></a
              >
            </div>
          </div>
        </div>
        <div class="newsletter-bottom">
          <div class="icon-container">
            <a href="https://www.hannstar.com/"
              ><img
                src="https://media.hannstar.com/Image/hannstar/newsleopard-images/August/home.png"
            /></a>
            <a href="https://tw.linkedin.com/company/hannstar-display"
              ><img
                src="https://media.hannstar.com/Image/hannstar/newsleopard-images/August/linkedin.png"
            /></a>
            <a href="https://www.facebook.com/HannstarRecruiting/"
              ><img
                src="https://media.hannstar.com/Image/hannstar/newsleopard-images/August/facebook.png"
            /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.newsletter-container {
  img {
    width: 100%;
  }
  .container-background {
    background-color: #f5f5f5;
    .loading {
      max-width: 100px;
      width: 100%;
      margin: 0 auto;
      min-height: 1000px;
      padding: 200px 0;
    }

    .newsletter-content {
      max-width: 640px;
      margin: 0 auto;
      padding: 60px 0;
      @media screen and (max-width: 768px) {
        margin: 0 10px;
      }
      .content-background {
        background-color: #fff;
        padding: 30px;

        .newsletter-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 20px;
          @media screen and (max-width: 768px) {
            display: inline-block;
          }
          .text {
            h1 {
              font-size: 1.5em;
              color: #0581cb;
              margin-bottom: 10px;
            }
            p {
              font-size: 1em;
            }
          }
          .logo {
            max-width: 270px;
            @media screen and (max-width: 768px) {
              max-width: 100%;
            }
          }
        }
        .newsletter-highlight-post {
          border-bottom: 1px solid #b9b9b9;
          img {
            padding-bottom: 30px;
          }
          h3 {
            padding-bottom: 15px;
          }
          p {
            line-height: 1.5;
            word-break: break-all;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 4;
            overflow: hidden;
            margin-bottom: 20px;
          }
          button {
            color: #fff;
            background-color: rgb(3, 155, 229);
            width: 100%;
            padding: 15px 0;
            border-radius: 5px;
            margin-bottom: 40px;
          }
        }
        .newsletter-recent-post {
          margin-top: 40px;
          .posts-wrap {
            display: flex;
            padding-bottom: 30px;
            @media screen and (max-width: 768px) {
              display: inline-block;
            }
            img {
              width: 50%;
              max-height: 300px;
              height: 100%;
              padding-right: 10px;
              @media screen and (max-width: 768px) {
                width: 100%;
                padding-right: 0;
              }
            }
            .text {
              width: 50%;

              padding-left: 10px;
              @media screen and (max-width: 768px) {
                width: 100%;
                padding-top: 15px;
                padding-left: 0;
              }
              h4 {
                padding-bottom: 15px;
              }
              p {
                line-height: 1.5;
                word-break: break-all;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 3;
                overflow: hidden;
              }
              button {
                width: 100%;
                margin-top: 15px;
                padding: 15px;
                color: rgb(3, 155, 229);
                border: 2px solid rgb(3, 155, 229);
              }
            }
          }
          .readmore-wrap {
            border-bottom: 1px solid #b9b9b9;
            button {
              &.readmore {
                color: #fff;
                background-color: rgb(3, 155, 229);
                width: 100%;
                padding: 15px 0;
                border-radius: 5px;
                margin: 40px 0;
              }
            }
          }
        }
      }
    }
  }
  .newsletter-bottom {
    background-color: #0581cb;
    padding: 15px 0;
    .icon-container {
      display: flex;
      justify-content: center;
      align-items: center;
      a {
        padding: 0 10px;
        img {
          max-width: 30px;
          width: 100%;
        }
      }
    }
  }
}
</style>
