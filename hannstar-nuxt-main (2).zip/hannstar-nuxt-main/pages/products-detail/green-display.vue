<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("product-menu08") });
</script>

<template>
  <div>
    <div class="product-container">
      <Breadcrumbs
        :level-second="{ text: data[1].mainMenu, link: data[1].mainMenuLink }"
        :level-third="{
          text: data[1].subMenu[7].text,
          link: data[1].subMenu[7].link,
        }"
      ></Breadcrumbs>
      <TabProducts :tab-active="7"></TabProducts>

      <div class="product-header">
        <div>
          <h1>{{ t("product-greenDisplay-main-title") }}</h1>
          <p>
            {{ t("product-greenDisplay-main-text") }}
          </p>
        </div>

        <div class="product-header-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/document360/products-detail/green-display/0001.jpg"
            alt=""
          />
        </div>
      </div>
      <div class="product-body">
        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/green-display/0005.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-greenDisplay-subtitle01") }}</h2>
              <p>
                {{ t("product-greenDisplay-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/green-display/0002.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-greenDisplay-subtitle02") }}</h2>
              <p>
                {{ t("product-greenDisplay-text02") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/green-display/0006.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-greenDisplay-subtitle03") }}</h2>
              <p>
                {{ t("product-greenDisplay-text03") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/green-display/0004.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-greenDisplay-subtitle04") }}</h2>
              <p>
                {{ t("product-greenDisplay-text04") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/green-display/0003.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-greenDisplay-subtitle05") }}</h2>
              <p>
                {{ t("product-greenDisplay-text05") }}
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>
