<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("product-menu01") });
</script>

<template>
  <div>
    <div class="product-container">
      <Breadcrumbs
        :level-second="{ text: data[1].mainMenu, link: data[1].mainMenuLink }"
        :level-third="{
          text: data[1].subMenu[0].text,
          link: data[1].subMenu[0].link,
        }"
      ></Breadcrumbs>
      <TabProducts :tab-active="0"></TabProducts>

      <div class="product-header">
        <div>
          <h1>{{ t("product-automotive-main-title") }}</h1>
          <p>
            {{ t("product-automotive-main-text") }}
          </p>
        </div>

        <div class="product-header-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0001.jpg"
            alt=""
          />
        </div>
      </div>
      <div class="product-body">
        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0004.png"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle01") }}</h2>
              <p>
                {{ t("product-automotive-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0005.png"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle02") }}</h2>
              <p>
                {{ t("product-automotive-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0006.png"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle03") }}</h2>
              <p>
                {{ t("product-automotive-text04") }}
              </p>
              <img
                :src="t('product-automotive-image03')"
                alt="一體黑顯示技術"
              />
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0007.png"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle04") }}</h2>
              <p>
                {{ t("product-automotive-text05") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0008.png"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle05") }}</h2>
              <p>
                {{ t("product-automotive-text05") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0009.png"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle06") }}</h2>
              <p>
                {{ t("product-automotive-text06") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/automotive/0003.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-automotive-subtitle07") }}</h2>
              <p>
                {{ t("product-automotive-text07") }}
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
