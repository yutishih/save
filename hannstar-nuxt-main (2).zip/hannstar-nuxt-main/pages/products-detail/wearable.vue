<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("product-menu04") });
</script>

<template>
  <div>
    <div class="product-container">
      <Breadcrumbs
        :level-second="{ text: data[1].mainMenu, link: data[1].mainMenuLink }"
        :level-third="{
          text: data[1].subMenu[3].text,
          link: data[1].subMenu[3].link,
        }"
      ></Breadcrumbs>
      <TabProducts :tab-active="3"></TabProducts>

      <div class="product-header">
        <div>
          <h1>{{ t("product-wearable-main-title") }}</h1>
          <p>
            {{ t("product-wearable-main-text") }}
          </p>
        </div>

        <div class="product-header-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0001.jpg"
            alt=""
          />
        </div>
      </div>
      <div class="product-body">
        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0004.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-wearable-subtitle01") }}</h2>
              <p>
                {{ t("product-wearable-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0005.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-wearable-subtitle02") }}</h2>
              <p>
                {{ t("product-wearable-text02") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0007.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-wearable-subtitle03") }}</h2>
              <p>
                {{ t("product-wearable-text03") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0003.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-wearable-subtitle04") }}</h2>
              <p>
                {{ t("product-wearable-text04") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0006.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-wearable-subtitle05") }}</h2>
              <p>
                {{ t("product-wearable-text05") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/wearable/0002.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-wearable-subtitle06") }}</h2>
              <p>
                {{ t("product-wearable-text06") }}
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>
