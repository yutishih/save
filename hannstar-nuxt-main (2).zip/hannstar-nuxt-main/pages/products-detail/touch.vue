<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("product-menu06") });
</script>

<template>
  <div>
    <div class="product-container">
      <Breadcrumbs
        :level-second="{ text: data[1].mainMenu, link: data[1].mainMenuLink }"
        :level-third="{
          text: data[1].subMenu[5].text,
          link: data[1].subMenu[5].link,
        }"
      ></Breadcrumbs>
      <TabProducts :tab-active="5"></TabProducts>

      <div class="product-header">
        <div>
          <h1>{{ t("product-touch-main-title") }}</h1>
          <p>
            {{ t("product-touch-main-text") }}
          </p>
        </div>

        <div class="product-header-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/document360/products-detail/touch/0001.jpg"
            alt=""
          />
        </div>
      </div>
      <div class="product-body">
        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/touch/0004.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-touch-subtitle01") }}</h2>
              <p>
                {{ t("product-touch-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/touch/0002.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-touch-subtitle02") }}</h2>
              <p>
                {{ t("product-touch-text02") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/touch/0005.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-touch-subtitle03") }}</h2>
              <p>
                {{ t("product-touch-text03") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/touch/0003.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-touch-subtitle04") }}</h2>
              <p>
                {{ t("product-touch-text04") }}
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>
