<script setup>
const { data } = useSitemap();
const { t } = useI18n();

//meta data
useMeta({ title: t("product-menu03") });
</script>

<template>
  <div>
    <div class="product-container">
      <Breadcrumbs
        :level-second="{ text: data[1].mainMenu, link: data[1].mainMenuLink }"
        :level-third="{
          text: data[1].subMenu[2].text,
          link: data[1].subMenu[2].link,
        }"
      ></Breadcrumbs>
      <TabProducts :tab-active="2"></TabProducts>

      <div class="product-header">
        <div>
          <h1>{{ t("product-mobile-main-title") }}</h1>
          <p>
            {{ t("product-mobile-main-text") }}
          </p>
        </div>

        <div class="product-header-img">
          <img
            src="https://media.hannstar.com/Image/hannstar/document360/products-detail/mobile/0001.jpg"
            alt=""
          />
        </div>
      </div>
      <div class="product-body">
        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/mobile/0003.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-mobile-subtitle01") }}</h2>
              <p>
                {{ t("product-mobile-text01") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/mobile/0004.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-mobile-subtitle02") }}</h2>
              <p>
                {{ t("product-mobile-text02") }}
              </p>
            </div>
          </div>
        </section>

        <section data-aos="fade-up">
          <div class="section-flex">
            <div class="product-body-img">
              <img
                src="https://media.hannstar.com/Image/hannstar/document360/products-detail/mobile/0002.jpg"
                alt=""
              />
            </div>
            <div class="product-body-content">
              <h2>{{ t("product-mobile-subtitle03") }}</h2>
              <p>
                {{ t("product-mobile-text03") }}
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>
