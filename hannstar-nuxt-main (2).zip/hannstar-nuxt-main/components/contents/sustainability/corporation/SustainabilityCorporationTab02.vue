<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="section-container section-goverance">
    <section class="esg-page-title">
      <h1>{{ t("sustainability-corporation-governance-main-title") }}</h1>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h3>{{ t("sustainability-corporation-governance-subtitle01") }}</h3>
          <p>
            {{ t("sustainability-corporation-governance-text01") }}
          </p>
        </div>
        <div class="image item-pc">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/csr/Rectangle2508.png"
            alt="永續治理"
          />
        </div>
      </div>
    </section>

    <section class="banner-image-middle-text" data-aos="fade-up">
      <div class="margin-left-right-10px">
        <div class="title">
          <h3>
            {{ t("sustainability-corporation-governance-subtitle02") }}
          </h3>
          <p>
            {{ t("sustainability-corporation-governance-text02") }}
          </p>
        </div>
        <div class="image item-pc">
          <img
            :src="t('sustainability-corporation-governance-image02_pc')"
            alt="瀚宇彩晶 永續藍圖"
          />
        </div>
        <div class="image item-mobile">
          <img
            :src="t('sustainability-corporation-governance-image02_mobile')"
            alt="瀚宇彩晶 永續藍圖 行動版本"
          />
        </div>
      </div>
    </section>

    <section class="banner-image-middle-text" data-aos="fade-up">
      <div class="margin-left-right-10px">
        <div class="title">
          <h3>
            {{ t("sustainability-corporation-governance-subtitle03") }}
          </h3>
        </div>
        <div class="image item-pc">
          <img
            :src="t('sustainability-corporation-governance-image03_pc')"
            alt="瀚宇彩晶 永續價值"
          />
        </div>
        <div class="image item-mobile">
          <img
            :src="t('sustainability-corporation-governance-image03_mobile')"
            alt="瀚宇彩晶 永續價值 行動版本"
          />
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.esg-page-title {
  text-align: center;
  padding: 30px 0;
}
.right-image-left-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column-reverse;
    }
    .image {
      width: 50%;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      h3 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
          text-align: center;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
    }
  }
}
.banner-image-middle-text {
  .title {
    margin: 0 auto;
    h3 {
      text-align: center;
      padding: 30px 0;
      @media (max-width: 980px) {
        padding: 10px 0;
        font-weight: 500;
        line-height: 48px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        text-align: center;
        @media (max-width: 980px) {
        }
      }
    }
    p {
      max-width: 1000px;
      margin: 0 auto;
      line-height: 28px;
      letter-spacing: 1px;
      padding-bottom: 30px;
      text-align: left;
    }
    .image {
      padding-bottom: 30px;
      img {
        width: 100%;
      }
    }
  }

  .item-pc {
    display: block;
    @media screen and (max-width: 980px) {
      display: none;
    }
  }
  .item-mobile {
    display: none;
    @media screen and (max-width: 980px) {
      display: block;
    }
  }
}
</style>
