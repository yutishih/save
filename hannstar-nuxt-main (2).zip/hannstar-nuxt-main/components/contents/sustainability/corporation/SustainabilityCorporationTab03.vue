<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="section-container section-negotiate">
    <!-- <section class="esg-page-title">
      <h1>利害關係人議合</h1>
    </section> -->

    <section data-aos="fade-up">
      <div class="esg-section-title">
        <div class="text">
          <h1>{{ t("sustainability-corporation-negotiate-main-title") }}</h1>
          <p>
            {{ t("sustainability-corporation-negotiate-main-text") }}
          </p>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="grid-wrap-3">
        <div class="grid-box">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/sustainablemanagement/demopic.png"
            />
          </div>
          <div class="text">
            <h5>
              1. {{ t("sustainability-corporation-negotiate-subtitle01") }}
            </h5>
            <p>
              {{ t("sustainability-corporation-negotiate-text01") }}
            </p>
          </div>
        </div>
        <div class="grid-box">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/sustainablemanagement/demopic_1.png"
            />
          </div>
          <div class="text">
            <h5>
              2. {{ t("sustainability-corporation-negotiate-subtitle02") }}
            </h5>
            <p>
              {{ t("sustainability-corporation-negotiate-text02") }}
            </p>
          </div>
        </div>
        <div class="grid-box">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/sustainablemanagement/demopic_2.png"
            />
          </div>
          <div class="text">
            <h5>
              3. {{ t("sustainability-corporation-negotiate-subtitle03") }}
            </h5>
            <p>
              {{ t("sustainability-corporation-negotiate-text03") }}
            </p>
          </div>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="single-image">
        <img :src="t('sustainability-corporation-negotiate-image03')" />
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="grid-wrap-3 gap-100">
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/sustainablemanagement/MaskGroup.png"
            />
          </div>
          <div class="list">
            <h4>
              {{ t("sustainability-corporation-negotiate-type01_title") }}
            </h4>
            <div class="list-justify-center">
              <ul>
                <li>
                  {{ t("sustainability-corporation-negotiate-type01_point01") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type01_point02") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type01_point03") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type01_point04") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type01_point05") }}
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/sustainablemanagement/MaskGroup_1.png"
            />
          </div>
          <div class="list">
            <h4>
              {{ t("sustainability-corporation-negotiate-type02_title") }}
            </h4>
            <div class="list-justify-center">
              <ul>
                <li>
                  {{ t("sustainability-corporation-negotiate-type02_point01") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type02_point02") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type02_point03") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type02_point04") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type02_point05") }}
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/sustainablemanagement/MaskGroup_2.png"
            />
          </div>
          <div class="list">
            <h4>
              {{ t("sustainability-corporation-negotiate-type03_title") }}
            </h4>
            <div class="list-justify-center">
              <ul>
                <li>
                  {{ t("sustainability-corporation-negotiate-type03_point01") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type03_point02") }}
                </li>
                <li>
                  {{ t("sustainability-corporation-negotiate-type03_point03") }}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="section-title">
        <h4>4. {{ t("sustainability-corporation-negotiate-subtitle04") }}</h4>
        <p>
          {{ t("sustainability-corporation-negotiate-text04") }}
        </p>
      </div>
      <div class="single-image item-pc">
        <img
          :src="t('sustainability-corporation-negotiate-image04_pc')"
          alt="重大永續議題辨識流程"
        />
      </div>
      <div class="single-image item-mobile">
        <img
          :src="t('sustainability-corporation-negotiate-image04_mobile')"
          alt="重大永續議題辨識流程"
        />
      </div>
      <div class="single-image item-pc">
        <img
          :src="t('sustainability-corporation-negotiate-image05_pc')"
          alt="重大永續議題辨識流程"
        />
      </div>
      <div class="single-image item-mobile">
        <img
          :src="t('sustainability-corporation-negotiate-image05_mobile')"
          alt="重大永續議題辨識流程"
        />
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="section-title">
        <h3>{{ t("sustainability-corporation-negotiate-subtitle05") }}</h3>
      </div>
      <div class="single-image item-pc">
        <img
          :src="t('sustainability-corporation-negotiate-image06_pc')"
          alt="利害關係人溝通"
        />
      </div>
      <div class="single-image item-mobile">
        <img
          :src="t('sustainability-corporation-negotiate-image06_mobile01')"
          alt="利害關係人溝通"
        />
      </div>
      <div class="single-image item-mobile">
        <img
          :src="t('sustainability-corporation-negotiate-image06_mobile02')"
          alt="利害關係人溝通"
        />
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
section {
  width: 100%;
  max-width: 1400px;
  margin: 0 auto 15px auto;
  @media (max-width: 980px) {
    margin: 0 auto 15px auto;
  }
  .section-title {
    padding: 30px 0;
    @media screen and (max-width: 980px) {
      padding: 0 0 30px 0;
    }
    h3 {
      text-align: center;
    }
    h4 {
      color: #039be5;
      padding: 15px 0;
    }
  }
  .single-image {
    padding-bottom: 30px;
  }
}
.esg-page-title {
  text-align: center;
}
.esg-section-title {
  .text {
    padding: 30px 0;
    h1 {
      text-align: center;
    }
    p {
      max-width: 1000px;
      margin: 0 auto;
    }
  }
}
.grid-wrap-3 {
  display: grid;
  grid-gap: 30px;
  justify-content: space-between;
  grid-template-columns: repeat(3, 1fr);
  padding-bottom: 30px;
  &.gap-100 {
    grid-gap: 100px;
    @media screen and (max-width: 980px) {
      grid-gap: 30px;
    }
  }
  @media screen and (max-width: 980px) {
    grid-template-columns: repeat(1, 1fr);
    grid-gap: 30px;
  }
  .grid-box {
    &.grid-shadow {
      box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2);
    }
    .text {
      h5 {
        color: #039be5;
        padding: 15px 0;
      }
    }
    .list {
      padding: 15px 0;
      h4 {
        color: #039be5;
        text-align: center;
        padding: 15px 0;
      }
      .list-justify-center {
        display: flex;
        justify-content: center;
        align-items: center;
        ul {
          list-style: disc;
          li {
            padding: 5px 0;
          }
        }
      }
    }
  }
}
.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
