<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="section-container section-chairman">
    <section class="esg-page-title">
      <h1>{{ t("sustainability-corporation-chairman-main-title") }}</h1>
    </section>
    <section data-aos="fade-up">
      <div class="paragraph">
        <h5 class="subtitle">
          {{ t("sustainability-corporation-chairman-subtitle01") }}
        </h5>
        <p class="content">
          {{ t("sustainability-corporation-chairman-text01") }}
        </p>
        <h5 class="sub-point">
          {{ t("sustainability-corporation-chairman-subtitle02") }}
        </h5>
        <p class="content">
          {{ t("sustainability-corporation-chairman-text02") }}
        </p>
        <h5 class="sub-point">
          {{ t("sustainability-corporation-chairman-subtitle03") }}
        </h5>
        <p class="content">
          {{ t("sustainability-corporation-chairman-text03") }}
        </p>
        <h5 class="sub-point">
          {{ t("sustainability-corporation-chairman-subtitle04") }}
        </h5>
        <p class="content">
          {{ t("sustainability-corporation-chairman-text04") }}
        </p>
        <h5 class="sub-point">
          {{ t("sustainability-corporation-chairman-subtitle05") }}
        </h5>
        <p class="content">
          {{ t("sustainability-corporation-chairman-text05_1") }}
        </p>
        <p class="content">
          {{ t("sustainability-corporation-chairman-text05_2") }}
        </p>
        <div class="chairman-signature">
          <img
            src="https://media.hannstar.com/Image/hannstar/document360/sustainability/corporation/chairmansign.png"
          />
        </div>
        <div class="chairman-name">
          <p>{{ t("sustainability-corporation-chairman-chairman_name") }}</p>
          <p>{{ t("sustainability-corporation-chairman-chairman_title") }}</p>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.section-chairman {
  .esg-page-title {
    text-align: center;
    padding: 30px 0;
  }
  .paragraph {
    text-align: left;
    .subtitle {
      font-weight: 600;
      padding-bottom: 20px;
    }
    .content {
      padding-bottom: 20px;
    }
    .sub-point {
      font-weight: 600;
      padding-bottom: 20px;
    }
    .chairman-signature {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      img {
        max-width: 180px;
        width: 100%;
      }
    }
    .chairman-name {
      p {
        display: flex;
        justify-content: flex-end;
        align-items: center;
      }
    }
  }
}
</style>
