<script setup>
const { t } = useI18n();
const data = [
  {
    date: t("sustainability-corporation-communicate-table-title01"),
    list: ["esg@hannstar.com"],
  },
  {
    date: t("sustainability-corporation-communicate-table-title02"),
    list: ["hr@hannstar.com"],
  },
  {
    date: t("sustainability-corporation-communicate-table-title03"),
    list: ["crm@hannstar.com"],
  },
  {
    date: t("sustainability-corporation-communicate-table-title04"),
    list: ["scm@hannstar.com"],
  },
  {
    date: t("sustainability-corporation-communicate-table-title05"),
    list: [
      t("sustainability-corporation-communicate-table-text01"),
      t("sustainability-corporation-communicate-table-text02"),
      t("sustainability-corporation-communicate-table-text03"),
    ],
  },
  {
    date: t("sustainability-corporation-communicate-table-title06"),
    list: [
      t("sustainability-corporation-communicate-table-text04"),
      t("sustainability-corporation-communicate-table-text05"),
      t("sustainability-corporation-communicate-table-text06"),
    ],
  },
  {
    date: t("sustainability-corporation-communicate-table-title07"),
    list: ["stakeholder@hannstar.com "],
  },
];
</script>

<template>
  <div class="sustainability-corporation-tab-content">
    <section class="esg-page-title">
      <h1>{{ t("sustainability-corporation-communicate-main-title") }}</h1>
    </section>
    <TableSideEsgCorporationCommunicate :table-body-data="data">
    </TableSideEsgCorporationCommunicate>
  </div>
</template>

<style scoped>
.sustainability-corporation-tab-content {
  .esg-page-title {
    text-align: center;
    padding: 30px 0 0 0;
  }
  table {
    text-align: center;
    tr {
      td {
        ul {
          list-style-type: none;
        }
      }
    }
  }
}
</style>
