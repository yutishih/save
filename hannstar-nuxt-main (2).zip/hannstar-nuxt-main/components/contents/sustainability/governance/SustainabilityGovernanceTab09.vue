<script setup>
const { t } = useI18n();

const { charterData } = useCharterData();
const toggleIndex = ref(null);
</script>

<template>
  <div class="sustainability-governance-charter-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-governance-charter-main-title") }}</h1>
      </div>
    </section>
    <section>
      <table>
        <tr class="tr-title">
          <th>{{ t("sustainability-governance-charter-table-head01") }}</th>
          <th>{{ t("sustainability-governance-charter-table-head02") }}</th>
          <th>{{ t("sustainability-governance-charter-table-head03") }}</th>
        </tr>
        <tr
          v-for="(item, index) in charterData"
          :key="index"
          class="tr-content"
        >
          <td>
            <p>{{ item.year }}</p>
          </td>
          <td>
            <p>{{ item.title }}</p>
          </td>
          <td>
            <a
              v-if="item.downloadLink && item.downloadLink !== ''"
              :href="item.downloadLink"
              target="_blank"
            >
              <img
                src="https://media.hannstar.com/Image/hannstar/download-PDF.png"
                alt=""
              />
            </a>
          </td>
        </tr>
      </table>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-charter-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    h1 {
      text-align: center;
      margin: 35px 0;
    }
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 20px auto 50px auto;
    .tr-title {
      th {
        text-align: left;
        padding-left: 10px;
      }
    }
    .tr-content {
      &:nth-child(odd) {
        background: rgb(247, 247, 247);
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      width: auto;
      min-width: 60px;
      min-height: 30px;
      &.text-center {
        text-align: center;
      }
      img {
        width: 30px;
      }
    }
  }
}
</style>
