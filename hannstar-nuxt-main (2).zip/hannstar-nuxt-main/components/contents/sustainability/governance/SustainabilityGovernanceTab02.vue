<script setup>
const { directorData, auditData } = useAuditData();
const { t } = useI18n();
const toggleIndex = ref(null);

const openCollapse = (i) => {
  if (toggleIndex.value === i) {
    toggleIndex.value = null;
  } else {
    toggleIndex.value = i;
  }
};
</script>

<template>
  <div class="sustainability-governance-audit-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-governance-audit-main-title") }}</h1>
      </div>
    </section>
    <section>
      <div class="table-text">
        <p class="w-600 pdb-10">
          {{ t("sustainability-governance-audit-subtitle01") }}
        </p>
        <p>{{ t("sustainability-governance-audit-text01") }}</p>
      </div>
      <table>
        <tr>
          <th>{{ t("sustainability-governance-audit-table01-head01") }}</th>
          <th>{{ t("sustainability-governance-audit-table01-head02") }}</th>
          <th>{{ t("sustainability-governance-audit-table01-head03") }}</th>
        </tr>
        <tr
          v-for="(item, index) in directorData"
          :key="index"
          class="tr-content"
        >
          <td class="text-center min-w-200 min-w-90-m">{{ item.title }}</td>
          <td class="text-center min-w-200 min-w-90-m">{{ item.name }}</td>
          <td>{{ item.positions }}</td>
        </tr>
      </table>

      <!-- PC Table  -->
      <div class="table-text">
        <p class="w-600">
          {{ t("sustainability-governance-audit-subtitle02") }}
        </p>
      </div>
      <table class="table-pc-component">
        <tr>
          <th>{{ t("sustainability-governance-audit-table02-head01") }}</th>
          <th>{{ t("sustainability-governance-audit-table02-head02") }}</th>
          <th>{{ t("sustainability-governance-audit-table02-head03") }}</th>
          <th>{{ t("sustainability-governance-audit-table02-head04") }}</th>
        </tr>
        <tr v-for="(item, index) in auditData" :key="index" class="tr-content">
          <td class="text-center min-w-150">
            <p>{{ item.date }}</p>
            <p>{{ item.meeting }}</p>
          </td>
          <td>
            <ul>
              <li v-for="(point, pIndex) in item.points" :key="pIndex">
                {{ point }}
              </li>
            </ul>
          </td>
          <td class="text-center">{{ item.advice }}</td>
          <td>{{ item.operation }}</td>
        </tr>
      </table>

      <!-- Mobile Table  -->
      <div class="mb-table-wrapper table-mobile-component">
        <div class="table-collapse">
          <div
            v-for="(item, index) in auditData"
            class="table-list"
            @click="openCollapse(index)"
          >
            <div class="list-flex">
              <p>
                <span>{{ item.date }}</span> <span>{{ item.meeting }}</span>
              </p>
              <span
                class="plus-icon"
                :class="{ open: toggleIndex === index }"
              ></span>
            </div>
            <div
              class="list-collapse"
              :class="{ active: toggleIndex === index }"
            >
              <div class="pd-10">
                <div class="points pdb-5">
                  <p class="w-600 pdb-5">
                    [{{ t("sustainability-governance-audit-table02-head02") }}]
                  </p>
                  <ul>
                    <li v-for="(point, pIndex) in item.points" :key="pIndex">
                      {{ point }}
                    </li>
                  </ul>
                </div>
                <div class="advice pdb-5">
                  <p class="w-600 pdb-5">
                    [{{ t("sustainability-governance-audit-table02-head03") }}]
                  </p>
                  <p>{{ item.advice }}</p>
                </div>
                <div class="operation pdb-5">
                  <p class="w-600 pdb-5">
                    [{{ t("sustainability-governance-audit-table02-head04") }}]
                  </p>
                  <p>{{ item.operation }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-audit-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    h1 {
      text-align: center;
      margin: 35px 0;
    }
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 20px auto 50px auto;

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }
    .tr-content {
      &:nth-child(odd) {
        background: rgb(247, 247, 247);
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      width: auto;
      min-width: 100px;
      min-height: 30px;
      &.text-center {
        text-align: center;
      }
      &.min-w-200 {
        min-width: 200px;
      }
      &.min-w-150 {
        min-width: 150px;
      }
      ul {
        list-style-type: decimal;
        padding-left: 20px;
      }
    }

    @media screen and (max-width: 980px) {
      td {
        &.min-w-90-m {
          min-width: 90px;
        }
      }
    }
  }
  .table-text {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    .w-600 {
      font-weight: 600;
    }
    .pdb-10 {
      padding-bottom: 10px;
    }
  }
}
.plus-icon {
  position: relative;
  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}

.mb-table-wrapper {
  padding: 15px 20px 20px 20px;
  border: 1px solid #b9b9b9;
  box-sizing: border-box;
  display: flex;
  margin: 25px 40px;

  .table-collapse {
    display: block;
    width: 100%;
  }

  .table-list {
    width: 100%;
    display: block;
    padding: 15px 0;
    border-bottom: 1px solid #b9b9b9;
    cursor: pointer;

    .list-flex {
      display: flex;
      justify-content: space-between;
      p {
        span {
          font-weight: 600;
        }
      }
    }
  }

  .list-collapse {
    height: 0;
    transition: 0.5s;
    overflow: hidden;
    .pd-10 {
      padding-top: 10px;
    }
    .pdb-5 {
      padding-bottom: 5px;
    }
    .w-600 {
      font-weight: 600;
    }
    div {
      opacity: 0;
      transition: 0.5s;
    }
    &.active {
      height: auto;

      div {
        opacity: 1;
      }
    }
    ul {
      list-style-type: decimal;
      padding-left: 20px;
    }
  }
}

@media screen and (max-width: 968px) {
  .table-pc-component {
    display: none;
  }
}

@media screen and (min-width: 968px) {
  .table-mobile-component {
    display: none;
  }
}
</style>
