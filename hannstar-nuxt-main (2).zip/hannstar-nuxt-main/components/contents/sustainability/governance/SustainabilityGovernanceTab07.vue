<script setup>
const { t } = useI18n();

const sustainabilityKeypoint = ref([
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/governance/InfoSecurityIcon1.png",
    mainText1: t("sustainability-governance-infoSecurity-point01-text01"),
    mainText2: t("sustainability-governance-infoSecurity-point01-text02"),
    mainText3: t("sustainability-governance-infoSecurity-point01-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/governance/InfoSecurityIcon2.png",
    mainText1: t("sustainability-governance-infoSecurity-point02-text01"),
    mainText2: t("sustainability-governance-infoSecurity-point02-text02"),
    mainText3: t("sustainability-governance-infoSecurity-point02-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/governance/InfoSecurityIcon3.png",
    mainText1: t("sustainability-governance-infoSecurity-point03-text01"),
    mainText2: t("sustainability-governance-infoSecurity-point03-text02"),
    mainText3: t("sustainability-governance-infoSecurity-point03-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/governance/InfoSecurityIcon4.png",
    mainText1: t("sustainability-governance-infoSecurity-point04-text01"),
    mainText2: t("sustainability-governance-infoSecurity-point04-text02"),
    mainText3: t("sustainability-governance-infoSecurity-point04-text03"),
  },
]);
</script>

<template>
  <div class="sustainability-governance-infoSecurity-tab-content">
    <div class="section-container">
      <section class="esg-page-title">
        <h1>{{ t("sustainability-governance-infoSecurity-main-title") }}</h1>
      </section>

      <section class="index-eight-squares">
        <div class="index-eight-squares-container">
          <div
            class="squares"
            v-for="(item, index) in sustainabilityKeypoint"
            :key="index"
            data-aos="flip-up"
            :data-aos-delay="`${index * 100}`"
          >
            <div class="main-title">
              <img :src="item.icon" alt="多元平等" />
              <div>
                <p class="main-text-style-3">
                  {{ item.mainText1
                  }}<span class="main-text-style-2">{{ item.mainText2 }}</span>
                </p>
                <p class="main-text-style-1">
                  {{ item.mainText3 }}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="right-image-left-text" data-aos="fade-up">
        <div class="flex-wrap margin-left-right-10px">
          <div class="text">
            <h4>
              {{ t("sustainability-governance-infoSecurity-subtitle01") }}
            </h4>
            <p>
              {{ t("sustainability-governance-infoSecurity-text01") }}
            </p>
          </div>
          <div class="image">
            <img
              :src="t('sustainability-governance-infoSecurity-image01')"
              alt="資訊安全政策"
            />
          </div>
        </div>
      </section>

      <section class="left-image-right-text" data-aos="fade-up">
        <div class="flex-wrap margin-left-right-10px">
          <div class="image">
            <img
              :src="t('sustainability-governance-infoSecurity-image02')"
              alt="資訊安全管理委員會"
            />
          </div>
          <div class="text">
            <h4>
              {{ t("sustainability-governance-infoSecurity-subtitle02") }}
            </h4>
            <p>
              {{ t("sustainability-governance-infoSecurity-text02") }}
            </p>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-infoSecurity-tab-content {
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;

  section {
    padding-bottom: 30px;
  }
  .top-banner {
    position: relative;
    img {
      max-height: 400px;
      width: 100%;
      object-fit: cover;
    }
    .main-banner-text-middle {
      position: absolute;
      width: 100%;
      top: 50%;
      bottom: auto;
      left: 50%;
      transform: translate(-50%, -50%);
      h2 {
        color: #fff;
        text-align: center;
        text-shadow: 1px 1px 2px #363636;
      }
    }
  }
  .esg-page-title {
    text-align: center;
    padding: 35px 0;
    h1 {
      margin: 0;
    }
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      // margin: 0 auto;
      grid-template-columns: repeat(4, 1fr);
      grid-gap: 10px;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        background-color: #f1eaf4;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 100%;
          padding: 5px;
          text-align: center;
          transform: translate(-50%, -50%);
          color: #217fc4;
          @media screen and (max-width: 768px) {
            max-width: 250px;
          }
          .main-text-style-1 {
            font-size: 20px;
            margin: 0;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 0.8em;
              padding-bottom: 0;
              line-height: 1.25em;
            }
          }
          .main-text-style-2 {
            font-size: 20px;
            padding-bottom: 10px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
            }
          }
          .main-text-style-3 {
            font-size: 2.5em;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 2em;
              padding-bottom: 0;
            }
          }
        }
        img {
          max-width: 80px;
          margin: 0 auto;
          padding-bottom: 20px;
          @media screen and (max-width: 768px) {
            max-width: 50px;
            padding-bottom: 5px;
          }
        }
      }
    }
  }

  .right-image-left-text {
    .flex-wrap {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 10px;
      @media (max-width: 980px) {
        flex-direction: column-reverse;
      }
      .image {
        width: 50%;
        padding-left: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 0 10px;
        }
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }
      .text {
        width: 50%;
        text-align: left;
        padding-right: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 10px;
        }
        h4 {
          font-weight: 400;
          line-height: 36px;
          letter-spacing: 1px;
          padding-bottom: 30px;
          @media (max-width: 980px) {
            padding: 30px 0;
          }
        }
        p {
          line-height: 28px;
          font-weight: 400;
          letter-spacing: 1px;
        }
      }
    }
  }

  .left-image-right-text {
    .flex-wrap {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 10px;
      @media (max-width: 980px) {
        flex-direction: column;
      }
      .image {
        width: 50%;
        padding-right: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 0 10px;
        }
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }
      .text {
        width: 50%;
        text-align: left;
        padding-left: 30px;
        @media (max-width: 980px) {
          width: 100%;
          padding: 0 10px;
        }
        h4 {
          font-weight: 400;
          line-height: 36px;
          letter-spacing: 1px;
          padding-bottom: 30px;
          @media (max-width: 980px) {
            padding: 30px 0;
          }
        }
        p {
          line-height: 28px;
          font-weight: 400;
          letter-spacing: 1px;
        }
      }
    }
  }
}
</style>
