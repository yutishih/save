<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-governance-operate-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-governance-trade-main-title") }}</h1>
      </div>
    </section>
    <section data-aos="fade-up">
      <div class="table-text">
        <p class="pdb-20">
          {{ t("sustainability-governance-trade-text01") }}
        </p>
        <p class="pdb-20">{{ t("sustainability-governance-trade-text02") }}</p>
        <ul class="pdb-20">
          <li>
            <p>{{ t("sustainability-governance-trade-text03") }}</p>
            <p>{{ t("sustainability-governance-trade-text04") }}</p>
            <p>{{ t("sustainability-governance-trade-text05") }}</p>
            <p>
              {{ t("sustainability-governance-trade-text06") }}
            </p>
            <p>
              {{ t("sustainability-governance-trade-text07") }}
            </p>
          </li>
          <li>
            {{ t("sustainability-governance-trade-text08") }}
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-operate-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    h1 {
      text-align: center;
      margin: 35px 0;
    }
  }
  .table-text {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    ul {
      list-style-type: decimal;
      padding-left: 20px;
      li {
        padding-bottom: 10px;
      }
    }
    .w-600 {
      font-weight: 600;
    }
    .pdb-10 {
      padding-bottom: 10px;
    }
    .pdb-20 {
      padding-bottom: 20px;
    }
    a {
      color: #06f;
    }
  }
}
</style>
