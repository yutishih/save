<script setup>
const { checkData } = useCheckData();
const { t } = useI18n();
const toggleIndex = ref(null);

const openCollapse = (i) => {
  if (toggleIndex.value === i) {
    toggleIndex.value = null;
  } else {
    toggleIndex.value = i;
  }
};
</script>

<template>
  <div class="sustainability-governance-check-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-governance-check-main-title") }}</h1>
      </div>
    </section>
    <section>
      <!-- PC Table  -->
      <div class="table-text">
        <p class="w-600">
          {{ t("sustainability-governance-check-subtitle01") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-check-text01") }}
        </p>
        <p class="w-600">
          {{ t("sustainability-governance-check-subtitle02") }}
        </p>

        <ul class="pdb-20">
          <li>
            {{ t("sustainability-governance-check-text02_1") }}
          </li>
          <li>
            {{ t("sustainability-governance-check-text02_2") }}
          </li>
          <li>
            {{ t("sustainability-governance-check-text02_3") }}
          </li>
          <li>
            {{ t("sustainability-governance-check-text02_4") }}
          </li>
        </ul>

        <p class="w-600">
          {{ t("sustainability-governance-check-subtitle03") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-check-text03") }}
        </p>
        <p class="w-600">
          {{ t("sustainability-governance-check-subtitle04") }}
        </p>
      </div>
      <table class="table-pc-component">
        <tr>
          <th>{{ t("sustainability-governance-check-table-head01") }}</th>
          <th>{{ t("sustainability-governance-check-table-head02") }}</th>
          <th>{{ t("sustainability-governance-check-table-head03") }}</th>
        </tr>
        <tr v-for="(item, index) in checkData" :key="index" class="tr-content">
          <td class="text-center min-w-200">
            <p>{{ item.date }}</p>
            <p>{{ item.meeting }}</p>
          </td>
          <td class="min-w-200">
            <ul>
              <li v-for="(point, pIndex) in item.communication" :key="pIndex">
                {{ point }}
              </li>
            </ul>
          </td>
          <td>
            <ul>
              <li v-for="(result, rIndex) in item.conclusion" :key="rIndex">
                {{ result }}
              </li>
            </ul>
          </td>
        </tr>
      </table>

      <!-- Mobile Table  -->
      <div class="mb-table-wrapper table-mobile-component">
        <div class="table-collapse">
          <div
            v-for="(item, index) in checkData"
            class="table-list"
            @click="openCollapse(index)"
          >
            <div class="list-flex">
              <p>
                <span>{{ item.date }}</span> <span>{{ item.meeting }}</span>
              </p>
              <span
                class="plus-icon"
                :class="{ open: toggleIndex === index }"
              ></span>
            </div>
            <div
              class="list-collapse"
              :class="{ active: toggleIndex === index }"
            >
              <div class="pd-10">
                <div class="points pdb-5">
                  <p class="w-600 pdb-5">
                    [{{ t("sustainability-governance-check-table-head02") }}]
                  </p>
                  <ul>
                    <li
                      v-for="(point, pIndex) in item.communication"
                      :key="pIndex"
                    >
                      {{ point }}
                    </li>
                  </ul>
                </div>
                <div class="operation pdb-5">
                  <p class="w-600 pdb-5">
                    [{{ t("sustainability-governance-check-table-head03") }}]
                  </p>
                  <ul>
                    <li
                      v-for="(result, rIndex) in item.conclusion"
                      :key="rIndex"
                    >
                      {{ result }}
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="table-text">
        <p class="w-600 pdb-10">
          {{ t("sustainability-governance-check-subtitle05") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-check-text05_1") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-check-text05_2") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-check-text05_3") }}：<a href="#"
            >stakeholder@hannstar.com</a
          >
        </p>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-check-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    h1 {
      text-align: center;
      margin: 35px 0;
    }
  }

  table {
    max-width: 1400px;
    width: 90%;
    margin: 20px auto 50px auto;

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }
    .tr-content {
      &:nth-child(odd) {
        background: rgb(247, 247, 247);
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      width: auto;
      min-width: 100px;
      min-height: 30px;
      &.text-center {
        text-align: center;
      }
      &.min-w-200 {
        min-width: 200px;
      }
      &.min-w-150 {
        min-width: 150px;
      }
      ul {
        list-style-type: decimal;
        padding-left: 20px;
      }
    }

    @media screen and (max-width: 968px) {
      td {
        &.min-w-90-m {
          min-width: 90px;
        }
      }
    }
  }
  .table-text {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    ul {
      list-style: decimal;
      padding-left: 20px;
    }
    .w-600 {
      font-weight: 600;
    }
    .pdb-10 {
      padding-bottom: 10px;
    }
    .pdb-20 {
      padding-bottom: 20px;
    }
    a {
      color: #06f;
    }
  }
}
.plus-icon {
  position: relative;
  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}

.mb-table-wrapper {
  padding: 15px 20px 20px 20px;
  border: 1px solid #b9b9b9;
  box-sizing: border-box;
  display: flex;
  margin: 25px 40px;

  .table-collapse {
    display: block;
    width: 100%;
  }

  .table-list {
    width: 100%;
    display: block;
    padding: 15px 0;
    border-bottom: 1px solid #b9b9b9;
    cursor: pointer;

    .list-flex {
      display: flex;
      justify-content: space-between;
      p {
        span {
          font-weight: 600;
        }
      }
    }
  }

  .list-collapse {
    height: 0;
    transition: 0.5s;
    overflow: hidden;
    .pd-10 {
      padding-top: 10px;
    }
    .pdb-5 {
      padding-bottom: 5px;
    }
    .w-600 {
      font-weight: 600;
    }
    div {
      opacity: 0;
      transition: 0.5s;
    }
    &.active {
      height: auto;

      div {
        opacity: 1;
      }
    }
    ul {
      list-style-type: decimal;
      padding-left: 20px;
    }
  }
}

@media screen and (max-width: 968px) {
  .table-pc-component {
    display: none;
  }
}

@media screen and (min-width: 968px) {
  .table-mobile-component {
    display: none;
  }
}
</style>
