<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-governance-operate-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-governance-operate-main-title") }}</h1>
      </div>
    </section>
    <section data-aos="fade-up">
      <div class="table-text">
        <p class="w-600 pdb-10">
          {{ t("sustainability-governance-operate-subtitle") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-operate-text01") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-operate-text02") }}
        </p>
        <p class="pdb-20">
          {{ t("sustainability-governance-operate-text03") }}
        </p>
        <ul class="pdb-20">
          <li>
            {{ t("sustainability-governance-operate-text04_1") }}
          </li>
          <li>
            {{ t("sustainability-governance-operate-text04_2") }}
          </li>
          <li>
            {{ t("sustainability-governance-operate-text04_3") }}
          </li>
          <li>
            {{ t("sustainability-governance-operate-text04_4") }}
          </li>
          <li>
            {{ t("sustainability-governance-operate-text04_5") }}
          </li>
        </ul>
        <p class="pdb-20">
          {{ t("sustainability-governance-operate-text05") }}
        </p>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-operate-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    h1 {
      text-align: center;
      margin: 35px 0;
    }
  }
  .table-text {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    ul {
      list-style-type: disc;
      padding-left: 20px;
      li {
        padding-bottom: 10px;
      }
    }
    .w-600 {
      font-weight: 600;
    }
    .pdb-10 {
      padding-bottom: 10px;
    }
    .pdb-20 {
      padding-bottom: 20px;
    }
    a {
      color: #06f;
    }
  }
}
</style>
