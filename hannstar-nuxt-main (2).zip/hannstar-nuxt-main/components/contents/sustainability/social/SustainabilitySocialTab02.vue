<script setup>
const { t } = useI18n();
const sustainabilityKeypoint = ref([
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/TalentsIcon1.png",
    mainText1: t("sustainability-social-talents-point01-text01"),
    mainText2: t("sustainability-social-talents-point01-text02"),
    mainText3: t("sustainability-social-talents-point01-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/TalentsIcon2.png",
    mainText1: t("sustainability-social-talents-point02-text01"),
    mainText2: t("sustainability-social-talents-point02-text02"),
    mainText3: t("sustainability-social-talents-point02-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/TalentsIcon3.png",
    mainText1: t("sustainability-social-talents-point03-text01"),
    mainText2: t("sustainability-social-talents-point03-text02"),
    mainText3: t("sustainability-social-talents-point03-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/TalentsIcon4.png",
    mainText1: t("sustainability-social-talents-point04-text01"),
    mainText2: t("sustainability-social-talents-point04-text02"),
    mainText3: t("sustainability-social-talents-point04-text03"),
  },
]);
</script>

<template>
  <div class="sustainability-social-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-talents-main-title") }}</h1>
      </div>
    </section>

    <section class="index-eight-squares">
      <div class="index-eight-squares-container">
        <div
          class="squares"
          v-for="(item, index) in sustainabilityKeypoint"
          :key="index"
          data-aos="flip-up"
          :data-aos-delay="`${index * 100}`"
        >
          <div class="main-title">
            <img :src="item.icon" alt="多元平等" />
            <div>
              <p class="main-text-style-3">
                {{ item.mainText1
                }}<span class="main-text-style-2">{{ item.mainText2 }}</span>
              </p>
              <p class="main-text-style-1">
                {{ item.mainText3 }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-talents-subtitle01") }}</h4>
          <p>
            {{ t("sustainability-social-talents-text01") }}
          </p>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/development/Rectangle2508.png"
            alt="資訊安全政策"
          />
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/development/Rectangle2508_1.png"
            alt="資訊安全管理委員會"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-talents-subtitle02") }}</h4>
          <p>
            {{ t("sustainability-social-talents-text02") }}
          </p>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-social-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  section {
    max-width: 1400px;
    margin: 0 auto;
    padding-bottom: 30px;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
      P {
        width: 90%;
        margin: 0 auto;
        max-width: 1000px;
      }
    }
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      // margin: 0 auto;
      grid-template-columns: repeat(4, 1fr);
      grid-gap: 10px;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        background-color: #f1eaf4;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 280px;
          text-align: center;
          transform: translate(-50%, -50%);
          color: #a56bab;
          @media screen and (max-width: 768px) {
            width: 150px;
          }
          .main-text-style-1 {
            font-size: 20px;
            margin: 0;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 20px;
              padding-bottom: 10px;
            }
          }
          .main-text-style-2 {
            font-size: 20px;
            padding-bottom: 10px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
            }
          }
          .main-text-style-3 {
            font-size: 48px;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 32px;
              padding-bottom: 10px;
            }
          }
        }
        img {
          max-width: 80px;
          margin: 0 auto;
          padding-bottom: 20px;
          @media screen and (max-width: 768px) {
            padding-bottom: 10px;
          }
        }
      }
    }
  }
}
.page-banner-text-inside {
  position: relative;

  img {
    width: 100%;
    object-fit: cover;
    max-height: 400px;
  }

  .hannstar-page-banner-text {
    position: absolute;
    width: 700px;
    box-sizing: border-box;
    left: 7.5%;
    bottom: 15%;

    @media (max-width: 968px) {
      background-color: #a0ddff;
      position: relative;
      width: 100%;
      left: 0;
      bottom: 0;
      padding: 20px;
      box-sizing: border-box;
    }

    h2 {
      color: #fff;
      margin-bottom: 25px;
      line-height: 1.5;
      text-shadow: 1px 1px 2px #fff;
      text-align: left;

      &.black-color {
        color: #000;
        text-shadow: 1px 1px 2px #fff;
      }
      @media screen and (max-width: 968px) {
        color: #000;
      }
    }

    p {
      color: #fff;
      line-height: 24px;
      letter-spacing: 0.14px;
      @media screen and (max-width: 968px) {
        color: #000;
      }
    }
  }
}
.single-image-section {
  padding: 30px 0;
  .title {
    width: 1000px;
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.left-image-right-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column;
    }
    .image {
      width: 50%;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
    }
  }
}
.right-image-left-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column-reverse;
    }
    .image {
      width: 50%;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
    }
  }
}

.grid-section {
  .section-title {
    width: 90%;
    text-align: center;
    margin: 0 auto;
    padding-bottom: 30px;
  }
  .grid-wrap-3 {
    display: grid;
    grid-gap: 30px;
    justify-content: space-between;
    grid-template-columns: repeat(3, 1fr);
    padding-bottom: 30px;
    &.gap-50 {
      grid-gap: 50px;
      @media screen and (max-width: 980px) {
        grid-gap: 30px;
      }
    }
    @media screen and (max-width: 980px) {
      grid-template-columns: repeat(1, 1fr);
      grid-gap: 30px;
    }
    .grid-box {
      position: relative;
      aspect-ratio: 1/1;
      background-color: #f1eaf4;
      &.grid-shadow {
        box-shadow: 4px 4px 12px -2px rgba(20%, 20%, 40%, 0.5);
      }
      .absolute-center {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        h4 {
          color: #a56bab;
          font-size: 48px;
          padding-bottom: 20px;
          span {
            font-size: 24px;
          }
        }
        p {
          width: 250px;
          color: #a56bab;
          font-size: 24px;
          padding-bottom: 10px;
        }
      }
      @media screen and (max-width: 968px) {
        margin: 10px 20px;
      }
    }
  }
}

.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
