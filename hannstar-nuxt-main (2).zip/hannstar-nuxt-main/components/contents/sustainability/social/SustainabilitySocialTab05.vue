<script setup>
const { t } = useI18n();
window.location.href = "https://hannstarfoundation.org/";
// window.open("https://hannstarfoundation.org/", "_blank");
</script>
<template>
  <div></div>
</template>

<style lang="scss" scoped></style>
