<script setup>
const { t } = useI18n();
const { RBAData } = useRBAData();
const toggleIndex = ref(null);

const openCollapse = (i) => {
  if (toggleIndex.value === i) {
    toggleIndex.value = null;
  } else {
    toggleIndex.value = i;
  }
};
</script>

<template>
  <div class="sustainability-governance-audit-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-RBA-main-title") }}</h1>
      </div>
    </section>

    <section>
      <!-- PC Table  -->
      <table class="table-pc-component">
        <tr>
          <th>{{ t("sustainability-social-RBA-table-head01") }}</th>
          <th>{{ t("sustainability-social-RBA-table-head02") }}</th>
          <th>{{ t("sustainability-social-RBA-table-head03") }}</th>
          <th>{{ t("sustainability-social-RBA-table-head04") }}</th>
        </tr>
        <tr v-for="(item, index) in RBAData" :key="index" class="tr-content">
          <td class="min-w-200 min-w-90-m">{{ item.object }}</td>
          <td class="min-w-200 min-w-90-m">{{ item.content }}</td>
          <td>{{ item.goal }}</td>
          <td>{{ item.achievement }}</td>
        </tr>
      </table>

      <!-- Mobile Table  -->
      <div class="mb-table-wrapper table-mobile-component">
        <div class="table-collapse">
          <div
            v-for="(item, index) in RBAData"
            class="table-list"
            @click="openCollapse(index)"
          >
            <div class="list-flex">
              <p>
                <span>{{ item.object }}</span>
              </p>
              <span
                class="plus-icon"
                :class="{ open: toggleIndex === index }"
              ></span>
            </div>
            <div
              class="list-collapse"
              :class="{ active: toggleIndex === index }"
            >
              <div class="pd-10">
                <div class="advice pdb-5">
                  <p>
                    {{ t("sustainability-social-RBA-table-head02") }}:
                    {{ item.content }}
                  </p>
                </div>
              </div>
              <div class="pd-10">
                <div class="advice pdb-5">
                  <p>
                    {{ t("sustainability-social-RBA-table-head03") }}:
                    {{ item.goal }}
                  </p>
                </div>
              </div>
              <div class="pd-10">
                <div class="advice pdb-5">
                  <p>
                    {{ t("sustainability-social-RBA-table-head03") }}:
                    {{ item.achievement }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-governance-audit-tab-content {
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;
  .title {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    h1 {
      text-align: center;
    }
  }

  table {
    max-width: 1400px;
    margin: 20px auto 50px auto;

    .tr-title {
      td {
        background-color: rgb(232, 232, 232);
        text-align: center;
        border: 1px solid rgb(242, 242, 242);
        padding: 10px;
      }
    }
    .tr-content {
      &:nth-child(odd) {
        background: rgb(247, 247, 247);
      }
    }

    th {
      text-align: center;
      background-color: rgb(0, 148, 218);
      border-color: rgb(238, 238, 238);
      color: #fff;
      padding: 10px 0;
      box-sizing: border-box;
    }

    td {
      border: 1px solid rgb(238, 238, 238);
      padding: 10px;
      text-align: left;
      width: auto;
      min-width: 100px;
      height: 100px;
      min-height: 30px;
      &.text-center {
        text-align: center;
      }
      &.min-w-200 {
        min-width: 200px;
      }
      &.min-w-150 {
        min-width: 150px;
      }
      ul {
        list-style-type: decimal;
        padding-left: 20px;
      }
    }

    @media screen and (max-width: 968px) {
      td {
        &.min-w-90-m {
          min-width: 90px;
        }
      }
    }
  }
  .table-text {
    max-width: 1400px;
    width: 90%;
    margin: 0 auto;
    .w-600 {
      font-weight: 600;
    }
    .pdb-10 {
      padding-bottom: 10px;
    }
  }
}
.plus-icon {
  position: relative;
  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}

.mb-table-wrapper {
  padding: 15px 20px 20px 20px;
  border: 1px solid #b9b9b9;
  box-sizing: border-box;
  display: flex;
  margin: 25px 40px;

  .table-collapse {
    display: block;
    width: 100%;
  }

  .table-list {
    width: 100%;
    display: block;
    padding: 15px 0;
    border-bottom: 1px solid #b9b9b9;
    cursor: pointer;

    .list-flex {
      display: flex;
      justify-content: space-between;
      p {
        span {
          font-weight: 600;
        }
      }
    }
  }

  .list-collapse {
    height: 0;
    transition: 0.5s;
    overflow: hidden;
    .pd-10 {
      padding-top: 10px;
    }
    .pdb-5 {
      padding-bottom: 5px;
    }
    .w-600 {
      font-weight: 600;
    }
    div {
      opacity: 0;
      transition: 0.5s;
    }
    &.active {
      height: auto;

      div {
        opacity: 1;
      }
    }
    ul {
      list-style-type: decimal;
      padding-left: 20px;
    }
  }
}

@media screen and (max-width: 968px) {
  .table-pc-component {
    display: none;
  }
}

@media screen and (min-width: 968px) {
  .table-mobile-component {
    display: none;
  }
}
</style>
