<script setup>
const { t } = useI18n();
const sustainabilityKeypoint = ref([
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/EqualityIcon1.png",
    mainText1: t("sustainability-social-equality-point01-text01"),
    mainText2: t("sustainability-social-equality-point01-text02"),
    mainText3: t("sustainability-social-equality-point01-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/EqualityIcon2.png",
    mainText1: t("sustainability-social-equality-point02-text01"),
    mainText2: t("sustainability-social-equality-point02-text02"),
    mainText3: t("sustainability-social-equality-point02-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/EqualityIcon3.png",
    mainText1: t("sustainability-social-equality-point03-text01"),
    mainText2: t("sustainability-social-equality-point03-text02"),
    mainText3: t("sustainability-social-equality-point03-text03"),
  },
  {
    icon: "https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/EqualityIcon4.png",
    mainText1: t("sustainability-social-equality-point04-text01"),
    mainText2: t("sustainability-social-equality-point04-text02"),
    mainText3: t("sustainability-social-equality-point04-text03"),
  },
]);

const sustainabilityEmployee = ref([
  {
    mainNTD: t("sustainability-social-equality-salary-median01-ntd"),
    mainText1: t("sustainability-social-equality-salary-median01-text01"),
    mainText2: t("sustainability-social-equality-salary-median01-text02"),
    mainText3: t("sustainability-social-equality-salary-median01-text03"),
    mainText4: t("sustainability-social-equality-salary-median01-text04"),
  },
  {
    mainNTD: t("sustainability-social-equality-salary-median02-ntd"),
    mainText1: t("sustainability-social-equality-salary-median02-text01"),
    mainText2: t("sustainability-social-equality-salary-median02-text02"),
    mainText3: t("sustainability-social-equality-salary-median02-text03"),
    mainText4: t("sustainability-social-equality-salary-median02-text04"),
  },
  {
    mainNTD: t("sustainability-social-equality-salary-median03-ntd"),
    mainText1: t("sustainability-social-equality-salary-median03-text01"),
    mainText2: t("sustainability-social-equality-salary-median03-text02"),
    mainText3: t("sustainability-social-equality-salary-median03-text03"),
    mainText4: t("sustainability-social-equality-salary-median03-text04"),
  },
]);

const sustainabilityMaternity = ref([
  {
    mainText1: t("sustainability-social-equality-maternity01-text01"),
    mainText2: t("sustainability-social-equality-maternity01-text02"),
    mainText3: t("sustainability-social-equality-maternity01-text03"),
  },
  {
    mainText1: t("sustainability-social-equality-maternity02-text01"),
    mainText2: t("sustainability-social-equality-maternity02-text02"),
    mainText3: t("sustainability-social-equality-maternity02-text03"),
  },
  {
    mainText1: t("sustainability-social-equality-maternity03-text01"),
    mainText2: t("sustainability-social-equality-maternity03-text02"),
    mainText3: t("sustainability-social-equality-maternity03-text03"),
  },
]);
</script>

<template>
  <div class="sustainability-social-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-equality-main-title") }}</h1>
        <p>
          {{ t("sustainability-social-equality-main-text") }}
        </p>
      </div>
    </section>

    <section class="index-eight-squares">
      <div class="index-eight-squares-container">
        <div
          class="squares"
          v-for="(item, index) in sustainabilityKeypoint"
          :key="index"
          data-aos="flip-up"
          :data-aos-delay="`${index * 100}`"
        >
          <div class="main-title">
            <img :src="item.icon" alt="多元平等" />
            <div>
              <p class="main-text-style-3">
                {{ item.mainText1
                }}<span class="main-text-style-2">{{ item.mainText2 }}</span>
              </p>
              <p class="main-text-style-1">
                {{ item.mainText3 }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="page-banner-text-inside">
        <img
          src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/image358_1.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2>{{ t("sustainability-social-equality-subtitle01") }}</h2>
          <p>
            {{ t("sustainability-social-equality-text01") }}
          </p>
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/diversity/Rectangle2503.png"
            alt="資訊安全管理委員會"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-equality-subtitle02") }}</h4>
          <p>
            {{ t("sustainability-social-equality-text02") }}
          </p>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-equality-subtitle03") }}</h4>
          <p>
            {{ t("sustainability-social-equality-text03") }}
          </p>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/diversity/Rectangle2504.png"
            alt="資訊安全政策"
          />
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/social_child_labor.png"
            alt="資訊安全管理委員會"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-equality-subtitle04") }}</h4>
          <p>
            {{ t("sustainability-social-equality-text04") }}
          </p>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-equality-subtitle05") }}</h4>
          <p>
            {{ t("sustainability-social-equality-text05") }}
          </p>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/diversity/Rectangle2500.png"
            alt="資訊安全政策"
          />
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/Rectangle2505.png"
            alt="資訊安全管理委員會"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-equality-subtitle06") }}</h4>
          <p>
            {{ t("sustainability-social-equality-text06") }}
          </p>
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="page-banner-text-inside">
        <img
          src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/Group63412.png"
          alt=""
        />
        <div class="hannstar-page-banner-text">
          <h2>{{ t("sustainability-social-equality-subtitle07") }}</h2>
          <p>
            {{ t("sustainability-social-equality-text07") }}
          </p>
        </div>
      </div>
    </section>

    <section class="grid-section">
      <div class="section-title">
        <h2>{{ t("sustainability-social-equality-subtitle08") }}</h2>
      </div>
      <div class="grid-wrap-3 gap-50">
        <div
          v-for="(v, id) in sustainabilityEmployee"
          :key="id"
          class="grid-box grid-shadow"
          data-aos="flip-up"
          :data-aos-delay="`${id * 100}`"
        >
          <div class="absolute-center">
            <h4>
              <span>{{ v.mainNTD }}</span
              >{{ v.mainText1 }}<span>{{ v.mainText2 }}</span>
            </h4>
            <p>{{ v.mainText3 }}</p>
            <p>{{ v.mainText4 }}</p>
          </div>
        </div>
      </div>
    </section>

    <section class="grid-section">
      <div class="section-title">
        <h2>{{ t("sustainability-social-equality-subtitle09") }}</h2>
      </div>
      <div class="grid-wrap-3 gap-50">
        <div
          v-for="(v, id) in sustainabilityMaternity"
          :key="id"
          class="grid-box grid-shadow"
          data-aos="flip-up"
          :data-aos-delay="`${id * 100}`"
        >
          <div class="absolute-center">
            <h4>
              {{ v.mainText1 }}<span>{{ v.mainText2 }}</span>
            </h4>
            <p>{{ v.mainText3 }}</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-social-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  section {
    max-width: 1400px;
    // width: 90%;
    margin: 0 auto;
    padding-bottom: 30px;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
      P {
        width: 90%;
        margin: 0 auto;
        max-width: 1000px;
      }
    }
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      // margin: 0 auto;
      grid-template-columns: repeat(4, 1fr);
      grid-gap: 10px;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        background-color: #f1eaf4;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 50%;
          left: 50%;
          width: inherit;
          text-align: center;
          transform: translate(-50%, -50%);
          color: #a56bab;
          .main-text-style-1 {
            font-size: 24px;
            margin: 0;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 20px;
              padding-bottom: 10px;
            }
          }
          .main-text-style-2 {
            font-size: 20px;
            padding-bottom: 10px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
            }
          }
          .main-text-style-3 {
            font-size: 48px;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 32px;
              padding-bottom: 10px;
            }
          }
          .main-text-style-4 {
            width: 220px;
            margin: 0 auto;
            font-size: 18px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
              width: 160px;
            }
          }
        }
        img {
          max-width: 80px;
          margin: 0 auto;
          padding-bottom: 20px;
          @media screen and (max-width: 768px) {
            padding-bottom: 10px;
          }
        }
        .subtitle {
          position: absolute;
          top: 15%;
          left: 24%;
          transform: translate(-50%, -50%);
          color: #111;
          font-size: 24px;
          @media (max-width: 980px) {
            top: 10%;
            font-size: 16px;
          }
        }
      }
    }
  }
}
.page-banner-text-inside {
  position: relative;
  img {
    width: 100%;
    object-fit: cover;
    max-height: 400px;
  }
  .hannstar-page-banner-text {
    position: absolute;
    width: 700px;
    box-sizing: border-box;
    left: 7.5%;
    bottom: 15%;
    @media (max-width: 968px) {
      background-color: #a0ddff;
      position: relative;
      width: 100%;
      left: 0;
      bottom: 0;
      padding: 20px;
      box-sizing: border-box;
    }
    h2 {
      color: #fff;
      margin-bottom: 25px;
      line-height: 1.5;
      text-shadow: 1px 1px 2px #fff;
      text-align: left;
      &.black-color {
        color: #000;
        text-shadow: 1px 1px 2px #fff;
      }
      @media screen and (max-width: 968px) {
        color: #000;
      }
    }
    p {
      color: #fff;
      line-height: 24px;
      letter-spacing: 0.14px;
      @media screen and (max-width: 968px) {
        color: #000;
      }
    }
    button {
      display: inline-block;
      background-color: #039be5;
      border-radius: 4px;
      color: #fff;
      font-size: 16px;
      line-height: 1;
      padding: 12px 16px;
      word-break: keep-all;
      cursor: pointer;
      margin-top: 20px;
      text-align: center;
    }
  }
}
.single-image-section {
  padding: 30px 0;
  .title {
    width: 1000px;
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.left-image-right-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column;
    }
    .image {
      width: 50%;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
    }
  }
}
.right-image-left-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column-reverse;
    }
    .image {
      width: 50%;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
    }
  }
}

.grid-section {
  .section-title {
    width: 90%;
    text-align: center;
    margin: 0 auto;
    padding-bottom: 30px;
  }
  .grid-wrap-3 {
    display: grid;
    grid-gap: 30px;
    justify-content: space-between;
    grid-template-columns: repeat(3, 1fr);
    padding-bottom: 30px;
    &.gap-50 {
      grid-gap: 50px;
      @media screen and (max-width: 980px) {
        grid-gap: 30px;
      }
    }
    @media screen and (max-width: 980px) {
      grid-template-columns: repeat(1, 1fr);
      grid-gap: 30px;
    }
    .grid-box {
      position: relative;
      aspect-ratio: 1/1;
      background-color: #f1eaf4;
      &.grid-shadow {
        box-shadow: 4px 4px 12px -2px rgba(20%, 20%, 40%, 0.5);
      }
      .absolute-center {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        h4 {
          color: #a56bab;
          font-size: 48px;
          padding-bottom: 20px;
          span {
            font-size: 24px;
          }
        }
        p {
          width: 250px;
          color: #a56bab;
          font-size: 24px;
          padding-bottom: 10px;
        }
      }
      @media screen and (max-width: 968px) {
        margin: 10px 20px;
      }
    }
  }
}

.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
