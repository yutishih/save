<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-social-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-society-main-title") }}</h1>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <p>
          {{ t("sustainability-social-society-main-text01") }}
        </p>
        <p>
          {{ t("sustainability-social-society-main-text02") }}
        </p>
        <p>
          {{ t("sustainability-social-society-main-text03") }}
        </p>
      </div>
      <div class="single-image">
        <img
          src="https://media.hannstar.com/Image/hannstar/sustainability/social/engagement/Rectangle2508_2.jpg"
          alt="支持文化發展"
        />
      </div>
    </section>

    <section class="title-only" data-aos="fade-up">
      <div class="title">
        <h2>{{ t("sustainability-social-society-subtitle01") }}</h2>
        <p>
          {{ t("sustainability-social-society-text01") }}
        </p>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-society-subtitle02") }}</h4>
          <p>
            {{ t("sustainability-social-society-text02") }}
          </p>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/engagement/Rectangle2508.png"
            alt="在地數位培育計畫"
          />
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/engagement/Rectangle2508_1.png"
            alt="支持臺灣農產品與社會關懷"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-society-subtitle03") }}</h4>
          <p>
            {{ t("sustainability-social-society-text03") }}
          </p>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-social-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  section {
    max-width: 1400px;
    margin: 0 auto;
    padding-bottom: 30px;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
    }
  }
}

.single-image-section {
  margin: 0 auto;
  .section-title {
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      margin: 0 auto;
      padding-bottom: 30px;
      @media screen and (max-width: 980px) {
        width: 90%;
      }
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.title-only {
  .title {
    width: 1000px;
    margin: 0 auto;
    text-align: center;
    h2 {
      padding-bottom: 30px;
    }
    p {
      max-width: 500px;
      width: 90%;
      margin: 0 auto;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.left-image-right-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    background-color: #f8f8f8;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column;
    }
    .image {
      width: 50%;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
      ul {
        list-style-type: disc;
        padding-left: 20px;
      }
    }
  }
}
.right-image-left-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    background-color: #f8f8f8;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column-reverse;
    }
    .image {
      width: 50%;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
      ul {
        list-style-type: disc;
        padding-left: 20px;
      }
    }
  }
}

.grid-section {
  max-width: 1400px;
  width: 90%;
  .section-title {
    max-width: 1000px;
    width: 90%;
    margin: 0 auto;
    padding-bottom: 30px;
    h2 {
      text-align: center;
      padding-bottom: 30px;
    }
  }
  .grid-wrap-3 {
    display: grid;
    grid-gap: 30px;
    justify-content: space-between;
    grid-template-columns: repeat(3, 1fr);
    padding-bottom: 30px;
    &.gap-50 {
      grid-gap: 50px;
      @media screen and (max-width: 980px) {
        grid-gap: 30px;
      }
    }
    @media screen and (max-width: 980px) {
      grid-template-columns: repeat(1, 1fr);
      grid-gap: 30px;
    }
    .grid-box {
      &.grid-shadow {
        box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2);
      }
      .image {
        img {
          width: 100%;
        }
      }
      .text {
        h5 {
          color: #039be5;
          padding: 15px 0;
        }
      }
      .list {
        padding: 15px 0;
        h4 {
          color: #039be5;
          text-align: center;
          padding: 15px 0;
        }
        .list-justify-center {
          display: flex;
          justify-content: center;
          align-items: center;
          p {
            padding: 0 20px;
          }
        }
      }
    }
  }
}
</style>
