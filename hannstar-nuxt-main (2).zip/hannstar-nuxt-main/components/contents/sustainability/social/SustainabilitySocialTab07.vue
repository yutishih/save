<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-social-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-labor-main-title") }}</h1>
      </div>
    </section>

    <section class="text-only-section" data-aos="fade-up">
      <div class="section-content">
        <h4 class="pdb-20">
          {{ t("sustainability-social-labor-subtitle01") }}
        </h4>
        <p>
          {{ t("sustainability-social-labor-text01") }}
        </p>
        <h5 class="pdb-20">
          {{ t("sustainability-social-labor-subtitle02") }}
        </h5>
        <ul class="pdb-20">
          <li>
            {{ t("sustainability-social-labor-text02_1") }}
          </li>
          <li>{{ t("sustainability-social-labor-text02_2") }}</li>
          <li>{{ t("sustainability-social-labor-text02_3") }}</li>
          <li>{{ t("sustainability-social-labor-text02_4") }}</li>
          <li>{{ t("sustainability-social-labor-text02_5") }}</li>
          <li>{{ t("sustainability-social-labor-text02_6") }}</li>
          <li>{{ t("sustainability-social-labor-text02_7") }}</li>
        </ul>
        <h5 class="pdb-20">
          {{ t("sustainability-social-labor-subtitle03") }}
        </h5>
        <ul>
          <li>{{ t("sustainability-social-labor-text03_1") }}</li>
          <li>{{ t("sustainability-social-labor-text03_2") }}</li>
          <li>{{ t("sustainability-social-labor-text03_3") }}</li>
          <li>{{ t("sustainability-social-labor-text03_4") }}</li>
          <li>{{ t("sustainability-social-labor-text03_5") }}</li>
          <li>{{ t("sustainability-social-labor-text03_6") }}</li>
          <li>{{ t("sustainability-social-labor-text03_7") }}</li>
          <li>{{ t("sustainability-social-labor-text03_8") }}</li>
        </ul>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-social-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  section {
    max-width: 1400px;
    margin: 0 auto;
    padding-bottom: 30px;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
    }
  }
}

.text-only-section {
  margin: 0 auto;
  @media screen and (max-width: 980px) {
    width: 90%;
  }
  .section-content {
    h4 {
      padding-bottom: 30px;
      text-align: left;
    }
    p {
      margin: 0 auto;
      padding-bottom: 30px;
    }
    ul {
      list-style-type: decimal;
      padding-left: 20px;
      li {
        padding-bottom: 10px;
      }
    }
  }
}

.pdb-20 {
  padding-bottom: 20px;
}
</style>
