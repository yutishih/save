<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-social-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-profession-main-title") }}</h1>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <p>
          {{ t("sustainability-social-profession-main-text") }}
        </p>
      </div>
      <div class="single-image">
        <img :src="t('sustainability-social-profession-image01')" />
      </div>
    </section>

    <section class="single-image-no-text-section" data-aos="fade-up">
      <div class="single-image">
        <img :src="t('sustainability-social-profession-image02')" />
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/social_ISO45001.png"
            alt="職業安全衛生管理系統ISO 45001驗證"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-profession-subtitle01") }}</h4>
          <p>
            {{ t("sustainability-social-profession-text01") }}
          </p>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-profession-subtitle02") }}</h4>
          <p>
            {{ t("sustainability-social-profession-text02") }}
          </p>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/Rectangle2500.png"
            alt="管理審查暨職安衛委員會"
          />
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/Rectangle2503.png"
            alt="安全保命條款"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-profession-subtitle03") }}</h4>
          <p>
            {{ t("sustainability-social-profession-text03") }}
          </p>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-profession-subtitle04") }}</h4>
          <p>
            {{ t("sustainability-social-profession-text04") }}
          </p>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/social/Rectangle2533.png"
            alt="安全教官與安全官制度"
          />
        </div>
      </div>
    </section>

    <section data-aos="fade-up">
      <div class="page-banner-text-inside">
        <img
          src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/image362.png"
          alt="健康促進"
        />
        <div class="hannstar-page-banner-text">
          <h2>{{ t("sustainability-social-profession-subtitle05") }}</h2>
          <p>
            {{ t("sustainability-social-profession-text05") }}
          </p>
        </div>
      </div>
    </section>

    <section class="left-image-right-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/Rectangle2508.png"
            alt="職安與環安相關課程"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-social-profession-subtitle06") }}</h4>
          <ul>
            <li>{{ t("sustainability-social-profession-text06_1") }}</li>
            <li>{{ t("sustainability-social-profession-text06_2") }}</li>
            <li>
              {{ t("sustainability-social-profession-text06_3") }}
            </li>
            <li>{{ t("sustainability-social-profession-text06_4") }}</li>
            <li>{{ t("sustainability-social-profession-text06_5") }}</li>
          </ul>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-social-profession-subtitle07") }}</h4>
          <ul>
            <li>{{ t("sustainability-social-profession-text07_1") }}</li>
            <li>{{ t("sustainability-social-profession-text07_2") }}</li>
            <li>{{ t("sustainability-social-profession-text07_3") }}</li>
            <li>{{ t("sustainability-social-profession-text07_4") }}</li>
            <li>{{ t("sustainability-social-profession-text07_5") }}</li>
            <li>{{ t("sustainability-social-profession-text07_6") }}</li>
            <li>{{ t("sustainability-social-profession-text07_7") }}</li>
            <li>{{ t("sustainability-social-profession-text07_8") }}</li>
          </ul>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/Rectangle2510.png"
            alt="緊急應變規劃"
          />
        </div>
      </div>
    </section>

    <section class="grid-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-social-profession-subtitle08") }}</h2>
        <p>
          {{ t("sustainability-social-profession-text08") }}
        </p>
      </div>
      <div class="grid-wrap-3 gap-50">
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/MaskGroup.png"
              alt="人因性危害防治"
            />
          </div>
          <div class="list">
            <h4>{{ t("sustainability-social-profession-point01-title") }}</h4>
            <div class="list-justify-center">
              <p>
                {{ t("sustainability-social-profession-point01-text") }}
              </p>
            </div>
          </div>
        </div>
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/MaskGroup_1.png"
              alt="自動檢查機制"
            />
          </div>
          <div class="list">
            <h4>{{ t("sustainability-social-profession-point02-title") }}</h4>
            <div class="list-justify-center">
              <p>
                {{ t("sustainability-social-profession-point02-text") }}
              </p>
            </div>
          </div>
        </div>
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/social/safety/MaskGroup_2.png"
              alt="綠色包材精進計畫"
            />
          </div>
          <div class="list">
            <h4>{{ t("sustainability-social-profession-point03-title") }}</h4>
            <div class="list-justify-center">
              <p>
                {{ t("sustainability-social-profession-point03-text") }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-social-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  section {
    max-width: 1400px;
    margin: 0 auto;
    padding-bottom: 30px;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
    }
  }
}
.single-image-section {
  max-width: 1000px;
  width: 90%;
  margin: 0 auto;
  .section-title {
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}
.single-image-no-text-section {
  max-width: 1000px;
  .section-title {
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}
.page-banner-text-inside {
  position: relative;
  img {
    width: 100%;
    object-fit: cover;
    max-height: 400px;
  }
  .hannstar-page-banner-text {
    position: absolute;
    width: 700px;
    box-sizing: border-box;
    left: 7.5%;
    bottom: 15%;
    @media (max-width: 968px) {
      background-color: #a0ddff;
      position: relative;
      width: 100%;
      left: 0;
      bottom: 0;
      padding: 20px;
      box-sizing: border-box;
    }
    h2 {
      color: #fff;
      margin-bottom: 25px;
      line-height: 1.5;
      text-shadow: 1px 1px 2px #000;
      text-align: left;
      &.black-color {
        color: #000;
        text-shadow: 1px 1px 2px #fff;
      }
    }
    p {
      color: #fff;
      line-height: 24px;
      letter-spacing: 0.14px;
      text-shadow: 1px 1px 2px #000;
    }
    button {
      display: inline-block;
      background-color: #039be5;
      border-radius: 4px;
      color: #fff;
      font-size: 16px;
      line-height: 1;
      padding: 12px 16px;
      word-break: keep-all;
      cursor: pointer;
      margin-top: 20px;
      text-align: center;
    }
  }
}
.single-image-section {
  .title {
    width: 1000px;
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.left-image-right-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column;
    }
    .image {
      width: 50%;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
      ul {
        list-style-type: disc;
        padding-left: 20px;
      }
    }
  }
}
.right-image-left-text {
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column-reverse;
    }
    .image {
      width: 50%;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
      ul {
        list-style-type: disc;
        padding-left: 20px;
      }
    }
  }
}

.grid-section {
  max-width: 1400px;
  width: 90%;
  .section-title {
    max-width: 1000px;
    width: 90%;
    margin: 0 auto;
    padding-bottom: 30px;
    h2 {
      text-align: center;
      padding-bottom: 30px;
    }
  }
  .grid-wrap-3 {
    display: grid;
    grid-gap: 30px;
    justify-content: space-between;
    grid-template-columns: repeat(3, 1fr);
    padding-bottom: 30px;
    &.gap-50 {
      grid-gap: 50px;
      @media screen and (max-width: 980px) {
        grid-gap: 30px;
      }
    }
    @media screen and (max-width: 980px) {
      grid-template-columns: repeat(1, 1fr);
      grid-gap: 30px;
    }
    .grid-box {
      &.grid-shadow {
        box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2);
      }
      .image {
        img {
          width: 100%;
        }
      }
      .text {
        h5 {
          color: #039be5;
          padding: 15px 0;
        }
      }
      .list {
        padding: 15px 0;
        h4 {
          color: #039be5;
          text-align: center;
          padding: 15px 0;
        }
        .list-justify-center {
          display: flex;
          justify-content: center;
          align-items: center;
          p {
            padding: 0 20px;
          }
        }
      }
    }
  }
}
</style>
