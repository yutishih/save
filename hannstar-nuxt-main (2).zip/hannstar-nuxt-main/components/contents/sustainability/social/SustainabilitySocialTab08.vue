<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-social-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-social-environmentSecurity-main-title") }}</h1>
      </div>
    </section>

    <section class="image-only-section" data-aos="fade-up">
      <div>
        <img :src="t('sustainability-social-environmentSecurity-image01')" />
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-social-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  section {
    max-width: 1400px;
    margin: 0 auto;
    padding-bottom: 30px;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
    }
  }
}

.image-only-section {
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;
  @media screen and (max-width: 980px) {
    width: 90%;
  }
  img {
    max-width: 800px;
    margin: 0 auto;
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}
</style>
