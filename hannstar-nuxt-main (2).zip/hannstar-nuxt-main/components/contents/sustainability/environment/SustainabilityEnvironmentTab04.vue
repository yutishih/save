<script setup>
const { t } = useI18n();
const sustainabilityKeypoint = ref([
  {
    mainText1: "83",
    mainText2: "%",
    mainText3: t("sustainability-environment-supplyChain-points01"),
    arrow: "",
  },
  {
    mainText1: "100",
    mainText2: "%",
    mainText3: t("sustainability-environment-supplyChain-points02"),
    arrow: "",
  },
  {
    mainText1: "100",
    mainText2: "%",
    mainText3: t("sustainability-environment-supplyChain-points03"),
    arrow: "",
  },
  {
    mainText1: "100",
    mainText2: "%",
    mainText3: t("sustainability-environment-supplyChain-points04"),
    arrow: "",
  },
]);
</script>

<template>
  <div class="sustainability-environment-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-environment-supplyChain-main-title") }}</h1>
        <p>
          {{ t("sustainability-environment-supplyChain-main-text01") }}
        </p>
        <p>
          {{ t("sustainability-environment-supplyChain-main-text02") }}
        </p>
      </div>
    </section>
    <section class="index-eight-squares">
      <div class="index-eight-squares-container">
        <div
          class="squares"
          v-for="(item, index) in sustainabilityKeypoint"
          :key="index"
          data-aos="flip-up"
          :data-aos-delay="`${index * 100}`"
        >
          <div class="main-title">
            <div>
              <p class="main-text-style-3 pb-10">
                {{ item.mainText1
                }}<span class="main-text-style-2">{{ item.mainText2 }}</span>
              </p>
              <p>
                <span class="main-text-style-2">{{ item.mainText3 }}</span>
                {{ item.arrow }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-supplyChain-subtitle01") }}</h2>
        <p>
          {{ t("sustainability-environment-supplyChain-text01") }}
        </p>
      </div>
    </section>

    <section class="left-image-right-text pb-30">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/environment/supplychain/Rectangle2914_1.png"
            alt="重要原物料"
          />
        </div>
        <div class="text">
          <h4>
            {{ t("sustainability-environment-supplyChain-point01-title") }}
          </h4>
          <ul>
            <li>
              {{ t("sustainability-environment-supplyChain-point01-text01") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point01-text02") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point01-text03") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point01-text04") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point01-text05") }}
            </li>
          </ul>
        </div>
      </div>
    </section>

    <section class="right-image-left-text" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>
            {{ t("sustainability-environment-supplyChain-point02-title") }}
          </h4>
          <ul>
            <li>
              {{ t("sustainability-environment-supplyChain-point02-text01") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point02-text02") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point02-text03") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point02-text04") }}
            </li>
          </ul>
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/environment/supplychain/Rectangle2500.png"
            alt="風險類型"
          />
        </div>
      </div>
    </section>

    <section class="left-image-right-text pb-30" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/environment/supplychain/Rectangle2503.png"
            alt="供應鏈管理策略"
          />
        </div>
        <div class="text">
          <h4>
            {{ t("sustainability-environment-supplyChain-point03-title") }}
          </h4>
          <ul>
            <li>
              {{ t("sustainability-environment-supplyChain-point03-text01") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point03-text02") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point03-text03") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-point03-text04") }}
            </li>
          </ul>
        </div>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-supplyChain-subtitle02") }}</h2>
        <p>
          {{ t("sustainability-environment-supplyChain-text02") }}
        </p>
      </div>
      <div class="single-image item-pc">
        <img
          :src="t('sustainability-environment-supplyChain-image01_pc')"
          alt="衝突礦產管理"
        />
      </div>
      <div class="single-image item-mobile">
        <img
          :src="t('sustainability-environment-supplyChain-image01_mobile')"
          alt="衝突礦產管理"
          class="img-50-center"
        />
      </div>
    </section>

    <section class="left-image-right-text pb-30" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/environment/supplychain/Rectangle2508.png"
            alt="Hannstar的衝突礦產政策"
          />
        </div>
        <div class="text">
          <h4>{{ t("sustainability-environment-supplyChain-subtitle03") }}</h4>
          <ul>
            <li>
              {{ t("sustainability-environment-supplyChain-text03_1") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-text03_2") }}
            </li>
          </ul>
        </div>
      </div>
    </section>

    <section class="right-image-left-text pb-30" data-aos="fade-up">
      <div class="flex-wrap margin-left-right-10px">
        <div class="text">
          <h4>{{ t("sustainability-environment-supplyChain-subtitle04") }}</h4>
          <p>{{ t("sustainability-environment-supplyChain-text04_1") }}</p>
          <ul>
            <li>{{ t("sustainability-environment-supplyChain-text04_2") }}</li>
            <li>
              {{ t("sustainability-environment-supplyChain-text04_3") }}
            </li>
            <li>
              {{ t("sustainability-environment-supplyChain-text04_4") }}
            </li>
          </ul>
          <p>{{ t("sustainability-environment-supplyChain-text04_5") }}</p>
          <a
            :href="t('sustainability-environment-supplyChain-link01')"
            target="_blank"
            >{{ t("sustainability-environment-supplyChain-text04_6") }}</a
          >
        </div>
        <div class="image">
          <img
            src="https://media.hannstar.com/Image/hannstar/sustainability/environment/supplychain/Rectangle2508_1.png"
            alt="供應商要求"
          />
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-environment-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  @media screen and (max-width: 768px) {
    width: 90%;
  }
  section {
    max-width: 1400px;
    margin: 0 auto;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
      p {
        max-width: 1000px;
        width: 90%;
        margin: 0 auto;
        padding-bottom: 10px;
      }
    }
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      margin: 0 auto;
      grid-template-columns: auto auto auto auto;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        background-color: #e7f3f1;
        width: 90%;
        height: 90%;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 30%;
          left: 50%;
          width: inherit;
          text-align: center;
          transform: translate(-50%, 0);
          color: #00ab98;
          .main-text-style-1 {
            font-size: 24px;
            margin: 0;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 20px;
            }
          }
          .main-text-style-2 {
            font-size: 20px;
            padding-bottom: 10px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
            }
          }
          .main-text-style-3 {
            font-size: 48px;
            @media screen and (max-width: 768px) {
              font-size: 32px;
            }
          }
          .main-text-style-4 {
            width: 220px;
            margin: 0 auto;
            font-size: 18px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
              width: 160px;
            }
          }
        }
        .subtitle {
          position: absolute;
          top: 15%;
          left: 24%;
          transform: translate(-50%, -50%);
          color: #111;
          font-size: 24px;
          @media (max-width: 980px) {
            top: 10%;
            font-size: 16px;
          }
        }
      }
    }
  }
}

.single-image-section {
  max-width: 1000px;
  width: 90%;
  padding: 30px 0;
  .section-title {
    width: 1000px;
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}
.right-image-left-text {
  max-width: 1000px;
  width: 90%;
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column-reverse;
    }
    .image {
      width: 50%;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
      ul {
        list-style-type: disc;
        padding-left: 20px;
      }
      a {
        text-decoration: underline;
        color: #6495ed;
      }
    }
  }
}

.left-image-right-text {
  max-width: 1000px;
  width: 90%;
  .flex-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    @media (max-width: 980px) {
      flex-direction: column;
    }
    .image {
      width: 50%;
      padding-right: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .text {
      width: 50%;
      text-align: left;
      padding-left: 30px;
      @media (max-width: 980px) {
        width: 100%;
        padding: 0 10px;
      }
      h4 {
        font-weight: 400;
        line-height: 36px;
        letter-spacing: 1px;
        padding-bottom: 30px;
        @media (max-width: 980px) {
          padding: 30px 0;
        }
      }
      p {
        line-height: 28px;
        font-weight: 400;
        letter-spacing: 1px;
      }
      ul {
        list-style-type: disc;
        padding-left: 20px;
      }
    }
  }
}

.pb-10 {
  padding-bottom: 10px;
}

.pb-30 {
  padding-bottom: 30px;
}

.img-50-center {
  width: 50%;
  margin: 0 auto;
}

.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
