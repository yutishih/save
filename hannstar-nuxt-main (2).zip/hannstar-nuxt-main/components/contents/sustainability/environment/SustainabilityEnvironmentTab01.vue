<script setup>
const { t } = useI18n();
const sustainabilityKeypoint = ref([
  {
    mainText1: t("sustainability-environment-production-point01-text01"),
    mainText2: t("sustainability-environment-production-point01-text02"),
    mainText3: "-44.7",
    mainText4: t("sustainability-environment-production-point01-text03"),
    arrow: "\u2193",
    mainText6: t("sustainability-environment-production-point01-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point02-text01"),
    mainText2: t("sustainability-environment-production-point02-text02"),
    mainText3: "26.4",
    mainText4: t("sustainability-environment-production-point02-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point02-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point03-text01"),
    mainText2: t("sustainability-environment-production-point03-text02"),
    mainText3: "119",
    mainText4: t("sustainability-environment-production-point03-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point03-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point04-text01"),
    mainText2: t("sustainability-environment-production-point04-text02"),
    mainText3: "90.5",
    mainText4: t("sustainability-environment-production-point04-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point04-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point05-text01"),
    mainText2: t("sustainability-environment-production-point05-text02"),
    mainText3: "450",
    mainText4: t("sustainability-environment-production-point05-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point05-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point06-text01"),
    mainText2: t("sustainability-environment-production-point06-text02"),
    mainText3: "100",
    mainText4: t("sustainability-environment-production-point06-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point06-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point07-text01"),
    mainText2: t("sustainability-environment-production-point07-text02"),
    mainText3: "4966",
    mainText4: t("sustainability-environment-production-point07-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point07-text04"),
  },
  {
    mainText1: t("sustainability-environment-production-point08-text01"),
    mainText2: t("sustainability-environment-production-point08-text02"),
    mainText3: "35",
    mainText4: t("sustainability-environment-production-point08-text03"),
    arrow: "",
    mainText6: t("sustainability-environment-production-point08-text04"),
  },
]);
</script>

<template>
  <div class="sustainability-environment-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-environment-production-main-title") }}</h1>
      </div>
    </section>
    <section class="index-eight-squares">
      <div class="index-eight-squares-container">
        <div
          class="squares"
          v-for="(item, index) in sustainabilityKeypoint"
          :key="index"
          data-aos="flip-up"
          :data-aos-delay="`${index * 100}`"
        >
          <div class="main-title">
            <div>
              <p
                :class="
                  $i18n.locale === 'en'
                    ? 'main-text-style-5'
                    : 'main-text-style-1'
                "
              >
                {{ item.mainText1 }}
              </p>

              <p class="main-text-style-2">
                {{ item.mainText2 }}
                <span class="main-text-style-3">{{ item.mainText3 }}</span>
                {{ item.mainText4 }}
                {{ item.arrow }}
              </p>
              <p class="main-text-style-4">{{ item.mainText6 }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-production-subtitle01") }}</h2>
        <p>
          {{ t("sustainability-environment-production-text01") }}
        </p>
      </div>
      <div class="single-image item-pc">
        <img :src="t('sustainability-environment-production-image01_pc')" />
      </div>
      <div class="single-image item-mobile">
        <img :src="t('sustainability-environment-production-image01_mobile')" />
      </div>
    </section>

    <section class="grid-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-production-subtitle02") }}</h2>
      </div>
      <div class="grid-wrap-3 gap-50">
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/environment/production/MaskGroup.png"
              alt="100%安裝NF₃及SF₆燃燒減量設備"
            />
          </div>
          <div class="list">
            <h4>
              {{ t("sustainability-environment-production-case01-title") }}
            </h4>
            <div class="list-justify-center">
              <p>
                {{ t("sustainability-environment-production-case01-text") }}
              </p>
            </div>
          </div>
        </div>
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/environment/production/MaskGroup_1.png"
              alt="Array光阻液回收"
            />
          </div>
          <div class="list">
            <h4>
              {{ t("sustainability-environment-production-case02-title") }}
            </h4>
            <div class="list-justify-center">
              <p>
                {{ t("sustainability-environment-production-case02-text") }}
              </p>
            </div>
          </div>
        </div>
        <div class="grid-box grid-shadow">
          <div class="image">
            <img
              src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/environment/MaskGroup.png"
              alt="綠色包材精進計畫"
            />
          </div>
          <div class="list">
            <h4>
              {{ t("sustainability-environment-production-case03-title") }}
            </h4>
            <div class="list-justify-center">
              <p>
                {{ t("sustainability-environment-production-case03-text") }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-environment-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  @media screen and (max-width: 768px) {
    width: 90%;
  }
  section {
    max-width: 1400px;
    margin: 0 auto;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
    }
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      margin: 0 auto;
      grid-template-columns: auto auto auto auto;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        background-color: #e7f3f1;
        width: 90%;
        height: 90%;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 30%;
          left: 50%;
          width: inherit;
          text-align: center;
          transform: translate(-50%, 0);
          color: #00ab98;
          .main-text-style-1 {
            font-size: 24px;
            margin: 0;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 20px;
            }
          }
          .main-text-style-2 {
            font-size: 20px;
            padding-bottom: 10px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
            }
          }
          .main-text-style-3 {
            font-size: 48px;
            @media screen and (max-width: 768px) {
              font-size: 32px;
            }
          }
          .main-text-style-4 {
            width: 220px;
            margin: 0 auto;
            font-size: 18px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
              width: 160px;
            }
          }
          .main-text-style-5 {
            color: #fff;
            background-color: #00ab98;
            border-radius: 20px;
            font-size: 24px;
            margin: 0 0 20px 0;
            padding: 10px 0;
            @media screen and (max-width: 768px) {
              font-size: 20px;
            }
          }
        }
        .subtitle {
          position: absolute;
          top: 15%;
          left: 24%;
          transform: translate(-50%, -50%);
          color: #111;
          font-size: 24px;
          @media (max-width: 980px) {
            top: 10%;
            font-size: 16px;
          }
        }
      }
    }
  }
}

.single-image-section {
  max-width: 1000px;
  width: 90%;
  padding: 30px 0;
  .section-title {
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.grid-section {
  max-width: 1400px;
  width: 90%;
  .section-title {
    text-align: center;
    padding-bottom: 30px;
  }
  .grid-wrap-3 {
    display: grid;
    grid-gap: 30px;
    justify-content: space-between;
    grid-template-columns: repeat(3, 1fr);
    padding-bottom: 30px;
    &.gap-50 {
      grid-gap: 50px;
      @media screen and (max-width: 980px) {
        grid-gap: 30px;
      }
    }
    @media screen and (max-width: 980px) {
      grid-template-columns: repeat(1, 1fr);
      grid-gap: 30px;
    }
    .grid-box {
      &.grid-shadow {
        box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2);
      }
      .image {
        img {
          width: 100%;
        }
      }
      .text {
        h5 {
          color: #039be5;
          padding: 15px 0;
        }
      }
      .list {
        padding: 15px 0;
        h4 {
          color: #039be5;
          text-align: center;
          padding: 15px 0;
        }
        .list-justify-center {
          display: flex;
          justify-content: center;
          align-items: center;
          p {
            padding: 0 20px;
          }
        }
      }
    }
  }
}

.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
