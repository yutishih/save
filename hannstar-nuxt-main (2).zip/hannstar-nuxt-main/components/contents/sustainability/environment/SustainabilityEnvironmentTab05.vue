<script setup>
const { t } = useI18n();
</script>
<template>
  <div class="sustainability-environment-tab-content">
    <section class="title">
      <h1>{{ t("sustainability-environment-policy-main-title") }}</h1>
    </section>
    <section data-aos="fade-up">
      <div class="paragraph">
        <p class="content">
          {{ t("sustainability-environment-policy-text01") }}
        </p>
        <p class="content">
          {{ t("sustainability-environment-policy-text02") }}
        </p>
        <ul class="list">
          <li>
            {{ t("sustainability-environment-policy-text03") }}
          </li>
          <li>
            {{ t("sustainability-environment-policy-text04") }}
          </li>
          <li>
            {{ t("sustainability-environment-policy-text05") }}
          </li>
          <li>
            {{ t("sustainability-environment-policy-text06") }}
          </li>
          <li>
            {{ t("sustainability-environment-policy-text07") }}
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-environment-tab-content {
  max-width: 800px;
  width: 100%;
  margin: 0 auto;
  @media screen and (max-width: 768px) {
    width: 90%;
  }
  section {
    max-width: 1400px;

    margin: 0 auto;
    &.title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
    }
  }
  .paragraph {
    text-align: left;
    .content {
      padding-bottom: 20px;
      text-indent: 2em;
    }
    .list {
      list-style-type: decimal;
      padding-left: 20px;
      padding-bottom: 30px;
      li {
        padding-bottom: 10px;
      }
    }
  }
}
</style>
