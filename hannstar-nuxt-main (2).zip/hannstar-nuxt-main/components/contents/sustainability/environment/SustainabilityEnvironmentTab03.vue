<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="sustainability-environment-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-environment-weather-main-title") }}</h1>
        <p>
          {{ t("sustainability-environment-weather-main-text") }}
        </p>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="single-image item-pc">
        <img :src="t('sustainability-environment-weather-image01_pc')" />
      </div>
      <div class="single-image item-mobile">
        <img :src="t('sustainability-environment-weather-image01_mobile')" />
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-weather-subtitle01") }}</h2>
      </div>
      <div class="single-image item-pc">
        <img :src="t('sustainability-environment-weather-image02_pc')" />
      </div>
      <div class="single-image item-mobile">
        <img :src="t('sustainability-environment-weather-image02_mobile')" />
      </div>
      <div class="single-image item-pc">
        <img :src="t('sustainability-environment-weather-image03_pc')" />
      </div>
      <div class="single-image item-mobile">
        <img :src="t('sustainability-environment-weather-image03_mobile')" />
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-environment-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  @media screen and (max-width: 768px) {
    width: 90%;
  }
  section {
    max-width: 1400px;
    margin: 0 auto;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
      p {
        width: 1000px;
        margin: 0 auto;
        padding-bottom: 10px;
        @media screen and (max-width: 980px) {
          width: 100%;
        }
      }
    }
  }
}

.single-image-section {
  max-width: 1000px;
  width: 90%;
  padding: 30px 0;
  .section-title {
    width: 1000px;
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
