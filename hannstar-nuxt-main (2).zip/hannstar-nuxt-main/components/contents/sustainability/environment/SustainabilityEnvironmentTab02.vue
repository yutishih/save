<script setup>
const { t } = useI18n();
const sustainabilityKeypoint = ref([
  {
    mainText1: t("sustainability-environment-greenProduct-point01-text01"),
    mainText2: t("sustainability-environment-greenProduct-point01-text02"),
    mainText3: t("sustainability-environment-greenProduct-point01-text03"),
    arrow: "",
  },
  {
    mainText1: t("sustainability-environment-greenProduct-point02-text01"),
    mainText2: t("sustainability-environment-greenProduct-point02-text02"),
    mainText3: t("sustainability-environment-greenProduct-point02-text03"),
    arrow: "",
  },
  {
    mainText1: t("sustainability-environment-greenProduct-point03-text01"),
    mainText2: t("sustainability-environment-greenProduct-point03-text02"),
    mainText3: t("sustainability-environment-greenProduct-point03-text03"),
    arrow: "",
  },
  {
    mainText1: t("sustainability-environment-greenProduct-point04-text01"),
    mainText2: t("sustainability-environment-greenProduct-point04-text02"),
    mainText3: t("sustainability-environment-greenProduct-point04-text03"),
    arrow: "",
  },
]);
</script>

<template>
  <div class="sustainability-environment-tab-content">
    <section>
      <div class="title">
        <h1>{{ t("sustainability-environment-greenProduct-main-title") }}</h1>
        <p>
          {{ t("sustainability-environment-greenProduct-main-text") }}
        </p>
      </div>
    </section>
    <section class="index-eight-squares">
      <div class="index-eight-squares-container">
        <div
          class="squares"
          v-for="(item, index) in sustainabilityKeypoint"
          :key="index"
          data-aos="flip-up"
          :data-aos-delay="`${index * 100}`"
        >
          <div class="main-title">
            <div>
              <p class="main-text-style-3 pb-10">
                {{ item.mainText1
                }}<span class="main-text-style-2">{{ item.mainText2 }}</span>
              </p>
              <p>
                <span class="main-text-style-2">{{ item.mainText3 }}</span>
                {{ item.arrow }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-greenProduct-subtitle01") }}</h2>
        <p>
          {{ t("sustainability-environment-greenProduct-text01") }}
        </p>
      </div>
      <div class="single-image item-pc">
        <img :src="t('sustainability-environment-greenProduct-image01_pc')" />
      </div>
      <div class="single-image item-mobile">
        <img
          :src="t('sustainability-environment-greenProduct-image01_mobile')"
        />
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <h2>{{ t("sustainability-environment-greenProduct-subtitle02") }}</h2>
        <p>
          {{ t("sustainability-environment-greenProduct-text02") }}
        </p>
      </div>
      <div class="single-image">
        <img
          src="https://media.hannstar.com/Image/hannstar/sustainability/ESG2023/environment/Group360.png"
        />
      </div>
    </section>

    <section class="single-image-section" data-aos="fade-up">
      <div class="section-title">
        <p>
          {{ t("sustainability-environment-greenProduct-text03") }}
        </p>
      </div>
      <div class="section-title">
        <ul>
          <li>
            {{ t("sustainability-environment-greenProduct-text03-point01") }}
          </li>
          <li>
            {{ t("sustainability-environment-greenProduct-text03-point02") }}
          </li>
          <li>
            {{ t("sustainability-environment-greenProduct-text03-point03") }}
          </li>
          <li>
            {{ t("sustainability-environment-greenProduct-text03-point04") }}
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<style lang="scss" scoped>
.sustainability-environment-tab-content {
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  @media screen and (max-width: 768px) {
    width: 90%;
  }
  section {
    max-width: 1400px;
    margin: 0 auto;
    .title {
      h1 {
        text-align: center;
        margin: 0.67em 0;
      }
      p {
        width: 1000px;
        margin: 0 auto;
        padding-bottom: 10px;
        @media screen and (max-width: 980px) {
          width: 100%;
        }
      }
    }
  }

  .index-eight-squares {
    .index-eight-squares-container {
      display: grid;
      width: 100%;
      margin: 0 auto;
      grid-template-columns: auto auto auto auto;
      @media (max-width: 980px) {
        grid-template-columns: auto auto;
      }
      .squares {
        background-color: #e7f3f1;
        width: 90%;
        height: 90%;
        aspect-ratio: 1/1;
        min-width: 10vw;
        min-height: 10vw;
        margin: 10px;
        position: relative;
        overflow: hidden;
        .main-title {
          position: absolute;
          top: 30%;
          left: 50%;
          width: inherit;
          text-align: center;
          transform: translate(-50%, 0);
          color: #00ab98;
          .main-text-style-1 {
            font-size: 24px;
            margin: 0;
            padding-bottom: 20px;
            @media screen and (max-width: 768px) {
              font-size: 20px;
            }
          }
          .main-text-style-2 {
            font-size: 20px;
            padding-bottom: 10px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
            }
          }
          .main-text-style-3 {
            font-size: 48px;
            @media screen and (max-width: 768px) {
              font-size: 32px;
            }
          }
          .main-text-style-4 {
            width: 220px;
            margin: 0 auto;
            font-size: 18px;
            @media screen and (max-width: 768px) {
              font-size: 16px;
              width: 160px;
            }
          }
        }
        .subtitle {
          position: absolute;
          top: 15%;
          left: 24%;
          transform: translate(-50%, -50%);
          color: #111;
          font-size: 24px;
          @media (max-width: 980px) {
            top: 10%;
            font-size: 16px;
          }
        }
      }
    }
  }
}

.single-image-section {
  max-width: 1400px;
  width: 90%;
  padding: 30px 0;
  .section-title {
    width: 1000px;
    margin: 0 auto;
    h2 {
      padding-bottom: 30px;
      text-align: center;
    }
    p {
      padding-bottom: 30px;
    }
    ul {
      list-style-type: decimal;
      padding-left: 20px;
      li {
        padding-bottom: 10px;
      }
    }
    @media screen and (max-width: 980px) {
      width: 100%;
    }
  }
}

.pb-10 {
  padding-bottom: 10px;
}

.item-pc {
  display: block;
  @media screen and (max-width: 980px) {
    display: none;
  }
}
.item-mobile {
  display: none;
  @media screen and (max-width: 980px) {
    display: block;
  }
}
</style>
