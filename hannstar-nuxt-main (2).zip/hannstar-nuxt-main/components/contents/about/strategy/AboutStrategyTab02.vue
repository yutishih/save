<script setup>
const { t } = useI18n();
</script>
<template>
  <div class="about-strategy-tab-content">
    <h1>{{ t("about-strategy-GreenProductPolicy-title") }}</h1>
    <section>
      <!-- <h4>產品及服務品質管理</h4> -->
      <p class="strong-p">
        {{ t("about-strategy-GreenProductPolicy-text01") }}
      </p>

      <img
        src="https://media.hannstar.com/Image/hannstar/about/strategy/img_strategy_content_banner01.jpg"
        alt=""
      />

      <h2>{{ t("about-strategy-GreenProductPolicy-subtitle02") }}</h2>
      <p>
        {{ t("about-strategy-GreenProductPolicy-text02-subtitle01") }} <br />
        {{ t("about-strategy-GreenProductPolicy-text02-content01") }}
      </p>

      <p>
        {{ t("about-strategy-GreenProductPolicy-text02-subtitle02") }} <br />
        {{ t("about-strategy-GreenProductPolicy-text02-content02") }}
      </p>

      <p>
        {{ t("about-strategy-GreenProductPolicy-text02-subtitle03") }} <br />
        {{ t("about-strategy-GreenProductPolicy-text02-content03") }}
      </p>

      <p>
        {{ t("about-strategy-GreenProductPolicy-text02-subtitle04") }} <br />
        {{ t("about-strategy-GreenProductPolicy-text02-content04") }}
      </p>

      <div class="special-img">
        <img
          :src="t('about-strategy-GreenProductPolicy-image01-pc')"
          alt=""
          class="pc-display"
        />
        <img
          :src="t('about-strategy-GreenProductPolicy-image01-mobile')"
          alt=""
          class="mb-display"
        />
      </div>

      <div class="flex-special">
        <span>
          <h2>{{ t("about-strategy-GreenProductPolicy-subtitle03") }}</h2>
          <p>
            {{ t("about-strategy-GreenProductPolicy-text03") }}
          </p>
        </span>
        <span>
          <img :src="t('about-strategy-GreenProductPolicy-image02')" alt="" />
        </span>
      </div>
    </section>
  </div>
</template>
<style lang="scss" scoped>
.about-strategy-tab-content {
  h1 {
    text-align: center;
    margin: 50px 0;
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
  }

  .strong-p {
    font-size: 18px;
  }

  p {
    max-width: 1000px;
    margin: 0 auto 25px auto;
    line-height: 2;
  }

  img {
    width: 100%;
    margin-bottom: 50px;

    @media (max-width: $mobileDeviceWidth) {
      margin-bottom: 25px;
    }
  }

  .flex-special {
    display: flex;
    align-items: center;

    @media (max-width: $mobileDeviceWidth) {
      flex-direction: column;
    }

    h2 {
      text-align: left;
    }

    p {
      text-align: left;
      margin: 0;
    }

    span {
      width: 50%;

      @media (max-width: $mobileDeviceWidth) {
        width: 90%;
        margin: 0 auto;

        &:nth-child(1) {
          order: 2;
          margin-bottom: 35px;
        }

        &:nth-child(2) {
          order: 1;
        }
      }

      img {
        width: 100%;
      }
    }
  }
}
</style>
