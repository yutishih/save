<script setup>
const { t } = useI18n();
</script>
<template>
  <div class="about-strategy-tab-content">
    <h1>{{ t("about-strategy-GreenEnvironment-title") }}</h1>
    <p>
      {{ t("about-strategy-GreenEnvironment-text01") }}
    </p>
    <p>
      {{ t("about-strategy-GreenEnvironment-text02") }}
    </p>
    <p>
      {{ t("about-strategy-GreenEnvironment-text03") }}
    </p>

    <img
      :src="
        t(
          'https://media.hannstar.com/Image/hannstar/document360/about/strategy/strategy3.jpg'
        )
      "
      alt=""
      class="pc-display"
    />
    <img
      :src="
        t(
          'https://media.hannstar.com/Image/hannstar/document360/about/strategy/strategy3_m.png'
        )
      "
      alt=""
      class="mb-display"
    />
  </div>
</template>
<style lang="scss" scoped>
.about-strategy-tab-content {
  padding-top: 25px;
  box-sizing: border-box;

  h1 {
    margin-bottom: 35px;
  }

  p {
    margin-bottom: 50px;
    font-size: 16px;
  }

  img {
    width: 100%;
    margin-bottom: 25px;
  }
}

img.mb-display {
  max-width: 600px;
  margin: 0 auto;
}
</style>
