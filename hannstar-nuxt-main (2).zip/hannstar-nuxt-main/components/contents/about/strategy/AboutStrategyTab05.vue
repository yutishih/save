<script setup>
const { t } = useI18n();

const data = [
  {
    date: t("about-strategy-GreenProductEvents-date01"),
    list: [t("about-strategy-GreenProductEvents-text01")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date02"),
    list: [t("about-strategy-GreenProductEvents-text02")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date03"),
    list: [t("about-strategy-GreenProductEvents-text03")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date04"),
    list: [t("about-strategy-GreenProductEvents-text04")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date05"),
    list: [t("about-strategy-GreenProductEvents-text05")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date06"),
    list: [t("about-strategy-GreenProductEvents-text06")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date07"),
    list: [t("about-strategy-GreenProductEvents-text07")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date08"),
    list: [t("about-strategy-GreenProductEvents-text08")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date09"),
    list: [t("about-strategy-GreenProductEvents-text09")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date10"),
    list: [t("about-strategy-GreenProductEvents-text10")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date11"),
    list: [t("about-strategy-GreenProductEvents-text11")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date12"),
    list: [t("about-strategy-GreenProductEvents-text12")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date13"),
    list: [t("about-strategy-GreenProductEvents-text13")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date14"),
    list: [t("about-strategy-GreenProductEvents-text14")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date15"),
    list: [t("about-strategy-GreenProductEvents-text15")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date16"),
    list: [t("about-strategy-GreenProductEvents-text16")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date17"),
    list: [t("about-strategy-GreenProductEvents-text17")],
  },
  {
    date: t("about-strategy-GreenProductEvents-date18"),
    list: [t("about-strategy-GreenProductEvents-text18")],
  },
];
</script>
<template>
  <div class="about-strategy-tab-content">
    <h1>{{ t("about-strategy-GreenProductEvents-title") }}</h1>
    <TableSide :table-body-data="data"></TableSide>
  </div>
</template>

<style lang="scss" scoped>
.about-strategy-tab-content {
  padding-top: 25px;
  box-sizing: border-box;

  h1 {
    margin-bottom: 35px;
  }

  p {
    margin-bottom: 50px;
    font-size: 16px;
  }
}
</style>
