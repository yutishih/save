<script setup>
const { t } = useI18n();
</script>
<template>
  <div class="about-strategy-tab-content">
    <h1>{{ t("about-strategy-GreenManagementandCertification-title") }}</h1>
    <section>
      <p>
        {{ t("about-strategy-GreenManagementandCertification-text01") }}
      </p>
      <p>
        {{ t("about-strategy-GreenManagementandCertification-text02") }}
      </p>
      <p>
        {{ t("about-strategy-GreenManagementandCertification-text03") }}
      </p>
      <p>
        {{ t("about-strategy-GreenManagementandCertification-text04") }}
      </p>

      <img
        :src="t('about-strategy-GreenManagementandCertification-image01')"
        alt=""
      />

      <h2>
        {{ t("about-strategy-GreenManagementandCertification-subtitle05") }}
      </h2>
      <p>
        {{ t("about-strategy-GreenManagementandCertification-text05") }}
      </p>

      <img
        :src="t('about-strategy-GreenManagementandCertification-image02-pc')"
        alt=""
        class="pc-display"
      />
      <img
        :src="
          t('about-strategy-GreenManagementandCertification-image02-mobile')
        "
        alt=""
        class="mb-display"
      />
    </section>
  </div>
</template>
<style lang="scss" scoped>
.about-strategy-tab-content {
  h1 {
    text-align: center;
    margin: 50px 0;
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
  }

  p {
    max-width: 1000px;
    margin: 0 auto 25px auto;
    line-height: 2;
  }

  img {
    width: 100%;
    margin: 50px 0;
  }

  .special-img {
    max-width: 1000px;
    width: 90%;
    margin: 0 auto;
  }
}

img.mb-display {
  max-width: 600px;
  margin: 0 auto;
}
</style>
