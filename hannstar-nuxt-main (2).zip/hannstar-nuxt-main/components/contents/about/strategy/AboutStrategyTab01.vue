<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="about-strategy-tab-content">
    <h1>{{ t("about-strategy-QualityManagementStrategy-title") }}</h1>
    <section>
      <h4>{{ t("about-strategy-QualityManagementStrategy-subtitle01") }}</h4>
      <p>
        {{ t("about-strategy-QualityManagementStrategy-text01") }}
      </p>

      <img
        src="https://media.hannstar.com/Image/hannstar/document360/about/strategy/strategy1.jpg"
        alt=""
      />

      <h4>{{ t("about-strategy-QualityManagementStrategy-subtitle02") }}</h4>
      <p>
        {{ t("about-strategy-QualityManagementStrategy-text02") }}
      </p>

      <div class="special-img">
        <img
          :src="t('about-strategy-QualityManagementStrategy-image')"
          alt=""
        />
      </div>
    </section>
  </div>
</template>
<style lang="scss" scoped>
.about-strategy-tab-content {
  h1 {
    text-align: center;
    margin: 50px 0;
  }

  h4 {
    text-align: center;
    margin-bottom: 25px;
  }

  p {
    max-width: 1000px;
    margin: 0 auto 25px auto;
    line-height: 2;
  }

  img {
    width: 100%;
    margin-bottom: 50px;
  }

  .special-img {
    max-width: 1000px;
    width: 90%;
    margin: 0 auto;
  }
}
</style>
