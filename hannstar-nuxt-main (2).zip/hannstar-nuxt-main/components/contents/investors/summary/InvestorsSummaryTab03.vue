<template>
  <div class="summary-tab03">
    <table>
      <tr>
        <th>{{ t("investors-summary-tab03-head01") }}</th>
        <th>{{ t("investors-summary-tab03-head02") }}</th>
        <th>{{ t("investors-summary-tab03-head03") }}</th>
      </tr>
      <tr v-for="(item, index) in tableData" :key="index">
        <td>{{ item.name }}</td>
        <td>{{ item.unit }}</td>
        <td>{{ item.perc }}</td>
      </tr>
    </table>
  </div>
</template>

<script setup lang="ts">
const { t } = useI18n();
const tableData = [
  {
    name: t("investors-summary-tab03-investor01"),
    unit: "310,052",
    perc: "10.54",
  },
  {
    name: t("investors-summary-tab03-investor02"),
    unit: "299,632",
    perc: "10.19",
  },
  {
    name: t("investors-summary-tab03-investor03"),
    unit: "150,000",
    perc: "5.10",
  },
  {
    name: t("investors-summary-tab03-investor04"),
    unit: "68,247",
    perc: "2.32",
  },
  {
    name: t("investors-summary-tab03-investor05"),
    unit: "49,670",
    perc: "1.69",
  },
  {
    name: t("investors-summary-tab03-investor06"),
    unit: "31,488",
    perc: "1.07",
  },
  {
    name: t("investors-summary-tab03-investor07"),
    unit: "29,391",
    perc: "1.00",
  },
  {
    name: t("investors-summary-tab03-investor08"),
    unit: "26,349	",
    perc: "0.90",
  },
  {
    name: t("investors-summary-tab03-investor09"),
    unit: "26,261	",
    perc: "0.89",
  },
  {
    name: t("investors-summary-tab03-investor10"),
    unit: "14,411",
    perc: "0.49",
  },
];
</script>

<style lang="scss" scoped>
.summary-tab03 {
  max-width: 1400px;
  width: 90%;
  margin: 50px auto;

  table {
    width: 100%;

    tr {
      th {
        background-color: rgb(0, 148, 218);
        padding: 20px 25px;
        box-sizing: border-box;
        color: #fff;
        border: 1px solid #b9b9b9;
      }

      &:nth-child(2n + 1) {
        background-color: rgb(247, 247, 247);
      }
    }

    td {
      padding: 20px 25px;
      box-sizing: border-box;
      border: 1px solid #b9b9b9;

      &:nth-child(1) {
        width: 60%;
        text-align: left;
      }
      &:nth-child(2) {
        width: 20%;
        text-align: right;
      }

      &:nth-child(3) {
        width: 20%;
        text-align: right;
      }
    }
  }
}
</style>
