<script setup>
const { t } = useI18n();
</script>
<template>
  <div class="summary-tab02">
    <table>
      <tr>
        <th>{{ t("investors-summary-tab02-head01") }}</th>
        <th>{{ t("investors-summary-tab02-head02") }}</th>
      </tr>
      <tr>
        <td>2024/02/07</td>
        <td>{{ t("investors-summary-tab02-event01") }}</td>
      </tr>
      <tr>
        <td>2024/03/08</td>
        <td>{{ t("investors-summary-tab02-event02") }}</td>
      </tr>
      <tr>
        <td>2024/04/10</td>
        <td>{{ t("investors-summary-tab02-event03") }}</td>
      </tr>
      <tr>
        <td>2024/05/10</td>
        <td>{{ t("investors-summary-tab02-event04") }}</td>
      </tr>
      <tr>
        <td>2024/06/07</td>
        <td>{{ t("investors-summary-tab02-event05") }}</td>
      </tr>
      <tr>
        <td>2024/07/09</td>
        <td>{{ t("investors-summary-tab02-event06") }}</td>
      </tr>
      <tr>
        <td>2024/08/09</td>
        <td>{{ t("investors-summary-tab02-event07") }}</td>
      </tr>
      <tr>
        <td>2024/09/09</td>
        <td>{{ t("investors-summary-tab02-event08") }}</td>
      </tr>
      <tr>
        <td>2024/10/09</td>
        <td>{{ t("investors-summary-tab02-event09") }}</td>
      </tr>
      <tr>
        <td>2024/11/08</td>
        <td>{{ t("investors-summary-tab02-event10") }}</td>
      </tr>
      <tr>
        <td>2024/12/09</td>
        <td>{{ t("investors-summary-tab02-event11") }}</td>
      </tr>
      <tr>
        <td>2025/01/10</td>
        <td>{{ t("investors-summary-tab02-event12") }}</td>
      </tr>
    </table>
  </div>
</template>

<style lang="scss" scoped>
.summary-tab02 {
  max-width: 1400px;
  width: 90%;
  margin: 50px auto;

  table {
    width: 100%;

    tr {
      th {
        background-color: rgb(0, 148, 218);
        padding: 20px 25px;
        box-sizing: border-box;
        color: #fff;
        border: 1px solid #b9b9b9;
      }

      &:nth-child(2n + 1) {
        background-color: rgb(247, 247, 247);
      }
    }

    td {
      padding: 20px 25px;
      box-sizing: border-box;
      text-align: center;
      border: 1px solid #b9b9b9;

      &:nth-child(1) {
        width: 30%;
      }

      &:nth-child(2) {
        width: 70%;
      }
    }
  }
}
</style>
