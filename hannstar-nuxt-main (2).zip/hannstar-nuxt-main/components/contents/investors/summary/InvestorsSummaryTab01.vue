<script setup>
const { t } = useI18n();
</script>
<template>
  <div class="summary-tab01">
    <table>
      <tr>
        <td>{{ t("investors-summary-tab01-head01") }}</td>
        <td>{{ t("investors-summary-tab01-text01") }}</td>
      </tr>
      <tr>
        <td>{{ t("investors-summary-tab01-head02") }}</td>
        <td>{{ t("investors-summary-tab01-text02") }}</td>
      </tr>
      <tr>
        <td>{{ t("investors-summary-tab01-head03") }}</td>
        <td>{{ t("investors-summary-tab01-text03") }}</td>
      </tr>
      <tr>
        <td>{{ t("investors-summary-tab01-head04") }}</td>
        <td>{{ t("investors-summary-tab01-text04") }}</td>
      </tr>
      <tr>
        <td>{{ t("investors-summary-tab01-head05") }}</td>
        <td>{{ t("investors-summary-tab01-text05") }}</td>
      </tr>
      <tr>
        <td>{{ t("investors-summary-tab01-head06") }}</td>
        <td>
          {{ t("investors-summary-tab01-text06") }}
        </td>
      </tr>
      <tr>
        <td>{{ t("investors-summary-tab01-head07") }}</td>
        <td>{{ t("investors-summary-tab01-text07") }}</td>
      </tr>
    </table>
  </div>
</template>

<style lang="scss" scoped>
.summary-tab01 {
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;

  table {
    margin: 50px 0;
    width: 100%;
    tr {
      td {
        padding: 15px 25px;
        box-sizing: border-box;
        border: 1px solid #b9b9b9;

        &:nth-child(1) {
          color: #fff;
          background-color: rgb(0, 148, 218);
          text-align: center;
          width: 20%;
          font-weight: 600;
        }
      }
    }
  }
}
</style>
