<script setup>
const { t } = useI18n();
</script>

<template>
  <div class="home-relate-company-container">
    <div class="home-rc-title">
      <h2>{{ t("home-company-related") }}</h2>
    </div>
    <div class="home-relate-box">
      <div class="home-relate-box-item">
        <a href="https://www.hannstar.com/tw/about/family#HannTouch">
          <img
            src="https://media.hannstar.com/Image/hannstar/oldpics/logo1.png"
            alt=""
          />
        </a>
      </div>
      <div class="home-relate-box-item">
        <a href="https://www.hannstar.com/tw/about/family#HannStarFoundation">
          <img
            src="https://media.hannstar.com/Image/hannstar/oldpics/logo2.png"
            alt=""
          />
        </a>
      </div>
      <div class="home-relate-box-item">
        <a href="https://www.hannstar.com/tw/about/family#HannsHouse">
          <img
            src="https://media.hannstar.com/Image/hannstar/oldpics/logo3.png"
            alt=""
          />
        </a>
      </div>
      <div class="home-relate-box-item">
        <a href="https://www.hannstar.com/tw/about/family#HannSpree">
          <img
            src="https://media.hannstar.com/Image/hannstar/oldpics/logo4.png"
            alt=""
          />
        </a>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.home-relate-company-container {
  display: inline-block;
  width: 45%;

  @media (max-width: $mobileDeviceWidth) {
    width: 100%;
    order: 1;
    margin-bottom: 25px;
  }

  .home-rc-title {
    padding: 0 30px 16px 0;
    border-bottom: 1px solid #b9b9b9;

    h2 {
      margin: 0;
      text-align: center;
      display: block;
    }
  }

  .home-relate-box {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 2px;

    .home-relate-box-item {
      padding: 10px 0;

      img {
        height: 55px;
        display: block;
        margin: 0 auto;
        object-fit: contain;
      }
    }
  }
}
</style>
