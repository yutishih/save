<!-- 這個header沒有被採用 真的header請見layout/default.vue -->
<script setup>
const { data } = useSitemap();
const switchLocalePath = useSwitchLocalePath();
const localePath = useLocalePath();
</script>

<template>
  <header class="hannstar-header">
    <div class="hannstar-header-container">
      <div class="header-main-menu">
        <NuxtLink :to="localePath('index')">
          <img
            src="https://media.hannstar.com/Image/hannstar/header/logo.png"
            alt=""
          />
        </NuxtLink>
      </div>
      <div class="header-nav">
        <div class="header-nav-menu">
          <ul>
            <li v-for="(item, index) in data" :key="index">
              <NuxtLink
                :to="
                  localePath({
                    name: item.mainMenuLink,
                  })
                "
              >
                <span>{{ item.mainMenu }}</span>
              </NuxtLink>

              <div class="header-nav-box">
                <ul>
                  <li v-for="(subItem, index) in item.subMenu" :key="index">
                    <NuxtLink
                      v-if="subItem.targetBlank === false"
                      :to="localePath(subItem.link)"
                    >
                      {{ subItem.text }}
                    </NuxtLink>
                    <a v-else :href="subItem.link" target="_blank">
                      {{ subItem.text }}
                    </a>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <NuxtLink :to="switchLocalePath('tw')">中</NuxtLink>/
              <NuxtLink :to="switchLocalePath('en')">EN</NuxtLink>/
              <NuxtLink :to="switchLocalePath('cn')">簡</NuxtLink>/
            </li>
          </ul>
        </div>
      </div>
    </div>
  </header>
  <!-- 處理Header Fixed -->
  <div class="header-fixed"></div>
</template>

<style lang="scss">
header.hannstar-header {
  position: sticky;
  top: 0;
  padding: 0 80px;
  flex: 1 1 auto;
  box-sizing: border-box;
  background: linear-gradient(280deg, #039be5 0%, #0959a2 60%, #082e74 100%);
  width: 100%;
  height: 100px;
  z-index: 99;

  .hannstar-header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    width: 100%;
    max-width: 1600px;
    margin: 0 auto;

    .header-nav-menu {
      a {
        color: #000;
        border: none;
        outline: none;
        text-decoration: none;
      }
    }
  }

  .header-nav {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-end;
  }

  .header-nav-lang {
    display: block;
    position: relative;
    height: 50%;
  }

  .header-nav-menu {
    display: block;
    position: relative;
    height: 50%;
  }

  .header-nav-box {
    // overflow: hidden;
    position: relative;
  }

  .header-nav-menu ul {
    list-style: none;

    :hover ul {
      max-height: 1000px;
    }
  }

  .header-nav-menu ul ul {
    position: absolute;
    transform: translate(-50%, 100%);
    bottom: 0;
    padding: 0;
    left: 50%;
    background: #ddd;
    overflow: hidden;
    max-height: 0;
    transition: 1s;
    width: 185px;

    li {
      padding: 15px 20px;
      box-sizing: border-box;

      a {
        color: #000;
        border: none;
        outline: none;
        text-decoration: none;
      }
    }
  }

  .header-nav-menu > ul {
    display: flex;
    position: relative;
    margin: 0;
    height: 100%;

    li {
      position: relative;
      padding: 0 25px;
      text-align: center;
      height: 100%;

      span {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        color: #fff;
        cursor: pointer;
        position: relative;

        &:after {
          content: "";
          transform: translateY(-50%) rotate(135deg);
          position: absolute;
          right: -15px;
          top: 50%;
          width: 3px;
          height: 3px;
          border-top: 2px solid #fff;
          border-right: 2px solid #fff;
        }
      }
    }
  }
}

@media screen and (max-width: 768px) {
  header.hannstar-header {
    height: 60px;
    padding: 0;
  }
}
</style>
