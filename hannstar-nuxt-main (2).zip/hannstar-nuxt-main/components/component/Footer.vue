<script setup lang="ts">
const { data } = useSitemap();
const localePath = useLocalePath();
</script>

<template>
  <footer class="hannstar-footer">
    <div class="footer-top">
      <ul class="footer-first-ul">
        <li v-for="(item, index) in data" :key="index">
          <span>{{ item.mainMenu }}</span>
          <div class="header-nav-box">
            <ul>
              <li v-for="(subItem, index) in item.subMenu" :key="index">
                <NuxtLink
                  :to="
                    localePath({
                      name: subItem.link,
                    })
                  "
                >
                  {{ subItem.text }}
                </NuxtLink>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
    <div class="footer-bot">
      <div class="footer-bot-wrapper">
        <div>
          <img
            src="https://media.hannstar.com/Image/hannstar/header/logo.png"
            alt=""
          />
        </div>
        <div class="link-wrapper">
          <NuxtLink :to="localePath('information-privacy')">聯絡我們</NuxtLink>
          <NuxtLink :to="localePath('information-privacy')">隱私聲明</NuxtLink>
          <NuxtLink :to="localePath('information-legalnotices')"
            >法律聲明</NuxtLink
          >
          <NuxtLink :to="localePath('sitemap')">網頁地圖</NuxtLink>
          <a
            target="_blank"
            href="https://tw.linkedin.com/company/hannstar-display"
            rel="noreferrer"
          >
            <img
              src="https://media.hannstar.com/Image/hannstar/social_media_icons/icons8-linkedin-50.png"
              alt=""
            />
          </a>
          <a
            target="_blank"
            href="https://www.facebook.com/HannstarRecruiting/"
            rel="noreferrer"
          >
            <img
              src="https://media.hannstar.com/Image/hannstar/social_media_icons/icons8-facebook-50.png"
              alt=""
            />
          </a>
        </div>

        <div class="right">© 2024 HannStar. All Rights Reserved.</div>
      </div>
    </div>
  </footer>
</template>

<style scoped lang="scss">
footer.hannstar-footer {
  background-color: #0959a2;
  color: #fff;
  display: block;

  ul.footer-first-ul {
    margin: 0;
    display: flex;
    align-items: flex-start;
    justify-content: space-evenly;
    width: 100%;
    max-width: 1600px;
    margin: 0 auto;

    span {
      margin: 0 0 35px 0;
      display: block;
      font-weight: 600;
    }
  }

  ul {
    list-style: none;
    padding: 0;

    li {
      color: #fff;
      text-align: left;
      margin: 10px 0;

      a {
        text-decoration: none;
        color: #fff;
        text-align: left;
      }
    }
  }
}

.footer-top {
  padding: 50px 0;
}

.footer-bot {
  background: linear-gradient(280deg, #039be5 0%, #0959a2 60%, #082e74 100%);

  .footer-bot-wrapper {
    width: 90%;
    max-width: 1600px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;

    height: 80px;
    padding: 0 80px;
  }

  .link-wrapper {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 65%;

    a {
      border-right: 1px solid #fff;
      padding: 2px 10px;
      text-decoration: none;
      color: #fff;
      font-size: 0.8em;

      img {
        width: 25px;
      }
    }
  }

  .right {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    font-size: 12px;
  }
}

@media screen and (max-width: 980px) {
  footer.hannstar-footer {
    ul.footer-first-ul {
      .footer-first-ul {
        flex-direction: column;
      }
    }
  }
}
</style>
