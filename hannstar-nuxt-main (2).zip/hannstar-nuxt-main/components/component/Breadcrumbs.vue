<script setup>
import { defineProps } from "vue";

// 使用方法
{
  /* <BreadcrumbComponent 
    :level-second="{ text: string , link: string }" 
    :level-third="{ text: string , link: string }"
></BreadcrumbComponent> */
}

const { t } = useI18n();
const localePath = useLocalePath();
const props = defineProps({
  levelSecond: Object,
  levelThird: Object,
  levelForth: String,
});
</script>

<template>
  <div class="hannstar-breadcrumb-container">
    <span>{{ t("breadcrumb-home") }}</span>
    <span>/</span>
    <span>
      <NuxtLink :to="localePath(levelSecond.link)">{{
        levelSecond.text
      }}</NuxtLink>
    </span>
    <span v-if="levelThird">/</span>
    <span v-if="levelThird">
      <NuxtLink :to="localePath(levelThird.link)">{{
        levelThird.text
      }}</NuxtLink>
    </span>
    <span v-if="props.levelForth && props.levelForth !== levelThird.text"
      >/</span
    >
    <span v-if="props.levelForth && props.levelForth !== levelThird.text">
      {{ props.levelForth }}
    </span>
  </div>
</template>

<style lang="scss" scoped>
.hannstar-breadcrumb-container {
  width: 90%;
  max-width: 1400px;
  margin: 25px auto 50px auto;

  span:nth-child(2n) {
    margin: 0 10px;
  }

  span:last-child {
    color: #039be5;
    text-align: center;
  }
}
</style>
