<script setup>
import { ref } from "vue";
import "vue3-carousel/dist/carousel.css";
import { useNewsList } from "../../../composables/news/useNewsList";
import { Carousel, Slide } from "vue3-carousel";

const { t, locale } = useI18n();
const localePath = useLocalePath();

//抓當前語言來call api
const language = computed(() => {
  switch (locale.value) {
    case "en":
      return "en";
    case "tw":
      return "zh-hant";
    case "cn":
      return "zh";
    default:
      return "tw";
  }
});

//api打入的資料
const { news, isLoading, error, fetchNews } = useNewsList();

const allMessagesData = ref([]);

onMounted(async () => {
  await fetchNews(); // 不帶props就是抓全部訊息
  allMessagesData.value = news.value.data.filter(
    (n) => n.language === language.value
  );
});

const groupedItems = computed(() => {
  const sortedMessages = allMessagesData.value.sort((a, b) => {
    const dateA = new Date(a.create_time);
    const dateB = new Date(b.create_time);
    return dateB - dateA;
  });

  const groupSize = 3;
  const groups = [];
  for (let i = 0; i < sortedMessages.length; i += groupSize) {
    groups.push(sortedMessages.slice(i, i + groupSize));
  }
  return groups;
});

//日期格式調整
const formatDate = (dateString) => {
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear();
  return `${year}.${month}.${day}`;
};
</script>

<template>
  <div class="home-news-center-container">
    <div class="home-news-title">
      <h2>{{ t("home-message-center") }}</h2>
      <div class="home-news-more">
        <NuxtLink :to="localePath('news-esg')"> MORE </NuxtLink>
      </div>
    </div>

    <div v-if="isLoading" class="loading"><img src="/loading.gif" /></div>
    <div v-else-if="error">{{ error.message }}</div>
    <Carousel v-else :wrap-around="true" :dir="'ltr'">
      <Slide
        v-for="(items, index) in groupedItems"
        :key="index"
        class="home-items-row"
      >
        <div class="home-news-items" v-for="item in items">
          <div class="home-news-box">
            <!-- 快速做永續訊息跟活動訊息的tag翻譯，之後可寫成功能 -->
            <div v-if="locale === 'en'" class="type">
              {{ item.tag }}
            </div>
            <div v-if="locale === 'tw' && item.tag === 'ESG'" class="type">
              永續訊息
            </div>
            <div v-if="locale === 'cn' && item.tag === 'ESG'" class="type">
              可持续讯息
            </div>
            <div v-if="locale === 'tw' && item.tag === 'Campaign'" class="type">
              活動訊息
            </div>
            <div v-if="locale === 'cn' && item.tag === 'Campaign'" class="type">
              活动讯息
            </div>
            <div class="date">
              {{ formatDate(item.create_time) }}
            </div>
            <div class="title">
              <a
                :href="`/${locale}/news/esg/article?articleId=${item.article_id}`"
                >{{ item.title }}</a
              >
            </div>
          </div>
        </div>
      </Slide>
    </Carousel>
  </div>
</template>

<style lang="scss" scoped>
.home-news-center-container {
  display: inline-block;
  width: 65%;
  margin-right: 5%;
  overflow: hidden;

  @media (max-width: $mobileDeviceWidth) {
    width: 100%;
    order: 2;
  }

  .home-items-row {
    width: 100% !important;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }

  .home-news-items {
    width: 100%;
  }

  .home-news-box {
    display: flex;
    align-items: center;
    border-top: 1px solid #b9b9b9;

    .type {
      padding: 5px 15px;
      color: #363636;
      font-size: 14px;
      font-weight: 400;
      border-radius: 5px;
      background-color: #d9d9d9;
      word-break: keep-all;
    }

    .date {
      color: #8d8d8d;
      margin: 0 20px;
    }

    .title {
      display: block;
      color: #363636;
      font-size: 16px;
      font-weight: 400;
      line-height: 1.8;
      line-height: 3;
      white-space: nowrap;
      overflow: hidden;
      -o-text-overflow: ellipsis;
      text-overflow: ellipsis;
      letter-spacing: 0.5pt;
      &:hover {
        text-decoration: underline;
      }
    }
  }

  .home-news-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px 16px 0;
    // border-bottom: 1px solid #b9b9b9;

    h2 {
      margin: 0;
    }

    .home-news-more {
      position: relative;
      color: #039be5;

      &:after {
        content: "";
        position: absolute;
        transform: translateY(-50%) rotate(45deg) translate(0, -75%);
        top: 70%;
        right: -10px;
        width: 5px;
        height: 5px;
        border-top: 1px solid;
        border-right: 1px solid;
      }
    }
  }
  .loading {
    max-width: 50px;
    width: 100%;
    margin: 0 auto;
    padding: 50px 0;
  }
}
</style>
