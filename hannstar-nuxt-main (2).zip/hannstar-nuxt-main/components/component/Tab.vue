<script setup>
import { defineProps, defineEmits, onMounted, ref } from "vue";
import { useRoute } from "vue-router";

const props = defineProps({
  tabNavigation: Array,
});

const emits = defineEmits(["update:tabChoose"]);
const route = useRoute();

// 初始化 pickIndex
const initializeTabIndex = () => {
  const tabParam = route.query.Tab;
  if (tabParam) {
    return props.tabNavigation.findIndex((tab) => tab.queryTab === tabParam);
  }
  return 0;
};

const pickIndex = ref(initializeTabIndex());

// 刷新後維持在刷新前的tab
const initializeTab = () => {
  if (process.client) {
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get("Tab");
    if (tabParam) {
      const tabIndex = props.tabNavigation.findIndex(
        (tab) => tab.queryTab === tabParam
      );
      if (tabIndex !== -1) {
        pickIndex.value = tabIndex;
      }
    }
  }
};
onMounted(initializeTab);

const pickTab = async (i) => {
  if (pickIndex.value === i) {
    return;
  } else {
    pickIndex.value = i;

    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set("Tab", props.tabNavigation[i].queryTab);
    const newUrl = window.location.pathname + "?" + urlParams.toString();
    window.history.pushState({}, "", newUrl);

    emits("update:tabChoose", i);
  }
};

const chooseTab = async (i) => {
  if (pickIndex.value === i.target.value) {
    return;
  } else {
    pickIndex.value = i.target.value;

    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set("Tab", props.tabNavigation[i.target.value].queryTab);
    const newUrl = window.location.pathname + "?" + urlParams.toString();
    window.history.pushState({}, "", newUrl);

    emits("update:tabChoose", parseInt(i.target.value));
  }
};
</script>

<template>
  <div class="tab-component-container">
    <div class="tab-section pc-display">
      <div
        v-for="(item, index) in props.tabNavigation"
        :key="index"
        class="tab-item"
        :class="{ active: pickIndex === index }"
        @click="pickTab(index)"
      >
        {{ item.text }}
      </div>
    </div>

    <div class="tab-select-section mb-display">
      <select v-model="pickIndex" @change="chooseTab($event)">
        <option
          v-for="(item, index) in props.tabNavigation"
          :key="index"
          :value="index"
        >
          {{ item.text }}
        </option>
      </select>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.tab-component-container {
  display: block;
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;

  .tab-section {
    display: flex;

    .tab-item {
      text-align: center;
      padding: 10px 15px;
      cursor: pointer;
      float: left;
      display: inline-flex;
      background-color: #f6f6f6;

      &.active {
        background: #039be5;
        color: #fff;
      }
    }
  }
}

.tab-select-section {
  select {
    width: 100%;
    padding: 5px 10px;
    border: solid 1px #b9b9b9;
    border-radius: 3px;
  }
}
</style>
