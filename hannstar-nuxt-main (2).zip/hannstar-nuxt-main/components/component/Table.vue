<script setup>
// 使用方法
{/* <TableComponent 
    :table-head-data="[{ text: string, width, string | number, align: 'left | center | right '}]" 
    :table-body-data="[{ title: string, name: string, jobs: [] }]">
</ TableComponent> */}

const toggleIndex = ref(null);
const props = defineProps({
    tableHeadData: Array,
    tableBodyData: Array
});

const openCollapse = (i) => {
    if( toggleIndex.value === i) {

        toggleIndex.value = null;
    } else {
        toggleIndex.value = i;
    }
}
</script>

<template>
    <!-- PC Table Components -->
    <table class="table-pc-component">
        <tr>
            <th v-for="(item, index) in tableHeadData" :key="index">
                {{ item.text }}
            </th>
        </tr>
        <tr v-for="(item, index) in props.tableBodyData" :key="index">
            <td v-for="(i, title, index) in item" :key="index" :style="{
                textAlign: tableHeadData[index].align,
                width: tableHeadData[index].width + '%'
            }">
                <div v-if="Array.isArray(i)" class="table-component-ul">
                    <ul>
                        <li v-for="(v, indexV) in i" :key="indexV">{{ v }}</li>
                    </ul>
                </div>
                <div v-else>{{ i }}</div>
            </td>
        </tr>
    </table>

    <!-- Mobile Table Components -->
    <div class="mb-table-wrapper table-mobile-component">
        <div class="table-collapse">
            <div v-for="(list, index) in tableBodyData" class="table-list" @click="openCollapse(index)">
                <div class="list-flex">
                    <span>{{ list.name }}</span>
                    <span class="plus-icon" :class="{ 'open': toggleIndex === index }"></span>
                </div>
                <div class="list-collapse" :class="{ 'active': toggleIndex === index }">
                    <div>
                        <ul>
                            <li v-for="(job, index) in list.jobs" :key="index">{{ job }}</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
table {
    width: 100%;

    tr {

        th {
            background: #0094da;
            vertical-align: baseline;
            text-size-adjust: none;
            box-sizing: border-box;
            margin: 0px;
            padding: 15px 5px;
            border: 0px;
            outline: 0px;
            font-size: 16px;
            font-weight: 500;
            color: #fff;
            text-align: center;
        }

        td {
            text-size-adjust: none;
            box-sizing: border-box;
            margin: 0px;
            padding: 20px 15px;
            border: 1px solid #e8e8e8;
            outline: 0px;
            font-size: 16px;
            vertical-align: middle;
            background: rgba(0,0,0,0);
        }
    }

    .table-component-ul ul {
        list-style-type: disc;
        padding-left: 25px;

        li {
            margin: 10px 0;
        }
    }
}

.plus-icon {
    position: relative;
    &:before {
        content: "";
        position: absolute;
        top: 50%;
        right: 8px;
        width: 12px;
        height: 2px;
        background-color: #ddd;
        transition: .3s ease-out;
    }

    &:after {
        content: "";
        position: absolute;
        top: 50%;
        right: 8px;
        width: 12px;
        height: 2px;
        background-color: #b9b9b9;
        transform: rotate(90deg);
        transition: all .3s ease-out;
    }

    &.open {
        &:after {
            transform: rotate(0);
        }
    }
}

.mb-table-wrapper {
    padding: 15px 20px 20px 20px;
    border: 1px solid #b9b9b9;
    box-sizing: border-box;
    display: flex;

    .table-collapse {
        display: block;
        width: 100%;
    }

    .table-list {
        width: 100%;
        display: block;
        padding: 15px 0;
        border-bottom: 1px solid #b9b9b9;
        cursor: pointer;

        .list-flex {
            display: flex;
            justify-content: space-between;
        }
    }

    .list-collapse {
        height: 0;
        transition: 0.5s;
        overflow: hidden;

        ul {
            list-style: disc;
            padding-left: 25px;

            li {
                margin: 5px 0;
            }
        }

        div {
            opacity: 0;
            transition: 0.5s;
        }
        &.active {
            height: auto;

            div {
                opacity: 1;
            }
        }
    }
}

@media screen and (max-width: $mobileDeviceWidth){
    .table-pc-component {
        display: none;
    }
}

@media screen and (min-width: $mobileDeviceWidth){
    .table-mobile-component {
        display: none;
    }
}
</style>