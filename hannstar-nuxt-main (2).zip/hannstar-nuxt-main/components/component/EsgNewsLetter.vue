<script setup>
import { onMounted, ref } from "vue";
import { useRecaptcha, useSubscription } from "#imports";

const email = ref("");
const toggleThanksMessage = ref(false);
const emailValidationError = ref(false);
const subscriptionError = ref(false);

// Email格式驗證
const validateEmail = () => {
  const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
  if (!emailRegex.test(email.value)) {
    emailValidationError.value = true;
  } else {
    emailValidationError.value = false;
  }
};

// Google Recaptcha Script
const siteKey = "6LdMYQ4nAAAAAOCTV3KCU3KcFtK7gtAn33G_m1bC";
onMounted(() => {
  if (process.client) {
    const googleRecaptchaScript = document.createElement("script");
    googleRecaptchaScript.src = `https://www.google.com/recaptcha/enterprise.js?render=${siteKey}`;
    googleRecaptchaScript.async = true;
    document.body.appendChild(googleRecaptchaScript);
  }
});

// 訂閱電子報
const { getBearerToken } = useRecaptcha();
const { postSubscription } = useSubscription();

const subscribeNewsLetter = async () => {
  //API Body
  const rawEmail = `EMAIL,NAME` + "\n" + email.value + `, Mr/Mrs`;
  const subscriptionBody = {
    requestData: rawEmail,
    token: "",
  };

  // 取Recapcha token
  const recaptchaToken = await getBearerToken({
    username: "magento",
    password: "Aa.123456789",
  });
  try {
    const siteKeyToken = await window.grecaptcha.enterprise.execute(siteKey, {
      action: "submit",
    });
    subscriptionBody.token = siteKeyToken;

    // 用Email + token進行訂閱
    // await postSubscription(subscriptionBody, recaptchaToken);
    await postSubscription(subscriptionBody, "test12345"); // 先隨便打，後端會先放行
    // console.log("訂閱成功1: ", recaptchaToken);
    // console.log("訂閱成功2: ", subscriptionBody);
    // console.log(siteKeyToken);
    toggleThanksMessage.value = true;
  } catch (error) {
    console.error("訂閱失敗: ", error);
    subscriptionError.value = true;
  }
};

// 監聽訂閱表單
const handleFormSubmit = async (e) => {
  e.preventDefault();
  validateEmail();
  if (!emailValidationError.value) {
    await subscribeNewsLetter();
  }
};

//訂閱後感謝訊息
const handleThanksMessage = (e) => {
  toggleThanksMessage.value = !toggleThanksMessage.value;
};

//自動抓取上一個月份並對應英文月份名稱
function getLastMonthAndYear() {
  const months = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
  ];
  let currentDate = new Date();
  let lastMonthIndex = currentDate.getMonth() - 1;
  let year = currentDate.getFullYear();
  if (lastMonthIndex === -1) {
    lastMonthIndex = 11;
    year -= 1;
  }
  return { month: months[lastMonthIndex], year };
}
const { month, year } = getLastMonthAndYear();
</script>

<template>
  <div class="flex-center">
    <div class="esg-news-letter">
      <div class="news-letter-wrapper">
        <div class="survey item-box">
          <a href="https://hannstar.surveycake.biz/s/WyGLZ" target="_blank">
            <div class="flex-wrap">
              <div class="image survey-image"></div>
              <div class="text">
                <h4>問卷調查</h4>
                <p>利害關係人關注議題</p>
              </div>
              <div class="arrow"></div>
            </div>
          </a>
        </div>
        <div class="newsletter item-box">
          <a :href="`/esg-newsletter/${month}-${year}`" target="_blank">
            <div class="flex-wrap">
              <div class="image newsletter-image"></div>
              <div class="text">
                <h4>最新電子報</h4>
                <p>最近一期永續發展成果</p>
              </div>
              <div class="arrow"></div>
            </div>
          </a>
        </div>
        <div class="subscribe item-box">
          <div>
            <div class="text">
              <h4>訂閱電子報</h4>
              <form @submit.prevent="handleFormSubmit">
                <input type="text" v-model="email" placeholder="Email" />
                <button type="submit">送出</button>
              </form>
            </div>
            <div v-if="emailValidationError" class="invalidation-message">
              Please enter a valid email.
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      class="thank-you-message"
      :class="{ show: toggleThanksMessage === true }"
    >
      <div class="message-container">
        <div class="padding-wrap">
          <div v-if="subscriptionError" class="title error">
            <h4>網路錯誤</h4>
          </div>
          <div v-else="!subscriptionError">
            <div class="title">
              <h4>感謝您的訂閱</h4>
            </div>
            <div class="text">
              <p>
                您所填寫的電子信箱{{
                  email
                }}已成功送出，我們將定期發送最新瀚宇彩晶ESG電子報至您的信箱，感謝您的訂閱！
              </p>
            </div>
          </div>

          <button @click="handleThanksMessage()">關閉</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.esg-news-letter {
  .news-letter-wrapper {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    @media screen and (max-width: 980px) {
      display: inline-block;
    }
    .item-box {
      min-width: 340px;
      padding: 0 10px;
      a {
        .flex-wrap {
          display: flex;
          align-items: center;
          justify-content: center;
          max-width: 350px;
          height: 90px;
          padding: 0 15px;
          border: 2px solid #a0ddff;
          border-radius: 4px;
          .image {
            width: 40px;
            height: 50px;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            margin: 0 10px 0 10px;
            &.survey-image {
              background-image: url("https://media.hannstar.com/Image/hannstar/esgIcon/note-icon.png");
            }
            &.newsletter-image {
              background-image: url("https://media.hannstar.com/Image/hannstar/esgIcon/env-icon.png");
            }
          }
          .arrow {
            width: 40px;
            height: 50px;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            margin: 0 10px 0 10px;
            background-image: url("https://media.hannstar.com/Image/hannstar/esgIcon/arrow-r-icon.png");
          }
          &:hover {
            background-color: #039be5;
            border: 2px solid #039be5;
            .image {
              &.survey-image {
                background-image: url("https://media.hannstar.com/Image/hannstar/esgIcon/note-icon-hover.png");
              }
              &.newsletter-image {
                background-image: url("https://media.hannstar.com/Image/hannstar/esgIcon/env-icon-hover.png");
              }
            }
            .text {
              color: #fff;
            }
            .arrow {
              background-image: url("https://media.hannstar.com/Image/hannstar/esgIcon/arrow-r-icon-hover.png");
            }
          }
        }
      }
      @media screen and (max-width: 980px) {
        margin-bottom: 20px;
      }
    }
    .subscribe {
      display: flex;
      align-items: center;
      flex-grow: 1;
      min-height: 90px;
      border-top: 1px solid #e9e9e9;
      border-bottom: 1px solid #e9e9e9;
      .text {
        display: flex;
        align-items: center;
        justify-content: center;
        h4 {
          padding-right: 10px;
        }
        form {
          display: flex;
          justify-content: center;
          align-items: center;
          padding-right: 10px;
          input {
            width: 150px;
            height: 36px;
            border: 1px solid #adadad;
            padding: 0 10px;
            outline: none;
          }
          button {
            width: 53px;
            height: 36px;
            background-color: #a0ddff;
            font-size: 14px;
            border: 1px solid rgba(0, 0, 0, 0);
            border-radius: 4px;
            margin-left: 16px;
            padding: 0;
            &:hover {
              color: #fff;
              background-color: #039be5;
            }
          }
        }
      }
      .invalidation-message {
        padding-top: 5px;
      }
    }
  }
}

.flex-center {
  @media screen and (max-width: 980px) {
    display: flex;
    justify-content: center;
  }
}

.thank-you-message {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 9999;
  &.show {
    display: inline-block;
  }
  .message-container {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 800px;
    // width: 100%;
    background-color: #fff;
    border-radius: 5px;
    text-align: center;
    @media screen and (max-width: 980px) {
      width: 400px;
      padding: 0 20px;
    }
    .padding-wrap {
      max-width: 600px;
      width: 100%;
      margin: 0 auto;
      padding-top: 20px;
      padding-bottom: 50px;
      .title {
        padding: 30px 0;
        border-bottom: 1px solid #039be5;
        &.error {
          border-bottom: none;
        }
      }
      .text {
        padding: 30px 0;
      }
      button {
        color: #039be5;
        padding: 10px 20px;
        border: 1px solid #039be5;
        border-radius: 5px;
        &:hover {
          color: #fff;
          background-color: #039be5;
        }
      }
    }
  }
}
</style>
