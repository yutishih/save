<script setup>
import { useRouter } from "vue-router";

const localePath = useLocalePath();
const router = useRouter();
const { t } = useI18n();

const props = defineProps({
  tabActive: Number,
});

const tabItems = [
  {
    text: t("news-investors-main-title"),
    link: "news-investors",
  },
  {
    text: t("news-esg-main-title"),
    link: "news-esg",
  },
  {
    text: t("news-campaign-main-title"),
    link: "news-campaign",
  },
];

// 用vue-router切換頁面
const selectedTabIndex = ref(props.tabActive || 0);
const chooseTab = (index) => {
  const path = tabItems[index].link;
  router.push(localePath(path));
};
</script>

<template>
  <div class="tab-component-container">
    <div class="tab-section pc-display">
      <NuxtLink
        v-for="(item, index) in tabItems"
        :key="index"
        class="tab-item"
        :class="{ active: props.tabActive === index }"
        :to="localePath(item.link)"
      >
        {{ item.text }}
      </NuxtLink>
    </div>

    <div class="tab-select-section mb-display">
      <select v-model="selectedTabIndex" @change="chooseTab(selectedTabIndex)">
        <option v-for="(item, index) in tabItems" :key="index" :value="index">
          {{ item.text }}
        </option>
      </select>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.tab-component-container {
  display: block;
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;

  .tab-section {
    display: flex;

    .tab-item {
      text-align: center;
      padding: 10px 15px;
      cursor: pointer;
      float: left;
      display: inline-flex;
      background-color: #f6f6f6;

      &.active {
        background: #039be5;
        color: #fff;
      }
    }
  }
}
.tab-select-section {
  select {
    width: 100%;
    padding: 5px 10px;
    border: solid 1px #b9b9b9;
    border-radius: 3px;
  }
}
</style>
