<script setup>
// 使用方法

const toggleIndex = ref(null);
const props = defineProps({
    tableBodyData: Array
});

const openCollapse = (i) => {
    if( toggleIndex.value === i) {

        toggleIndex.value = null;
    } else {
        toggleIndex.value = i;
    }
}
</script>

<template>
    <!-- PC Table Components -->
    <table class="table-pc-component">
        <tr v-for="(item, index) in props.tableBodyData" :key="index"> 
            <td>
                {{ item.date }}
            </td>
            <td>
                <ul>
                    <li v-for="(list, index) in item.list" :key="index">{{ list }}</li>
                </ul>
            </td>
        </tr>
    </table>

    <!-- Mobile Table Components -->
    <div class="mb-table-wrapper table-mobile-component">
        <div class="table-collapse">
            <div v-for="(item, index) in tableBodyData" class="table-list" @click="openCollapse(index)">
                <div class="list-flex">
                    <span>{{ item.date }}</span>
                    <span class="plus-icon" :class="{ 'open': toggleIndex === index }"></span>
                </div>
                <div class="list-collapse" :class="{ 'active': toggleIndex === index }">
                    <div>
                        <ul>
                            <li v-for="(job, index) in item.list" :key="index">{{ job }}</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
table {
    width: 100%;
    margin: 50px 0;

    tr {
        border: 1px solid #b9b9b9;

        td {
            text-size-adjust: none;
            box-sizing: border-box;
            margin: 0px;
            border: 1px solid #e8e8e8;
            outline: 0px;
            font-size: 16px;
            vertical-align: middle;
            background: rgba(0,0,0,0);


            ul {
                list-style-type: disc;
                padding-left: 35px;
            }

            &:nth-child(1) {
                width: 15%;
                text-align: center;
                text-size-adjust: none;
                box-sizing: border-box;
                margin: 0px;
                padding: 20px 0;
                border: 0px;
                outline: 0px;
                font-size: 14px;
                vertical-align: baseline;
                background: rgb(0, 148, 218);
                font-weight: 500;
                color: rgb(255, 255, 255);
            }
        }

        &:nth-child(2n -1 ) {
            background: rgb(247, 247, 247);
        }
    }

    .table-component-ul ul {
        list-style-type: disc;
        padding-left: 25px;

        li {
            margin: 10px 0;
        }
    }
}

.plus-icon {
    position: relative;
    &:before {
        content: "";
        position: absolute;
        top: 50%;
        right: 8px;
        width: 12px;
        height: 2px;
        background-color: #ddd;
        transition: .3s ease-out;
    }

    &:after {
        content: "";
        position: absolute;
        top: 50%;
        right: 8px;
        width: 12px;
        height: 2px;
        background-color: #b9b9b9;
        transform: rotate(90deg);
        transition: all .3s ease-out;
    }

    &.open {
        &:after {
            transform: rotate(0);
        }
    }
}

.mb-table-wrapper {
    padding: 15px 20px 20px 20px;
    border: 1px solid #b9b9b9;
    box-sizing: border-box;
    display: flex;
    margin: 25px 0;

    .table-collapse {
        display: block;
        width: 100%;
    }

    .table-list {
        width: 100%;
        display: block;
        padding: 15px 0;
        border-bottom: 1px solid #b9b9b9;
        cursor: pointer;

        .list-flex {
            display: flex;
            justify-content: space-between;
        }
    }

    .list-collapse {
        height: 0;
        transition: 0.5s;
        overflow: hidden;

        ul {
            list-style: disc;
            padding-left: 25px;
            margin-top: 15px;

            li {
                margin: 5px 0;
            }
        }

        div {
            opacity: 0;
            transition: 0.5s;
        }
        &.active {
            height: auto;

            div {
                opacity: 1;
            }
        }
    }
}

@media screen and (max-width: 968px){
    .table-pc-component {
        display: none;
    }
}

@media screen and (min-width: 968px){
    .table-mobile-component {
        display: none;
    }
}
</style>