<script setup>
const localePath = useLocalePath();
const router = useRouter();
const { t } = useI18n();

const props = defineProps({
  tabActive: Number,
});

const tabItems = [
  {
    text: t("product-menu01"),
    link: "products-detail-automotive",
  },
  {
    text: t("product-menu02"),
    link: "products-detail-industrial",
  },
  {
    text: t("product-menu03"),
    link: "products-detail-mobile",
  },
  {
    text: t("product-menu04"),
    link: "products-detail-wearable",
  },
  {
    text: t("product-menu05"),
    link: "products-detail-tablet",
  },
  {
    text: t("product-menu06"),
    link: "products-detail-touch",
  },
  {
    text: t("product-menu07"),
    link: "products-detail-monitor",
  },
  {
    text: t("product-menu08"),
    link: "products-detail-green-display",
  },
];

const defaultText = ref(tabItems[props.tabActive].text);
const chooseTab = async (i) => {
  router.push(
    localePath({
      name: tabItems.find((e) => e.text === i.target.value).link,
    })
  );

  // ("/"+useI18n().locale.value+"/" + tabItems[i.target.value].link)
};
</script>

<template>
  <div class="tab-component-container">
    <div class="tab-section pc-display">
      <NuxtLink
        v-for="(item, index) in tabItems"
        :key="index"
        class="tab-item"
        :class="{ active: props.tabActive === index }"
        :to="localePath(item.link)"
      >
        {{ item.text }}
      </NuxtLink>
    </div>

    <div class="tab-select-section mb-display">
      <select v-model="defaultText" @change="chooseTab($event)">
        <option v-for="(item, index) in tabItems" :key="index">
          {{ item.text }}
        </option>
      </select>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.tab-component-container {
  display: block;
  max-width: 1400px;
  width: 90%;
  margin: 0 auto;

  .tab-section {
    display: flex;

    .tab-item {
      text-align: center;
      padding: 10px 15px;
      cursor: pointer;
      float: left;
      display: inline-flex;
      background: #039be5;
      margin-right: 15px;
      color: #fff;
      font-size: 14px;

      &.active {
        background: rgb(8, 48, 118);
      }
    }
  }
}

.tab-select-section {
  select {
    width: 100%;
    padding: 5px 10px;
    border: solid 1px #b9b9b9;
    border-radius: 3px;
  }
}
</style>
