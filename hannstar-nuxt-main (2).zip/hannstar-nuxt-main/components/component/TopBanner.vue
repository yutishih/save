<script setup>
import { defineProps } from "vue";

const props = defineProps({
  imgLink: "",
  bannerTitle: "",
  bannerText: "",
  bannerHeightMax: 0,
});
</script>

<template>
  <div
    class="hannstar-page-banner"
    :style="{ maxHeight: props.bannerHeightMax }"
  >
    <img :src="props.imgLink" alt="" />
    <div class="hannstar-page-banner-text">
      <h2>
        {{ props.bannerTitle }}
      </h2>
      <p>
        {{ props.bannerText }}
      </p>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.hannstar-page-banner {
  position: relative;
  img {
    width: 100%;
    object-fit: cover;

    @media (max-width: $mobileDeviceWidth) {
      min-height: 360px;
    }
  }

  .hannstar-page-banner-text {
    position: absolute;
    width: 700px;
    padding: 40px 0px;
    box-sizing: border-box;
    left: 5%;
    bottom: 10%;

    @media (max-width: $mobileDeviceWidth) {
      padding: 0;
      width: 90%;
    }

    h2 {
      color: #fff;
      margin-bottom: 25px;
      text-shadow: 1px 1px 1px #000;
    }

    p {
      color: #fff;
      line-height: 24px;
      letter-spacing: 0.14px;
      text-shadow: 1px 1px 1px #8f8f8f;
    }
  }
}
</style>
