## Hannstar Web前端開發環境
## Vue3 + Nuxt3
## Node 18.x
## 采用前後端分離邏輯

## AWS Git Project
https://aws-git01.hannstar.com/johnsonliew/hannstar-nuxt

## Setup
```bash
# npm
npm install

## 開發環境 Server `http://localhost:3000`:

## 開發基本指令
```bash
# npm
npm run dev


## Build Production 指令
```bash
# npm
npm run build


## 本地端預覽 Product 指令
```bash
# npm
npm run preview
```
## ---------------------------------------------------

## 圖片部署位置(PDF、Images)
正式機 https://media.hannstar.com

## 新增頁面方式，使用 Nuxt3 'pages' 新增寫法
可參考 https://nuxt.com/docs/migration/pages-and-layouts

## 新增Components方式
可參考 https://nuxt.com/docs/migration/component-options

## 專案結構
pages 頁面
components 頁面元件
composables 共用 Function(例api、靜態data)
layouts 固定組件
locales 多語系

## Wordpress API 資料
-
