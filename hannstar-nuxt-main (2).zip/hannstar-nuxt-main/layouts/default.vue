<script setup>
import { ref, onMounted, onUnmounted } from "vue";
import { useHead } from "#imports";
const { data } = useSitemap();
const switchLocalePath = useSwitchLocalePath();
const localePath = useLocalePath();
const { t, locale } = useI18n();

const toggleMenu = ref(false);
const toggleHeaderIndex = ref(null);
const toggleFooterIndex = ref(null);
const isButtonVisible = ref(false);

const language = computed(() => {
  switch (locale.value) {
    case "en":
      return "EN";
    case "tw":
      return "繁中";
    case "cn":
      return "簡中";
    default:
      return "繁中";
  }
});

// 語言列參數
const toggleLang = ref(false);

// 刷新頁面後語言欄位也會保持一樣
const currentLang = ref(language.value);
const langSelector = ref(null);

const openHeaderCollapse = (i) => {
  if (window.matchMedia("(max-width: 980px)").matches) {
    if (toggleHeaderIndex.value === i) {
      toggleHeaderIndex.value = null;
    } else {
      toggleHeaderIndex.value = i;
    }
  }
};

const openFooterCollapse = (i) => {
  if (toggleFooterIndex.value === i) {
    toggleFooterIndex.value = null;
  } else {
    toggleFooterIndex.value = i;
  }
};

const toggleMobileMenu = () => {
  toggleMenu.value = !toggleMenu.value;
};

// 更新當前語言
const updateLang = (lang) => {
  currentLang.value = lang;
  toggleLang.value = false;
};

// 語言列開關
const toggleDropdown = () => {
  toggleLang.value = !toggleLang.value;
};

// 點擊其他地方時關閉下拉菜單
const handleClickOutside = (event) => {
  if (langSelector.value && !langSelector.value.contains(event.target)) {
    toggleLang.value = false;
  }
};

//按鈕: 回到頁面最上方
const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
};
//按鈕: 判定當前捲動位置
const checkScroll = () => {
  if (window.scrollY > 0) {
    isButtonVisible.value = true;
  } else if (window.scrollY === 0) {
    isButtonVisible.value = false;
  }
};

// 監聽點擊事件: handleClickOutside, checkScroll
onMounted(() => {
  window.addEventListener("click", handleClickOutside);
  window.addEventListener("scroll", checkScroll);
});

onUnmounted(() => {
  window.removeEventListener("click", handleClickOutside);
  window.removeEventListener("scroll", checkScroll);
});

// Google Tag Manager
useHead({
  script: [
    {
      hid: "gtm",
      innerHTML: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
      'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-MFTHXVP');`,
      type: "text/javascript",
      charset: "utf-8",
    },
  ],
  __dangerouslyDisableSanitizers: ["script"],
});
</script>

<template>
  <div>
    <header class="hannstar-header">
      <div class="hannstar-header-container">
        <div class="header-main-menu">
          <NuxtLink :to="localePath('index')">
            <img
              src="https://media.hannstar.com/Image/hannstar/header/logo.png"
              alt=""
            />
          </NuxtLink>
        </div>
        <div class="header-nav">
          <div class="menu-button mb-display" @click="toggleMobileMenu()">
            <div>
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
          <div class="header-nav-menu" :class="{ active: toggleMenu === true }">
            <ul>
              <li @click="openHeaderCollapse(1)" class="ul-li-one">
                <NuxtLink
                  :to="localePath({ name: 'about' })"
                  class="pc-display"
                >
                  <span>{{ $t("title-about") }}</span>
                </NuxtLink>
                <div class="list-flex mb-display">
                  <span>{{ $t("title-about") }}</span>
                  <span
                    class="plus-icon"
                    :class="{ open: toggleHeaderIndex === 1 }"
                  ></span>
                </div>

                <div
                  class="header-nav-box"
                  :class="{ active: toggleHeaderIndex === 1 }"
                >
                  <ul>
                    <li>
                      <NuxtLink
                        :to="localePath('about')"
                        @click="toggleMobileMenu()"
                        >{{ $t("hannstar-about") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('about-team')"
                        @click="toggleMobileMenu()"
                        >{{ $t("hannstar-team") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('about-family')"
                        @click="toggleMobileMenu()"
                        >{{ $t("hannstar-related") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('about-strategy')"
                        @click="toggleMobileMenu()"
                        >{{ $t("hannstar-quality") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('about-certification')"
                        @click="toggleMobileMenu()"
                        >{{ $t("hannstar-cert") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('about-stronghold')"
                        @click="toggleMobileMenu()"
                        >{{ $t("hannstar-global") }}
                      </NuxtLink>
                    </li>
                  </ul>
                </div>
              </li>

              <li @click="openHeaderCollapse(2)" class="ul-li-one">
                <NuxtLink
                  :to="localePath({ name: 'products-detail-automotive' })"
                  class="pc-display"
                >
                  <span>{{ $t("product-title") }}</span>
                </NuxtLink>

                <div class="list-flex mb-display">
                  <span>{{ $t("product-title") }}</span>
                  <span
                    class="plus-icon"
                    :class="{ open: toggleHeaderIndex === 2 }"
                  ></span>
                </div>

                <div
                  class="header-nav-box"
                  :class="{ active: toggleHeaderIndex === 2 }"
                >
                  <ul>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-automotive')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu01") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-industrial')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu02") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-mobile')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu03") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-wearable')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu04") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-tablet')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu05") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-touch')"
                        @click="toggleMobileMenu()"
                      >
                        {{ $t("product-menu06") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-monitor')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu07") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('products-detail-green-display')"
                        @click="toggleMobileMenu()"
                        >{{ $t("product-menu08") }}</NuxtLink
                      >
                    </li>
                  </ul>
                </div>
              </li>

              <li @click="openHeaderCollapse(3)" class="ul-li-one">
                <NuxtLink
                  :to="localePath({ name: 'sustainability' })"
                  class="pc-display"
                >
                  <span>{{ $t("esg-title") }}</span>
                </NuxtLink>

                <div class="list-flex mb-display">
                  <span>{{ $t("esg-title") }}</span>
                  <span
                    class="plus-icon"
                    :class="{ open: toggleHeaderIndex === 3 }"
                  ></span>
                </div>

                <div
                  class="header-nav-box"
                  :class="{ active: toggleHeaderIndex === 3 }"
                >
                  <ul>
                    <li>
                      <NuxtLink
                        :to="localePath('sustainability')"
                        @click="toggleMobileMenu()"
                        >{{ $t("esg-menu01") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('sustainability-corporation')"
                        @click="toggleMobileMenu()"
                        >{{ $t("esg-menu02") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('sustainability-governance')"
                        @click="toggleMobileMenu()"
                        >{{ $t("esg-menu03") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('sustainability-environment')"
                        @click="toggleMobileMenu()"
                        >{{ $t("esg-menu04") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('sustainability-social')"
                        @click="toggleMobileMenu()"
                      >
                        {{ $t("esg-menu05") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('sustainability-report')"
                        @click="toggleMobileMenu()"
                      >
                        {{ $t("esg-menu06") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('news-esg')"
                        @click="toggleMobileMenu()"
                        >{{ $t("esg-menu07") }}</NuxtLink
                      >
                    </li>
                  </ul>
                </div>
              </li>

              <li @click="openHeaderCollapse(4)" class="ul-li-one">
                <NuxtLink
                  :to="localePath({ name: 'investors-summary' })"
                  class="pc-display"
                >
                  <span>{{ $t("investors-title") }}</span>
                </NuxtLink>

                <div class="list-flex mb-display">
                  <span>{{ $t("investors-title") }}</span>
                  <span
                    class="plus-icon"
                    :class="{ open: toggleHeaderIndex === 4 }"
                  ></span>
                </div>

                <div
                  class="header-nav-box"
                  :class="{ active: toggleHeaderIndex === 4 }"
                >
                  <ul>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-summary')"
                        @click="toggleMobileMenu()"
                        >{{ $t("investors-menu01") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-revenue')"
                        @click="toggleMobileMenu()"
                        >{{ $t("investors-menu02") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-report')"
                        @click="toggleMobileMenu()"
                        >{{ $t("investors-menu03") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-conference')"
                        @click="toggleMobileMenu()"
                      >
                        {{ $t("investors-menu04") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-shareholdermeeting')"
                        @click="toggleMobileMenu()"
                        >{{ $t("investors-menu05") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-dividend')"
                        @click="toggleMobileMenu()"
                        >{{ $t("investors-menu06") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <a
                        href="https://tw.stock.yahoo.com/quote/6116"
                        target="_blank"
                        >{{ $t("investors-menu07") }}</a
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('investors-contacts')"
                        @click="toggleMobileMenu()"
                        >{{ $t("investors-menu08") }}
                      </NuxtLink>
                    </li>
                  </ul>
                </div>
              </li>

              <li @click="openHeaderCollapse(5)" class="ul-li-one">
                <NuxtLink
                  :to="localePath({ name: 'careers' })"
                  class="pc-display"
                >
                  <span>{{ $t("careers-title") }}</span>
                </NuxtLink>

                <div class="list-flex mb-display">
                  <span>{{ $t("careers-title") }}</span>
                  <span
                    class="plus-icon"
                    :class="{ open: toggleHeaderIndex === 5 }"
                  ></span>
                </div>

                <div
                  class="header-nav-box"
                  :class="{ active: toggleHeaderIndex === 5 }"
                >
                  <ul>
                    <li>
                      <NuxtLink
                        :to="localePath('careers-work')"
                        @click="toggleMobileMenu()"
                        >{{ $t("career-menu01") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('careers-growup')"
                        @click="toggleMobileMenu()"
                        >{{ $t("career-menu02") }}
                      </NuxtLink>
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('careers-join')"
                        @click="toggleMobileMenu()"
                        >{{ $t("career-menu03") }}</NuxtLink
                      >
                    </li>
                  </ul>
                </div>
              </li>

              <li @click="openHeaderCollapse(6)" class="ul-li-one">
                <NuxtLink
                  :to="localePath({ name: 'news-investors' })"
                  class="pc-display"
                >
                  <span>{{ $t("news-title") }}</span>
                </NuxtLink>
                <div class="list-flex mb-display">
                  <span>{{ $t("news-title") }}</span>
                  <span
                    class="plus-icon"
                    :class="{ open: toggleHeaderIndex === 6 }"
                  ></span>
                </div>

                <div
                  class="header-nav-box"
                  :class="{ active: toggleHeaderIndex === 6 }"
                >
                  <ul>
                    <li>
                      <NuxtLink
                        :to="localePath('news-investors')"
                        @click="toggleMobileMenu()"
                        >{{ $t("news-menu01") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('news-esg')"
                        @click="toggleMobileMenu()"
                        >{{ $t("news-menu02") }}</NuxtLink
                      >
                    </li>
                    <li>
                      <NuxtLink
                        :to="localePath('news-campaign')"
                        @click="toggleMobileMenu()"
                        >{{ $t("news-menu03") }}</NuxtLink
                      >
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
            <div class="site-search">
              <NuxtLink :to="localePath('search')">
                <img
                  src="https://media.hannstar.com/Image/hannstar/scope-white.jpg"
                  alt="search-icon"
                />
              </NuxtLink>
            </div>
            <div class="language-selector" ref="langSelector">
              <button @click="toggleDropdown" :class="{ open: toggleLang }">
                {{ currentLang }}
              </button>
              <div class="language-toggle" :class="{ open: toggleLang }">
                <ul>
                  <NuxtLink :to="switchLocalePath('tw')">
                    <li @click="updateLang('繁中')">繁中</li>
                  </NuxtLink>
                  <NuxtLink :to="switchLocalePath('en')">
                    <li @click="updateLang('EN')">EN</li>
                  </NuxtLink>
                  <NuxtLink :to="switchLocalePath('cn')">
                    <li @click="updateLang('簡中')">簡中</li>
                  </NuxtLink>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Next Page -->
    <slot></slot>

    <!-- FOOTER -->
    <footer class="hannstar-footer">
      <div class="footer-top">
        <ul class="footer-first-ul">
          <li @click="openFooterCollapse(1)">
            <div class="list-flex">
              <span>{{ $t("title-about") }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleFooterIndex === 1 }"
              ></span>
            </div>

            <div
              class="header-nav-box pd-l-20"
              :class="{ active: toggleFooterIndex === 1 }"
            >
              <ul>
                <li>
                  <NuxtLink :to="localePath('about')">{{
                    $t("hannstar-about")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('about-team')">{{
                    $t("hannstar-team")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('about-family')">{{
                    $t("hannstar-related")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('about-strategy')">{{
                    $t("hannstar-quality")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('about-certification')">{{
                    $t("hannstar-cert")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('about-stronghold')">{{
                    $t("hannstar-global")
                  }}</NuxtLink>
                </li>
              </ul>
            </div>
          </li>

          <li @click="openFooterCollapse(2)">
            <div class="list-flex">
              <span>{{ $t("product-title") }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleFooterIndex === 2 }"
              ></span>
            </div>
            <div
              class="header-nav-box pd-l-20"
              :class="{ active: toggleFooterIndex === 2 }"
            >
              <ul>
                <li>
                  <NuxtLink :to="localePath('products-detail-automotive')"
                    >{{ $t("product-menu01") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-industrial')"
                    >{{ $t("product-menu02") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-mobile')"
                    >{{ $t("product-menu03") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-wearable')"
                    >{{ $t("product-menu04") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-tablet')"
                    >{{ $t("product-menu05") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-touch')"
                    >{{ $t("product-menu06") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-monitor')"
                    >{{ $t("product-menu07") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('products-detail-green-display')"
                    >{{ $t("product-menu08") }}
                  </NuxtLink>
                </li>
              </ul>
            </div>
          </li>

          <li @click="openFooterCollapse(3)">
            <div class="list-flex">
              <span>{{ $t("esg-title") }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleFooterIndex === 3 }"
              ></span>
            </div>
            <div
              class="header-nav-box pd-l-20"
              :class="{ active: toggleFooterIndex === 3 }"
            >
              <ul>
                <li>
                  <NuxtLink :to="localePath('sustainability')">{{
                    $t("esg-menu01")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('sustainability-corporation')"
                    >{{ $t("esg-menu02") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('sustainability-governance')"
                    >{{ $t("esg-menu03") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('sustainability-environment')"
                    >{{ $t("esg-menu04") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('sustainability-social')">{{
                    $t("esg-menu05")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('sustainability-report')">{{
                    $t("esg-menu06")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('news-esg')">{{
                    $t("esg-menu07")
                  }}</NuxtLink>
                </li>
              </ul>
            </div>
          </li>

          <li @click="openFooterCollapse(4)">
            <div class="list-flex">
              <span>{{ $t("investors-title") }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleFooterIndex === 4 }"
              ></span>
            </div>
            <div
              class="header-nav-box pd-l-20"
              :class="{ active: toggleFooterIndex === 4 }"
            >
              <ul>
                <li>
                  <NuxtLink :to="localePath('investors-summary')">{{
                    $t("investors-menu01")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('investors-revenue')">{{
                    $t("investors-menu02")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('investors-report')">{{
                    $t("investors-menu03")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('investors-conference')"
                    >{{ $t("investors-menu04") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('investors-shareholdermeeting')"
                    >{{ $t("investors-menu05") }}
                  </NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('investors-dividend')">{{
                    $t("investors-menu06")
                  }}</NuxtLink>
                </li>
                <li>
                  <a
                    href="https://tw.stock.yahoo.com/quote/6116"
                    target="_blank"
                    >{{ $t("investors-menu07") }}</a
                  >
                </li>
                <li>
                  <NuxtLink :to="localePath('investors-contacts')">{{
                    $t("investors-menu08")
                  }}</NuxtLink>
                </li>
              </ul>
            </div>
          </li>

          <li @click="openFooterCollapse(5)">
            <div class="list-flex">
              <span>{{ $t("careers-title") }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleFooterIndex === 5 }"
              ></span>
            </div>
            <div
              class="header-nav-box pd-l-20"
              :class="{ active: toggleFooterIndex === 5 }"
            >
              <ul>
                <li>
                  <NuxtLink :to="localePath('careers-work')">{{
                    $t("career-menu01")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('careers-growup')">{{
                    $t("career-menu02")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('careers-join')">{{
                    $t("career-menu03")
                  }}</NuxtLink>
                </li>
              </ul>
            </div>
          </li>

          <li @click="openFooterCollapse(6)">
            <div class="list-flex">
              <span>{{ $t("news-title") }}</span>
              <span
                class="plus-icon"
                :class="{ open: toggleFooterIndex === 6 }"
              ></span>
            </div>
            <div
              class="header-nav-box pd-l-20"
              :class="{ active: toggleFooterIndex === 6 }"
            >
              <ul>
                <li>
                  <NuxtLink :to="localePath('news-investors')">{{
                    $t("news-menu01")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('news-esg')">{{
                    $t("news-menu02")
                  }}</NuxtLink>
                </li>
                <li>
                  <NuxtLink :to="localePath('news-campaign')">{{
                    $t("news-menu03")
                  }}</NuxtLink>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
      <div class="footer-bot">
        <div class="footer-bot-wrapper">
          <div>
            <img
              src="https://media.hannstar.com/Image/hannstar/header/logo.png"
              alt=""
            />
          </div>
          <div class="link-wrapper">
            <NuxtLink :to="localePath('contactUs')">{{
              $t("contact-us")
            }}</NuxtLink>
            <NuxtLink :to="localePath('information-privacy')">{{
              $t("private-policy")
            }}</NuxtLink>
            <NuxtLink :to="localePath('information-legalnotices')">{{
              $t("legal-announcement")
            }}</NuxtLink>
            <NuxtLink :to="localePath('sitemap')">{{
              $t("site-map")
            }}</NuxtLink>
            <a
              target="_blank"
              href="https://tw.linkedin.com/company/hannstar-display"
              rel="noreferrer"
            >
              <img
                src="https://media.hannstar.com/Image/hannstar/social_media_icons/icons8-linkedin-50.png"
                alt=""
              />
            </a>
            <a
              target="_blank"
              href="https://www.facebook.com/HannstarRecruiting/"
              rel="noreferrer"
            >
              <img
                src="https://media.hannstar.com/Image/hannstar/social_media_icons/icons8-facebook-50.png"
                alt=""
              />
            </a>
          </div>
          <div
            v-if="isButtonVisible"
            class="go-to-top-icon"
            @click="scrollToTop"
          >
            <p>TOP</p>
          </div>
          <div class="contact-icon">
            <NuxtLink :to="localePath('contactUs')">
              <img
                src="https://media.hannstar.com/Image/star_icon_hp.png"
                alt="contact hannstar"
              />
            </NuxtLink>
          </div>
          <div class="right">© 2024 HannStar. All Rights Reserved.</div>
        </div>
      </div>
    </footer>
  </div>
  <!-- Google Tag Manager noscript-->
  <div>
    <noscript>
      <iframe
        src="https://www.googletagmanager.com/ns.html?id=GTM-MFTHXVP"
        height="0"
        width="0"
        style="display: none; visibility: hidden"
      ></iframe>
    </noscript>
  </div>
</template>

<style lang="scss">
header.hannstar-header {
  position: sticky;
  top: 0;
  flex: 1 1 auto;
  box-sizing: border-box;
  background: linear-gradient(280deg, #039be5 0%, #0959a2 60%, #082e74 100%);
  width: 100%;
  height: 100px;
  z-index: 99;

  .hannstar-header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    width: 90%;
    max-width: 1600px;
    margin: 0 auto;

    @media (max-width: $mobileDeviceWidth) {
      width: 90%;
    }

    .header-nav-menu {
      @media screen and (max-width: $mobileDeviceWidth) {
        padding-top: 50px;
      }
      a {
        color: #000;
        border: none;
        outline: none;
        text-decoration: none;

        @media (max-width: $mobileDeviceWidth) {
          margin: 20px 0;
        }
      }
      .language-toggle {
        a {
          color: #777;
          padding: 0;
        }
      }

      @media (max-width: $mobileDeviceWidth) {
        position: fixed;
        top: 60px;
        left: 100%;
        height: 100%;
        width: 100%;
        z-index: 100;
        background-color: #363636;
        transition: 0.5s;
        overflow-y: auto;
        padding-bottom: 100px;
        box-sizing: border-box;

        &.active {
          left: 0;
        }

        ul {
          margin: 0 auto;
          width: 100%;
          li {
            a {
              padding: 0 20px;
            }
          }
        }
      }
    }

    @media (max-width: $mobileDeviceWidth) {
      .header-nav-box {
        ul {
          position: relative;
          transform: translate(0, 0);
          left: 0;
          top: 0;
          background: none;
          color: #fff;
          width: 100%;
          margin-top: 25px;

          li {
            padding: 20px 10px 20px 20px;
            border-bottom: 1px solid #999;
            text-align: left;
            background: #fff;
            box-sizing: border-box;

            a {
              color: #000;
            }
          }
        }

        &.active {
          ul {
            max-height: none;
          }
        }
      }
    }
  }

  .header-nav {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-end;

    @media (max-width: $mobileDeviceWidth) {
      display: block;
    }
  }

  .header-nav-lang {
    display: block;
    position: relative;
    height: 50%;
  }

  .header-nav-menu {
    display: block;
    position: relative;
    height: 50%;
  }

  .header-nav-box {
    // overflow: hidden;
    position: relative;
  }

  .header-nav-menu ul {
    list-style: none;

    @media (min-width: $mobileDeviceWidth) {
      :hover ul {
        max-height: 1000px;
      }
    }
  }

  .header-nav-menu ul ul {
    position: absolute;
    transform: translate(-50%, 100%);
    bottom: 0;
    padding: 0;
    left: 50%;
    background: #ddd;
    overflow: hidden;
    max-height: 0;
    transition: 1s;
    width: 185px;

    li {
      padding: 15px 20px;
      box-sizing: border-box;
      &:hover {
        background-color: #111;
        a {
          color: #fff;
        }
      }

      a {
        color: #000;
        border: none;
        outline: none;
        text-decoration: none;
      }
    }
  }

  .header-nav-menu > ul {
    display: flex;
    position: relative;
    margin: 0;
    gap: 40px;
    height: 100%;
    @media (max-width: $mobileDeviceWidth) {
      height: auto;
    }

    @media (max-width: $mobileDeviceWidth) {
      display: block;

      .ul-li-one {
        margin-top: 30px;
        border-bottom: 1px solid #b9b9b9;
      }
    }

    li {
      position: relative;
      text-align: center;
      height: 100%;

      span {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        color: #fff;
        cursor: pointer;
        position: relative;

        @media (min-width: $mobileDeviceWidth) {
          &:after {
            content: "";
            transform: translateY(-50%) rotate(135deg);
            position: absolute;
            right: -15px;
            top: 50%;
            width: 3px;
            height: 3px;
            border-top: 2px solid #fff;
            border-right: 2px solid #fff;
          }
        }

        @media (max-width: $mobileDeviceWidth) {
          width: 100%;
          justify-content: flex-start;
        }
      }
    }
  }
}

footer.hannstar-footer {
  background-color: #0959a2;
  color: #fff;
  display: block;

  ul.footer-first-ul {
    margin: 0;
    display: flex;
    align-items: flex-start;
    justify-content: space-evenly;
    width: 100%;
    max-width: 1600px;
    margin: 0 auto;

    & > li {
      width: 100%;

      @media (max-width: $mobileDeviceWidth) {
        border-bottom: 1px solid #b9b9b9;

        .header-nav-box {
          height: 0;
          transition: 0.5s;
          overflow: hidden;
          opacity: 0;

          ul {
            padding-left: 25px;
            margin-bottom: 25px;

            li {
              margin: 15px 0;
            }
          }

          div {
            opacity: 0;
            transition: 0.5s;
          }

          &.active {
            height: auto;
            opacity: 1;
          }
        }
      }
    }

    @media (max-width: $mobileDeviceWidth) {
      flex-direction: column;
      width: 90%;
      margin: 0 auto;
    }

    span {
      margin: 0 0 35px 0;
      display: block;
      font-weight: 600;

      @media (max-width: $mobileDeviceWidth) {
        margin: 0 0 15px 0;
      }
    }
  }

  ul {
    list-style: none;
    padding: 0;

    li {
      color: #fff;
      text-align: left;
      margin: 10px 0;

      a {
        text-decoration: none;
        color: #fff;
        text-align: left;
      }
    }
  }
}

.footer-top {
  padding: 50px 0;
  width: 90%;
  margin: 0 auto;
}

.footer-bot {
  background: linear-gradient(280deg, #039be5 0%, #0959a2 60%, #082e74 100%);

  .footer-bot-wrapper {
    width: 90%;
    max-width: 1600px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 80px;
    padding: 0 80px;

    @media (max-width: $mobileDeviceWidth) {
      flex-direction: column;
      height: auto;
      padding: 25px 0;
    }
  }

  .link-wrapper {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 65%;

    @media (max-width: $mobileDeviceWidth) {
      width: 100%;
      justify-content: center;
      margin: 15px 0;
    }

    a:not(:last-child) {
      border-right: 1px solid #fff;
    }

    a {
      padding: 2px 10px;
      text-decoration: none;
      color: #fff;
      font-size: 0.8em;

      img {
        width: 25px;
      }
    }
  }

  .right {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    font-size: 12px;
  }
}

@media screen and (max-width: $mobileDeviceWidth) {
  header.hannstar-header {
    height: 60px;
    padding: 0;
  }
}

.list-flex {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
}

.plus-icon {
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #ddd;
    transition: 0.3s ease-out;
  }

  &:after {
    content: "";
    position: absolute;
    top: 50%;
    right: 8px;
    width: 12px;
    height: 2px;
    background-color: #b9b9b9;
    transform: rotate(90deg);
    transition: all 0.3s ease-out;
  }

  &.open {
    &:after {
      transform: rotate(0);
    }
  }
}

footer.hannstar-footer ul.footer-first-ul span.plus-icon {
  @media (min-width: $mobileDeviceWidth) {
    display: none;
  }
}

.menu-button {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  cursor: pointer;

  span {
    display: block;
    height: 2px;
    width: 20px;
    background-color: #fff;
    margin: 5px 0;
  }
}

.language-selector {
  position: absolute;
  top: 0;
  right: 0;
  transform: translate(0, -100%);
  @media screen and (max-width: 968px) {
    top: 30px;
    left: 20px;
    transform: translate(0, 0);
  }
  button {
    color: #fff;
    &::after {
      content: "˅";
      display: inline-block;
      font-size: 1.25em;
      font-weight: 700;
      padding-left: 0.25em;
      transform: scaleY(0.5);
      transform-origin: center;
    }
    &.open {
      &::after {
        content: "˄";
      }
    }
  }
  .language-toggle {
    display: none;
    position: absolute;
    top: 2em;
    background-color: #fff;
    &.open {
      display: block;
    }
    ul {
      min-width: 100px;
      li {
        padding: 10px;
        &:hover {
          background-color: #e8e8e8;
        }
      }
    }
  }
}
.contact-icon {
  position: fixed;
  right: 0;
  bottom: 70px;
  transform: translate(-30%, -30%);
  background-color: #082e74;
  color: #fff;
  width: 60px;
  aspect-ratio: 1;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  cursor: pointer;
  &:hover {
    background-color: #111;
    transition: all 0.5s;
  }
  img {
    width: 45px;
  }
}
.go-to-top-icon {
  position: fixed;
  right: 0;
  bottom: 130px;
  transform: translate(-30%, -50%);
  background-color: #082e74;
  color: #fff;
  width: 60px;
  aspect-ratio: 1;
  border-radius: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  cursor: pointer;
  &:hover {
    background-color: #111;
    transition: all 0.5s;
  }
}
.site-search {
  position: absolute;
  top: 0px;
  right: 60px;
  transform: translate(-50%, -100%);
  @media screen and (max-width: 980px) {
    position: fixed;
    top: 30px;
    right: 80px;
    transform: translate(-50%, -50%);
    z-index: 100;
  }
  @media screen and (max-width: 768px) {
    right: 60px;
  }
  img {
    max-width: 18px;
    cursor: pointer;
  }
}

.pd-l-20 {
  padding-left: 20px;
  @media screen and (max-width: 968px) {
    padding-left: 0;
  }
}
</style>
