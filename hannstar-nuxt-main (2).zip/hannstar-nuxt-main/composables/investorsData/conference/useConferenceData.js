import { useI18n } from 'vue-i18n';

export const useConferenceData = () => {
    const { t } = useI18n();
    const conferenceData = [
        {
            "date": "2023/11/23",
            "title": t('investors-conference-table-title01'),
            "downloadLink": t('investors-conference-table-link01')
        },
        {
            "date": "2023/07/14",
            "title": t('investors-conference-table-title02'),
            "downloadLink": t('investors-conference-table-link02')
        },
        {
            "date": "2022/08/18",
            "title": t('investors-conference-table-title03'),
            "downloadLink": t('investors-conference-table-link03')
        },
        {
            "date": "2022/03/02",
            "title": t('investors-conference-table-title04'),
            "downloadLink": t('investors-conference-table-link04')
        },
        {
            "date": "2021/11/11",
            "title": t('investors-conference-table-title05'),
            "downloadLink": t('investors-conference-table-link05')
        },

        {
            "date": "2021/08/10",
            "title": t('investors-conference-table-title06'),
            "downloadLink": t('investors-conference-table-link06')
        },
        {
            "date": "2020/12/04",
            "title": t('investors-conference-table-title07'),
            "downloadLink": t('investors-conference-table-link07')
        },
        {
            "date": "2019/09/19",
            "title": t('investors-conference-table-title08'),
            "downloadLink": t('investors-conference-table-link08')
        },
        {
            "date": "2018/11/16",
            "title": t('investors-conference-table-title09'),
            "downloadLink": t('investors-conference-table-link09')
        },
        {
            "date": "2017/09/14",
            "title": t('investors-conference-table-title10'),
            "downloadLink": t('investors-conference-table-link10')
        },
        {
            "date": "2016/12/27",
            "title": t('investors-conference-table-title11'),
            "downloadLink": t('investors-conference-table-link11')
        }
    ]


    return {
        conferenceData,
    }
}