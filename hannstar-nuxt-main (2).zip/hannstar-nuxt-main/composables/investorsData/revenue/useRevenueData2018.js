import { useI18n } from 'vue-i18n';

export const useRevenueData2018 = () => {
    const { t } = useI18n();
    const revenueData2018 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "1,926",
            "yearlyChange": "-12.20%",
            "countBig": "308",
            "countSmall": "44,651",
            "yearlyChangeBig": "409.30%",
            "yearlyChangeSmall": "25%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "1,137",
            "yearlyChange": "-41.80%",
            "countBig": "84",
            "countSmall": "31,197",
            "yearlyChangeBig": "-8.80%",
            "yearlyChangeSmall": "-11.00%"
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "1,380",
            "yearlyChange": "-33.60%",
            "countBig": "286",
            "countSmall": "32,870",
            "yearlyChangeBig": "24.20%",
            "yearlyChangeSmall": "-27.80%"
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "1,383",
            "yearlyChange": "-6.40%",
            "countBig": "351",
            "countSmall": "27,140",
            "yearlyChangeBig": "245.80%",
            "yearlyChangeSmall": "-9.80%"
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "1,875",
            "yearlyChange": "15.30%",
            "countBig": "187",
            "countSmall": "45,288",
            "yearlyChangeBig": "-37.30%",
            "yearlyChangeSmall": "49.80%"
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "1,873",
            "yearlyChange": "16.70%",
            "countBig": "198",
            "countSmall": "46,490",
            "yearlyChangeBig": "18.40%",
            "yearlyChangeSmall": "39.40%"
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "1,623",
            "yearlyChange": "-23.30%",
            "countBig": "181",
            "countSmall": "47,319",
            "yearlyChangeBig": "20.10%",
            "yearlyChangeSmall": "19.70%"
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "1,326",
            "yearlyChange": "-45.00%",
            "countBig": "148",
            "countSmall": "35,578",
            "yearlyChangeBig": "111.10%",
            "yearlyChangeSmall": "-15.70%"
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "1,153",
            "yearlyChange": "-45.90%",
            "countBig": "176",
            "countSmall": "34,430",
            "yearlyChangeBig": "25.30%",
            "yearlyChangeSmall": "-4.10%"
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "1,333",
            "yearlyChange": "-44.60%",
            "countBig": "45",
            "countSmall": "47,250",
            "yearlyChangeBig": "-76.20%",
            "yearlyChangeSmall": "13.00%"
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "1,116",
            "yearlyChange": "-43.90%",
            "countBig": "109",
            "countSmall": "52,773",
            "yearlyChangeBig": "-30.50%",
            "yearlyChangeSmall": "34.90%"
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "741",
            "yearlyChange": "-57.80%",
            "countBig": "98",
            "countSmall": "24,251",
            "yearlyChangeBig": "-53.70%",
            "yearlyChangeSmall": "48.60%"
        }
    ]

    return {
        revenueData2018
    }
}