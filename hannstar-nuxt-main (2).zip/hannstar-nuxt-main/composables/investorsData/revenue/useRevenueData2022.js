import { useI18n } from 'vue-i18n';

export const useRevenueData2022 = () => {
    const { t } = useI18n();
    const revenueData2022 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "1,735",
            "yearlyChange": "-30.10%",
            "countBig": "166",
            "countSmall": "29,307",
            "yearlyChangeBig": "-30%",
            "yearlyChangeSmall": "37.50%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "1,481",
            "yearlyChange": "-37.70%",
            "countBig": "122",
            "countSmall": "34,598",
            "yearlyChangeBig": "-35.60%",
            "yearlyChangeSmall": "3.20%"
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "1,739",
            "yearlyChange": "-42.50%",
            "countBig": "63",
            "countSmall": "29,567",
            "yearlyChangeBig": "-87.90%",
            "yearlyChangeSmall": "-5.50%"
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "1,386",
            "yearlyChange": "-49.60%",
            "countBig": "38",
            "countSmall": "17,319",
            "yearlyChangeBig": "-78.30%",
            "yearlyChangeSmall": "-52.60%"
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "1,602",
            "yearlyChange": "-43.10%",
            "countBig": "312",
            "countSmall": "31,387",
            "yearlyChangeBig": "16.10%",
            "yearlyChangeSmall": "-10.70%"
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "1,505",
            "yearlyChange": "-39.80%",
            "countBig": "135",
            "countSmall": "41,296",
            "yearlyChangeBig": "-50.30%",
            "yearlyChangeSmall": "14.20%"
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "1,356",
            "yearlyChange": "-41.90%",
            "countBig": "94",
            "countSmall": "35,614",
            "yearlyChangeBig": "-77.20%",
            "yearlyChangeSmall": "-24.80%"
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "1,438",
            "yearlyChange": "-32.20%",
            "countBig": "50",
            "countSmall": "38,641",
            "yearlyChangeBig": "-86.70%",
            "yearlyChangeSmall": "-17.70%"
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "1,032",
            "yearlyChange": "-37.80%",
            "countBig": "54",
            "countSmall": "27,495",
            "yearlyChangeBig": "-91.60%",
            "yearlyChangeSmall": "-18.30%"
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "1,307",
            "yearlyChange": "-10.60%",
            "countBig": "59",
            "countSmall": "33,684",
            "yearlyChangeBig": "-83.90%",
            "yearlyChangeSmall": "23.80%"
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "1,328",
            "yearlyChange": "-30.50%",
            "countBig": "55",
            "countSmall": "31,431",
            "yearlyChangeBig": "-90.70%",
            "yearlyChangeSmall": "28.70%"
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "1,141",
            "yearlyChange": "-41.00%",
            "countBig": "101",
            "countSmall": "22,403",
            "yearlyChangeBig": "-75.50%",
            "yearlyChangeSmall": "-28.60%"
        }
    ]


    return {
        revenueData2022
    }
}