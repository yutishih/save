import { useI18n } from 'vue-i18n';

export const useRevenueData2020 = () => {
    const { t } = useI18n();
    const revenueData2020 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "1,104",
            "yearlyChange": "-6.00%",
            "countBig": "252",
            "countSmall": "17,052",
            "yearlyChangeBig": "268%",
            "yearlyChangeSmall": "-53%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "1,011",
            "yearlyChange": "14.80%",
            "countBig": "33",
            "countSmall": "34,319",
            "yearlyChangeBig": "-32.10%",
            "yearlyChangeSmall": "6.60%"
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "1,301",
            "yearlyChange": "7.90%",
            "countBig": "168",
            "countSmall": "30,228",
            "yearlyChangeBig": "1009.30%",
            "yearlyChangeSmall": "27.00%"
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "1,017",
            "yearlyChange": "-26.50%",
            "countBig": "169",
            "countSmall": "37,885",
            "yearlyChangeBig": "16.20%",
            "yearlyChangeSmall": "138.50%"
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "1,262",
            "yearlyChange": "-9.40%",
            "countBig": "179",
            "countSmall": "45,603",
            "yearlyChangeBig": "59.90%",
            "yearlyChangeSmall": "20.90%"
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "1,378",
            "yearlyChange": "-7.20%",
            "countBig": "218",
            "countSmall": "42,420",
            "yearlyChangeBig": "-43.00%",
            "yearlyChangeSmall": "59.50%"
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "1,475",
            "yearlyChange": "3.90%",
            "countBig": "87",
            "countSmall": "44,849",
            "yearlyChangeBig": "-47.30%",
            "yearlyChangeSmall": "38.90%"
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "1,907",
            "yearlyChange": "46.10%",
            "countBig": "230",
            "countSmall": "77,377",
            "yearlyChangeBig": "294.10%",
            "yearlyChangeSmall": "190.80%"
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "2,056",
            "yearlyChange": "31.80%",
            "countBig": "351",
            "countSmall": "32,779",
            "yearlyChangeBig": "140.20%",
            "yearlyChangeSmall": "-13.00%"
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "2,078",
            "yearlyChange": "38.80%",
            "countBig": "167",
            "countSmall": "30,666",
            "yearlyChangeBig": "167.00%",
            "yearlyChangeSmall": "-29.60%"
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "2,393",
            "yearlyChange": "63.00%",
            "countBig": "215",
            "countSmall": "30,077",
            "yearlyChangeBig": "-17.50%",
            "yearlyChangeSmall": "-29.80%"
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "2,571",
            "yearlyChange": "64.50%",
            "countBig": "301",
            "countSmall": "22,994",
            "yearlyChangeBig": "39.40%",
            "yearlyChangeSmall": "-37.40%"
        }
    ]

    return {
        revenueData2020
    }
}