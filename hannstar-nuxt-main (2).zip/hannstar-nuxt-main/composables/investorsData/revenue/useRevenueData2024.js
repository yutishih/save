import { useI18n } from 'vue-i18n';

export const useRevenueData2024 = () => {
    const { t } = useI18n();
    const revenueData2024 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "978",
            "yearlyChange": "25.3%",
            "countBig": "81",
            "countSmall": "53,404",
            "yearlyChangeBig": "-22.1%",
            "yearlyChangeSmall": "173.3%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "",
            "yearlyChange": "",
            "countBig": "",
            "countSmall": "",
            "yearlyChangeBig": "",
            "yearlyChangeSmall": ""
        }
    ]


    return {
        revenueData2024,
    }
}