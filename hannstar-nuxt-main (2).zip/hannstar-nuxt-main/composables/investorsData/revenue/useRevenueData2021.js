import { useI18n } from 'vue-i18n';

export const useRevenueData2021 = () => {
    const { t } = useI18n();
    const revenueData2021 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "2,481",
            "yearlyChange": "124.70%",
            "countBig": "237",
            "countSmall": "21,314",
            "yearlyChangeBig": "-6%",
            "yearlyChangeSmall": "25%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "2,379",
            "yearlyChange": "135.20%",
            "countBig": "190",
            "countSmall": "33,534",
            "yearlyChangeBig": "474.30%",
            "yearlyChangeSmall": "-2.30%"
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "3,028",
            "yearlyChange": "132.70%",
            "countBig": "525",
            "countSmall": "31,285",
            "yearlyChangeBig": "211.90%",
            "yearlyChangeSmall": "3.50%"
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "2,750",
            "yearlyChange": "170.40%",
            "countBig": "175",
            "countSmall": "36,526",
            "yearlyChangeBig": "3.50%",
            "yearlyChangeSmall": "-3.60%"
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "2,815",
            "yearlyChange": "123.00%",
            "countBig": "269",
            "countSmall": "35,137",
            "yearlyChangeBig": "50.30%",
            "yearlyChangeSmall": "-23.00%"
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "2,502",
            "yearlyChange": "81.60%",
            "countBig": "272",
            "countSmall": "36,169",
            "yearlyChangeBig": "25.00%",
            "yearlyChangeSmall": "-14.70%"
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "2,335",
            "yearlyChange": "58.30%",
            "countBig": "413",
            "countSmall": "47,371",
            "yearlyChangeBig": "376.00%",
            "yearlyChangeSmall": "5.60%"
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "2,120",
            "yearlyChange": "11.20%",
            "countBig": "373",
            "countSmall": "46,927",
            "yearlyChangeBig": "61.90%",
            "yearlyChangeSmall": "-39.40%"
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "1,659",
            "yearlyChange": "-19.30%",
            "countBig": "644",
            "countSmall": "33,649",
            "yearlyChangeBig": "83.60%",
            "yearlyChangeSmall": "2.70%"
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "1,462",
            "yearlyChange": "-29.60%",
            "countBig": "367",
            "countSmall": "27,211",
            "yearlyChangeBig": "120.20%",
            "yearlyChangeSmall": "-11.30%"
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "1,911",
            "yearlyChange": "-20.10%",
            "countBig": "592",
            "countSmall": "24,422",
            "yearlyChangeBig": "175.50%",
            "yearlyChangeSmall": "-18.80%"
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "1,935",
            "yearlyChange": "-24.70%",
            "countBig": "412",
            "countSmall": "31,360",
            "yearlyChangeBig": "36.70%",
            "yearlyChangeSmall": "36.40%"
        }
    ]

    return {
        revenueData2021
    }
}