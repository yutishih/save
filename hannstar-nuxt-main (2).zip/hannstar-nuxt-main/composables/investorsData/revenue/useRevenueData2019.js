import { useI18n } from 'vue-i18n';

export const useRevenueData2019 = () => {
    const { t } = useI18n();
    const revenueData2019 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "1,175",
            "yearlyChange": " -39.0%",
            "countBig": "68",
            "countSmall": "36,622",
            "yearlyChangeBig": " -77.8%",
            "yearlyChangeSmall": "-18%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "881",
            "yearlyChange": "-22.50%",
            "countBig": "49",
            "countSmall": "32,185",
            "yearlyChangeBig": "-42.40%",
            "yearlyChangeSmall": "3.20%"
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "1,206",
            "yearlyChange": "-12.60%",
            "countBig": "15",
            "countSmall": "23,805",
            "yearlyChangeBig": "-94.70%",
            "yearlyChangeSmall": "-27.60%"
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "1,383",
            "yearlyChange": "0.10%",
            "countBig": "146",
            "countSmall": "15,844",
            "yearlyChangeBig": "-15.80%",
            "yearlyChangeSmall": "-41.50%"
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "1,394",
            "yearlyChange": "-25.70%",
            "countBig": "112",
            "countSmall": "37,715",
            "yearlyChangeBig": "-40.20%",
            "yearlyChangeSmall": "-16.70%"
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "1,484",
            "yearlyChange": "-20.80%",
            "countBig": "382",
            "countSmall": "26,596",
            "yearlyChangeBig": "93.00%",
            "yearlyChangeSmall": "-42.80%"
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "1,420",
            "yearlyChange": "-12.50%",
            "countBig": "165",
            "countSmall": "32,285",
            "yearlyChangeBig": "-9.00%",
            "yearlyChangeSmall": "-31.80%"
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "1,305",
            "yearlyChange": "-1.60%",
            "countBig": "58",
            "countSmall": "26,607",
            "yearlyChangeBig": "-60.50%",
            "yearlyChangeSmall": "-25.20%"
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "1,559",
            "yearlyChange": "35.30%",
            "countBig": "146",
            "countSmall": "37,692",
            "yearlyChangeBig": "-17.20%",
            "yearlyChangeSmall": "9.50%"
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "1,498",
            "yearlyChange": "12.40%",
            "countBig": "62",
            "countSmall": "43,542",
            "yearlyChangeBig": "38.30%",
            "yearlyChangeSmall": "-7.80%"
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "1,468",
            "yearlyChange": "31.60%",
            "countBig": "260",
            "countSmall": "42,867",
            "yearlyChangeBig": "139.50%",
            "yearlyChangeSmall": "-12.80%"
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "1,563",
            "yearlyChange": "110.80%",
            "countBig": "216",
            "countSmall": "36,729",
            "yearlyChangeBig": "121.60%",
            "yearlyChangeSmall": "51.50%"
        }
    ]

    return {
        revenueData2019
    }
}