import { useI18n } from 'vue-i18n';

export const useRevenueData2023 = () => {
    const { t } = useI18n();
    const revenueData2023 = [
        {
            "date": t('investors-revenue-table-month01'),
            "monthlyIncome": "781",
            "yearlyChange": "-55.00%",
            "countBig": "104",
            "countSmall": "19,542",
            "yearlyChangeBig": "-37.10%",
            "yearlyChangeSmall": "-33.30%"
        },
        {
            "date": t('investors-revenue-table-month02'),
            "monthlyIncome": "767",
            "yearlyChange": "-48.20%",
            "countBig": "61",
            "countSmall": "15,225",
            "yearlyChangeBig": "-49.90%",
            "yearlyChangeSmall": "-56.00%"
        },
        {
            "date": t('investors-revenue-table-month03'),
            "monthlyIncome": "1,129",
            "yearlyChange": "-35.10%",
            "countBig": "106",
            "countSmall": "23,892",
            "yearlyChangeBig": "66.40%",
            "yearlyChangeSmall": "-19.20%"
        },
        {
            "date": t('investors-revenue-table-month04'),
            "monthlyIncome": "1,189",
            "yearlyChange": "-14.20%",
            "countBig": "317",
            "countSmall": "35,342",
            "yearlyChangeBig": "736.60%",
            "yearlyChangeSmall": "104.10%"
        },
        {
            "date": t('investors-revenue-table-month05'),
            "monthlyIncome": "1,006",
            "yearlyChange": "-37.20%",
            "countBig": "91",
            "countSmall": "23,252",
            "yearlyChangeBig": "-70.90%",
            "yearlyChangeSmall": "-25.90%"
        },
        {
            "date": t('investors-revenue-table-month06'),
            "monthlyIncome": "1,221",
            "yearlyChange": "-18.80%",
            "countBig": "114",
            "countSmall": "33,456",
            "yearlyChangeBig": "-16.00%",
            "yearlyChangeSmall": "-19.00%"
        },
        {
            "date": t('investors-revenue-table-month07'),
            "monthlyIncome": "1,099",
            "yearlyChange": "-18.90%",
            "countBig": "57",
            "countSmall": "22,630",
            "yearlyChangeBig": "-39.20%",
            "yearlyChangeSmall": "-36.50%"
        },
        {
            "date": t('investors-revenue-table-month08'),
            "monthlyIncome": "1,137",
            "yearlyChange": "-20.90%",
            "countBig": "89",
            "countSmall": "12,089",
            "yearlyChangeBig": "79.10%",
            "yearlyChangeSmall": "-68.70%"
        },
        {
            "date": t('investors-revenue-table-month09'),
            "monthlyIncome": "1,027",
            "yearlyChange": "-0.50%",
            "countBig": "261",
            "countSmall": "14,323",
            "yearlyChangeBig": "379.60%",
            "yearlyChangeSmall": "-47.90%"
        },
        {
            "date": t('investors-revenue-table-month10'),
            "monthlyIncome": "1,043",
            "yearlyChange": "-20.20%",
            "countBig": "159",
            "countSmall": "12,378",
            "yearlyChangeBig": "168.40%",
            "yearlyChangeSmall": "-63.30%"
        },
        {
            "date": t('investors-revenue-table-month11'),
            "monthlyIncome": "1,021",
            "yearlyChange": "-23.1%",
            "countBig": "467",
            "countSmall": "23,999",
            "yearlyChangeBig": "752.6%",
            "yearlyChangeSmall": "-23.6%"
        },
        {
            "date": t('investors-revenue-table-month12'),
            "monthlyIncome": "933",
            "yearlyChange": "-18.2%",
            "countBig": "127",
            "countSmall": "36,649",
            "yearlyChangeBig": "26.3%",
            "yearlyChangeSmall": "63.6%"
        }
    ]


    return {
        revenueData2023,
    }
}