import { useI18n } from 'vue-i18n';

export const useReportData2022 = () => {
    const { t } = useI18n();
    const reportData2022 = [
        {
            "year": "2022 Q1",
            "title": "2022 Q1 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2022-quarterly-report-link01')
        },
        {
            "year": "2022 Q2",
            "title": "2022 Q2 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2022-quarterly-report-link02')
        },
        {
            "year": "2022 Q3",
            "title": "2022 Q3 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2022-quarterly-report-link03')
        },
        {
            "year": "2022 Q4",
            "title": "2022 Q4 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2022-quarterly-report-link04')

        },
        {
            "year": "2022",
            "title": "2022 " + t('investors-report-table-individual-report'),
            "downloadLink": t('investors-report-2022-individual-report-link')
        },
        {
            "year": "2022",
            "title": "2022 " + t('investors-report-table-annually-report'),
            "downloadLink": t('investors-report-2022-annually-report-link')
        },
    ]


    return {
        reportData2022,
    }
}