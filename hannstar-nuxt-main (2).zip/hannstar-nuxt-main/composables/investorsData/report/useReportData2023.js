import { useI18n } from 'vue-i18n';

export const useReportData2023 = () => {
    const { t } = useI18n();
    const reportData2023 = [
        {
            "year": "2023 Q1",
            "title": "2023 Q1 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2023-quarterly-report-link01')
        },
        {
            "year": "2023 Q2",
            "title": "2023 Q2 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2023-quarterly-report-link02')
        },
        {
            "year": "2023 Q3",
            "title": "2023 Q3 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2023-quarterly-report-link03')
        },
        {
            "year": "2023 Q4",
            "title": "2023 Q4 " + t('investors-report-table-quarterly-report'),
            "downloadLink": ""
        },
        {
            "year": "2023",
            "title": "2023 " + t('investors-report-table-individual-report'),
            "downloadLink": ""
        },
        {
            "year": "2023",
            "title": "2023 " + t('investors-report-table-annually-report'),
            "downloadLink": ""
        },
    ]


    return {
        reportData2023,
    }
}