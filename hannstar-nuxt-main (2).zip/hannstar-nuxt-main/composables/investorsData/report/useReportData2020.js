import { useI18n } from 'vue-i18n';

export const useReportData2020 = () => {
    const { t } = useI18n();
    const reportData2020 = [
        {
            "year": "2020 Q1",
            "title": "2020 Q1 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2020-quarterly-report-link01')
        },
        {
            "year": "2020 Q2",
            "title": "2020 Q2 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2020-quarterly-report-link02')
        },
        {
            "year": "2020 Q3",
            "title": "2020 Q3 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2020-quarterly-report-link03')
        },
        {
            "year": "2020 Q4",
            "title": "2020 Q4 " + t('investors-report-table-quarterly-report'),
            "downloadLink": t('investors-report-2020-quarterly-report-link04')

        },
        {
            "year": "2020",
            "title": "2020 " + t('investors-report-table-individual-report'),
            "downloadLink": t('investors-report-2020-individual-report-link')
        },
        {
            "year": "2020",
            "title": "2020 " + t('investors-report-table-annually-report'),
            "downloadLink": t('investors-report-2020-annually-report-link')
        },
    ]


    return {
        reportData2020,
    }
}