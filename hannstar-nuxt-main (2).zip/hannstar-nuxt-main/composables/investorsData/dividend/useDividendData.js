import { useI18n } from 'vue-i18n';

export const useDividendData = () => {
    const { t } = useI18n();
    const dividendData = [
        {
            "year": "2022",
            "date": "2023/05/25",
            "interest": 0,
            "tradeDate": "",
            "issueDate": "",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },
        {
            "year": "2021",
            "date": "2022/05/26",
            "interest": 1.0,
            "tradeDate": "2022/06/16",
            "issueDate": "2022/07/13",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },
        {
            "year": "2020",
            "date": "2021/07/29",
            "interest": 0.5,
            "tradeDate": "2021/08/23",
            "issueDate": "2021/09/13",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },
        {
            "year": "2019",
            "date": "2020/06/05",
            "interest": 0,
            "tradeDate": "",
            "issueDate": "",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },
        {
            "year": "2018",
            "date": "2019/06/05	",
            "interest": 0.3,
            "tradeDate": "2019/07/30",
            "issueDate": "2019/08/28",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },
        {
            "year": "2017",
            "date": "2018/06/08",
            "interest": 0.5,
            "tradeDate": "2018/07/05",
            "issueDate": "2018/08/03",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },
        {
            "year": "2016",
            "date": "2017/06/08",
            "interest": 0.5,
            "tradeDate": "2017/08/21",
            "issueDate": "2017/09/12",
            "shareInterest": 0,
            "exDividendDate": "",
            "listDate": ""
        },

        {
            "year": "2013",
            "date": "2014/06/12",
            "interest": 0.15,
            "tradeDate": "2014/08/29",
            "issueDate": "2014/09/24",
            "shareInterest": 1.15,
            "exDividendDate": "2014/08/29",
            "listDate": "2014/09/17"
        },

        {
            "year": "2007",
            "date": "2008/06/13",
            "interest": 0.74995,
            "tradeDate": "2008/08/05",
            "issueDate": "2008/08/29",
            "shareInterest": 0.74995,
            "exDividendDate": "2008/08/05",
            "listDate": "2008/08/26"
        },

        {
            "year": "2004",
            "date": "2005/05/26",
            "interest": 0,
            "tradeDate": "",
            "issueDate": "",
            "shareInterest": 0.335,
            "exDividendDate": "2005/07/20",
            "listDate": "2005/08/17"
        },
    ]


    return {
        dividendData,
    }
}