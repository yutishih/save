import { useI18n } from 'vue-i18n';

export const useHolderMeet2021 = () => {
    const { t } = useI18n();
    const holderMeeting2021 = [
        {
            "year": "2021/04/23",
            "title": t('investors-shareholdermeeting-2021-title01'),
            "downloadLink": t('investors-shareholdermeeting-2021-link01'),
        },
        {
            "year": "2021/05/13",
            "title": t('investors-shareholdermeeting-2021-title02'),
            "downloadLink": t('investors-shareholdermeeting-2021-link02'),
        },
        {
            "year": "2021/07/29",
            "title": t('investors-shareholdermeeting-2021-title03'),
            "downloadLink": t('investors-shareholdermeeting-2021-link03'),
        }
    ]


    return {
        holderMeeting2021,
    }
}