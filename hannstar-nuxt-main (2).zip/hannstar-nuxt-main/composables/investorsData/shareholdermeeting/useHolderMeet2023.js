import { useI18n } from 'vue-i18n';

export const useHolderMeet2023 = () => {
    const { t } = useI18n();
    const holderMeeting2023 = [
        {
            "year": "2023/06/08",
            "title": t('investors-shareholdermeeting-2023-title01'),
            "downloadLink": t('investors-shareholdermeeting-2023-link01'),
        },
        {
            "year": "2023/05/25",
            "title": t('investors-shareholdermeeting-2023-title02'),
            "downloadLink": t('investors-shareholdermeeting-2023-link02'),
        },
        {
            "year": "2023/05/05",
            "title": t('investors-shareholdermeeting-2023-title03'),
            "downloadLink": t('investors-shareholdermeeting-2023-link03'),
        },
        {
            "year": "2023/05/05",
            "title": t('investors-shareholdermeeting-2023-title04'),
            "downloadLink": t('investors-shareholdermeeting-2023-link04'),
        },
        {
            "year": "2023/05/05",
            "title": t('investors-shareholdermeeting-2023-title05'),
            "downloadLink": t('investors-shareholdermeeting-2023-link05'),
        },
    ]


    return {
        holderMeeting2023,
    }
}