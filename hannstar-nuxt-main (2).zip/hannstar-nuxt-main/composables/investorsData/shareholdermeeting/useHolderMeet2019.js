import { useI18n } from 'vue-i18n';

export const useHolderMeet2019 = () => {
    const { t } = useI18n();
    const holderMeeting2019 = [
        {
            "year": "2019/06/05",
            "title": t('investors-shareholdermeeting-2019-title01'),
            "downloadLink": t('investors-shareholdermeeting-2019-link01'),
        },
        {
            "year": "2019/05/05",
            "title": t('investors-shareholdermeeting-2019-title02'),
            "downloadLink": t('investors-shareholdermeeting-2019-link02'),
        },
        {
            "year": "2019/06/05",
            "title": t('investors-shareholdermeeting-2019-title03'),
            "downloadLink": t('investors-shareholdermeeting-2019-link03'),
        }
    ]


    return {
        holderMeeting2019,
    }
}