import { useI18n } from 'vue-i18n';

export const useHolderMeet2020 = () => {
    const { t } = useI18n();
    const holderMeeting2020 = [
        {
            "year": "2020/06/05",
            "title": t('investors-shareholdermeeting-2020-title01'),
            "downloadLink": t('investors-shareholdermeeting-2020-link01'),
        },
        {
            "year": "2020/05/05",
            "title": t('investors-shareholdermeeting-2020-title02'),
            "downloadLink": t('investors-shareholdermeeting-2020-link02'),
        },
        {
            "year": "2020/06/05",
            "title": t('investors-shareholdermeeting-2020-title03'),
            "downloadLink": t('investors-shareholdermeeting-2020-link03'),
        }
    ]


    return {
        holderMeeting2020,
    }
}