import { useI18n } from 'vue-i18n';

export const useHolderMeet2022 = () => {
    const { t } = useI18n();
    const holderMeeting2022 = [
        {
            "year": "2022/04/25",
            "title": t('investors-shareholdermeeting-2022-title01'),
            "downloadLink": t('investors-shareholdermeeting-2022-link01'),
        },
        {
            "year": "2022/04/25",
            "title": t('investors-shareholdermeeting-2022-title02'),
            "downloadLink": t('investors-shareholdermeeting-2022-link02'),
        },
        {
            "year": "2022/05/26",
            "title": t('investors-shareholdermeeting-2022-title03'),
            "downloadLink": t('investors-shareholdermeeting-2022-link03'),
        }
    ]


    return {
        holderMeeting2022,
    }
}