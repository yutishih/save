//useContactUs.jss
import { reactive, toRefs } from 'vue';
import axios from 'axios'

export const useContactUs = () => {
    const postContactUsData = reactive({
        isData: null,
        isLoading: false,
        error: null
    })

    const tokenConfig = {
        "x-api-key": "LAmsduWSX36T7Z7sXTtKW6YdVuBWQwHcQ8KbCRA2",
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
    }

    const postContactUsApi = async (tokenBody, key) => {
        postContactUsData.isLoading = true

        try {
            // mockAPI: http://localhost:3001/index.php/rest/V1/eipDev
            // prd: https://kqnq4ps8u2.execute-api.us-west-2.amazonaws.com/eipPRD
            // dev: https://kqnq4ps8u2.execute-api.us-west-2.amazonaws.com/eipDev
            // env檔案: import.meta.env.VITE_CONTACTUS_API_URL
            const response = await axios.post("https://kqnq4ps8u2.execute-api.us-west-2.amazonaws.com/eipPRD", tokenBody, tokenConfig)
            postContactUsData.isData = response.data
            // console.log(postContactUsData.isData)
            return postContactUsData.isData;
        } catch (error) {
            postContactUsData.error = error
            console.log(error.message)
            return null
        } finally {
            postContactUsData.isLoading = false
        }
    }

    return { ...toRefs(postContactUsData), postContactUsApi }
}