import { useI18n } from 'vue-i18n';

export const useRBAData = () => {
    const { t } = useI18n();
    const RBAData = [
        {
            "object": t('sustainability-social-RBA-table-object01'),
            "content": t('sustainability-social-RBA-table-content01'),
            "goal": t('sustainability-social-RBA-table-goal01'),
            "achievement": t('sustainability-social-RBA-table-achievement01'),
        },
        {
            "object": t('sustainability-social-RBA-table-object02'),
            "content": t('sustainability-social-RBA-table-content02'),
            "goal": t('sustainability-social-RBA-table-goal02'),
            "achievement": t('sustainability-social-RBA-table-achievement02'),
        },
        {
            "object": t('sustainability-social-RBA-table-object03'),
            "content": t('sustainability-social-RBA-table-content03'),
            "goal": t('sustainability-social-RBA-table-goal03'),
            "achievement": t('sustainability-social-RBA-table-achievement03'),
        },
        {
            "object": t('sustainability-social-RBA-table-object04'),
            "content": t('sustainability-social-RBA-table-content04'),
            "goal": t('sustainability-social-RBA-table-goal04'),
            "achievement": t('sustainability-social-RBA-table-achievement04'),
        }
    ]


    return {
        RBAData,
    }
}