import { useI18n } from 'vue-i18n';

export const useAuditData = () => {
    const { t } = useI18n();
    const directorData = [
        {
            "title": t('sustainability-governance-audit-table01-position01'),
            "name": t('sustainability-governance-audit-table01-name01'),
            "positions": t('sustainability-governance-audit-table01-current01'),
        },
        {
            "title": t('sustainability-governance-audit-table01-position02'),
            "name": t('sustainability-governance-audit-table01-name02'),
            "positions": t('sustainability-governance-audit-table01-current02'),
        },
        {
            "title": t('sustainability-governance-audit-table01-position03'),
            "name": t('sustainability-governance-audit-table01-name03'),
            "positions": t('sustainability-governance-audit-table01-current03'),
        },
        {
            "title": t('sustainability-governance-audit-table01-position04'),
            "name": t('sustainability-governance-audit-table01-name04'),
            "positions": t('sustainability-governance-audit-table01-current04'),
        }
    ]

    const auditData = [
        {
            "date": t('sustainability-governance-audit-table02-date01'),
            "meeting": t('sustainability-governance-audit-table02-meeting01'),
            "points": [t('sustainability-governance-audit-table02-points01_1'), t('sustainability-governance-audit-table02-points01_2'),],
            "advice": t('sustainability-governance-audit-table02-advice01'),
            "operation": t('sustainability-governance-audit-table02-operation01'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date02'),
            "meeting": t('sustainability-governance-audit-table02-meeting02'),
            "points": [t('sustainability-governance-audit-table02-points02_1'), t('sustainability-governance-audit-table02-points02_2'),],
            "advice": t('sustainability-governance-audit-table02-advice02'),
            "operation": t('sustainability-governance-audit-table02-operation02'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date03'),
            "meeting": t('sustainability-governance-audit-table02-meeting03'),
            "points": [t('sustainability-governance-audit-table02-points03_1'), t('sustainability-governance-audit-table02-points03_2'), t('sustainability-governance-audit-table02-points03_3'),],
            "advice": t('sustainability-governance-audit-table02-advice03'),
            "operation": t('sustainability-governance-audit-table02-operation03'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date04'),
            "meeting": t('sustainability-governance-audit-table02-meeting04'),
            "points": [t('sustainability-governance-audit-table02-points04_1'), t('sustainability-governance-audit-table02-points04_2'),],
            "advice": t('sustainability-governance-audit-table02-advice04'),
            "operation": t('sustainability-governance-audit-table02-operation04'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date05'),
            "meeting": t('sustainability-governance-audit-table02-meeting05'),
            "points": [t('sustainability-governance-audit-table02-points05_1'), t('sustainability-governance-audit-table02-points05_2'),],
            "advice": t('sustainability-governance-audit-table02-advice05'),
            "operation": t('sustainability-governance-audit-table02-operation05'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date06'),
            "meeting": t('sustainability-governance-audit-table02-meeting06'),
            "points": [t('sustainability-governance-audit-table02-points06_1'), t('sustainability-governance-audit-table02-points06_2'),],
            "advice": t('sustainability-governance-audit-table02-advice06'),
            "operation": t('sustainability-governance-audit-table02-operation06'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date07'),
            "meeting": t('sustainability-governance-audit-table02-meeting07'),
            "points": [t('sustainability-governance-audit-table02-points07_1'), t('sustainability-governance-audit-table02-points07_2'), t('sustainability-governance-audit-table02-points07_3'),],
            "advice": t('sustainability-governance-audit-table02-advice07'),
            "operation": t('sustainability-governance-audit-table02-operation07'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date08'),
            "meeting": t('sustainability-governance-audit-table02-meeting08'),
            "points": [t('sustainability-governance-audit-table02-points08_1'), t('sustainability-governance-audit-table02-points08_2'),],
            "advice": t('sustainability-governance-audit-table02-advice08'),
            "operation": t('sustainability-governance-audit-table02-operation08'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date09'),
            "meeting": t('sustainability-governance-audit-table02-meeting09'),
            "points": [t('sustainability-governance-audit-table02-points09_1'), t('sustainability-governance-audit-table02-points09_2'),],
            "advice": t('sustainability-governance-audit-table02-advice09'),
            "operation": t('sustainability-governance-audit-table02-operation09'),
        },
        {
            "date": t('sustainability-governance-audit-table02-date10'),
            "meeting": t('sustainability-governance-audit-table02-meeting10'),
            "points": [t('sustainability-governance-audit-table02-points10_1'), t('sustainability-governance-audit-table02-points10_2'),],
            "advice": t('sustainability-governance-audit-table02-advice10'),
            "operation": t('sustainability-governance-audit-table02-operation10'),
        }
    ]


    return {
        directorData,
        auditData
    }
}