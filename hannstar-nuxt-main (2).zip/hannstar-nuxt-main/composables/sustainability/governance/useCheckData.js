import { useI18n } from 'vue-i18n';

export const useCheckData = () => {
    const { t } = useI18n();
    const checkData = [
        {
            "date": t('sustainability-governance-check-table-date01'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication01'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion01'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date02'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication02_1'),
                t('sustainability-governance-check-table-communication02_2'),
                t('sustainability-governance-check-table-communication02_3'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion02_1'),
                t('sustainability-governance-check-table-conclusion02_2'),
                t('sustainability-governance-check-table-conclusion02_3'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date03'),
            "meeting": t('sustainability-governance-check-table-meeting03'),
            "communication": [
                t('sustainability-governance-check-table-communication03_1'),
                t('sustainability-governance-check-table-communication03_2'),
                t('sustainability-governance-check-table-communication03_3'),
                t('sustainability-governance-check-table-communication03_4'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion03_1'),
                t('sustainability-governance-check-table-conclusion03_2'),
                t('sustainability-governance-check-table-conclusion03_3'),
                t('sustainability-governance-check-table-conclusion03_4'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date04'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication04_1'),
                t('sustainability-governance-check-table-communication04_2'),
                t('sustainability-governance-check-table-communication04_3'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion04_1'),
                t('sustainability-governance-check-table-conclusion04_2'),
                t('sustainability-governance-check-table-conclusion04_3'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date05'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication05_1'),
                t('sustainability-governance-check-table-communication05_2'),
                t('sustainability-governance-check-table-communication05_3'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion05_1'),
                t('sustainability-governance-check-table-conclusion05_2'),
                t('sustainability-governance-check-table-conclusion05_3'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date06'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication06_1'),
                t('sustainability-governance-check-table-communication06_2'),
                t('sustainability-governance-check-table-communication06_3'),
                t('sustainability-governance-check-table-communication06_4'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion06_1'),
                t('sustainability-governance-check-table-conclusion06_2'),
                t('sustainability-governance-check-table-conclusion06_3'),
                t('sustainability-governance-check-table-conclusion06_4'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date07'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication07_1'),
                t('sustainability-governance-check-table-communication07_2'),
                t('sustainability-governance-check-table-communication07_3'),
                t('sustainability-governance-check-table-communication07_4'),
                t('sustainability-governance-check-table-communication07_5'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion07_1'),
                t('sustainability-governance-check-table-conclusion07_2'),
                t('sustainability-governance-check-table-conclusion07_3'),
                t('sustainability-governance-check-table-conclusion07_4'),
                t('sustainability-governance-check-table-conclusion07_5'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date08'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication08_1'),
                t('sustainability-governance-check-table-communication08_2'),
                t('sustainability-governance-check-table-communication08_3'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion08_1'),
                t('sustainability-governance-check-table-conclusion08_2'),
                t('sustainability-governance-check-table-conclusion08_3'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date09'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication09_1'),
                t('sustainability-governance-check-table-communication09_2'),
                t('sustainability-governance-check-table-communication09_3'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion09_1'),
                t('sustainability-governance-check-table-conclusion09_2'),
                t('sustainability-governance-check-table-conclusion09_3'),
            ]
        },
        {
            "date": t('sustainability-governance-check-table-date10'),
            "meeting": t('sustainability-governance-check-table-meeting01'),
            "communication": [
                t('sustainability-governance-check-table-communication10_1'),
                t('sustainability-governance-check-table-communication10_2'),
                t('sustainability-governance-check-table-communication10_3'),
            ],
            "conclusion": [
                t('sustainability-governance-check-table-conclusion10_1'),
                t('sustainability-governance-check-table-conclusion10_2'),
                t('sustainability-governance-check-table-conclusion10_3'),
            ]
        },
    ]


    return {
        checkData,
    }
}