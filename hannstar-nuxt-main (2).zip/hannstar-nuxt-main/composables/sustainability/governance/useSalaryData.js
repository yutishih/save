import { useI18n } from 'vue-i18n';

export const useSalaryData = () => {
    const { t } = useI18n();
    const salaryData = [
        {
            "title": t('sustainability-governance-salary-table-position01'),
            "name": t('sustainability-governance-salary-table-name01'),
            "positions": t('sustainability-governance-salary-table-current01'),
        },
        {
            "title": t('sustainability-governance-salary-table-position02'),
            "name": t('sustainability-governance-salary-table-name02'),
            "positions": t('sustainability-governance-salary-table-current02'),
        },
        {
            "title": t('sustainability-governance-salary-table-position03'),
            "name": t('sustainability-governance-salary-table-name03'),
            "positions": t('sustainability-governance-salary-table-current03'),
        }
    ]


    return {
        salaryData,
    }
}