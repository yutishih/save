import { useI18n } from 'vue-i18n';

export const useCharterData = () => {
    const { t } = useI18n();
    const charterData = [
        {
            "year": t('sustainability-governance-charter-table-year01'),
            "title": t('sustainability-governance-charter-table-title01'),
            "downloadLink": t('sustainability-governance-charter-table-link01'),
        },
        {
            "year": t('sustainability-governance-charter-table-year02'),
            "title": t('sustainability-governance-charter-table-title02'),
            "downloadLink": t('sustainability-governance-charter-table-link02'),
        },
        {
            "year": t('sustainability-governance-charter-table-year03'),
            "title": t('sustainability-governance-charter-table-title03'),
            "downloadLink": t('sustainability-governance-charter-table-link03'),
        },
        {
            "year": t('sustainability-governance-charter-table-year04'),
            "title": t('sustainability-governance-charter-table-title04'),
            "downloadLink": t('sustainability-governance-charter-table-link04'),
        },
        {
            "year": t('sustainability-governance-charter-table-year05'),
            "title": t('sustainability-governance-charter-table-title05'),
            "downloadLink": t('sustainability-governance-charter-table-link05'),
        },
        {
            "year": t('sustainability-governance-charter-table-year06'),
            "title": t('sustainability-governance-charter-table-title06'),
            "downloadLink": t('sustainability-governance-charter-table-link06'),
        },
        {
            "year": t('sustainability-governance-charter-table-year07'),
            "title": t('sustainability-governance-charter-table-title07'),
            "downloadLink": t('sustainability-governance-charter-table-link07'),
        },
        {
            "year": t('sustainability-governance-charter-table-year08'),
            "title": t('sustainability-governance-charter-table-title08'),
            "downloadLink": t('sustainability-governance-charter-table-link08'),
        },
        {
            "year": t('sustainability-governance-charter-table-year09'),
            "title": t('sustainability-governance-charter-table-title09'),
            "downloadLink": t('sustainability-governance-charter-table-link09'),
        },
        {
            "year": t('sustainability-governance-charter-table-year10'),
            "title": t('sustainability-governance-charter-table-title10'),
            "downloadLink": t('sustainability-governance-charter-table-link10'),
        },
        {
            "year": t('sustainability-governance-charter-table-year11'),
            "title": t('sustainability-governance-charter-table-title11'),
            "downloadLink": t('sustainability-governance-charter-table-link11'),
        },
        {
            "year": t('sustainability-governance-charter-table-year12'),
            "title": t('sustainability-governance-charter-table-title12'),
            "downloadLink": t('sustainability-governance-charter-table-link12'),
        },
        {
            "year": t('sustainability-governance-charter-table-year13'),
            "title": t('sustainability-governance-charter-table-title13'),
            "downloadLink": t('sustainability-governance-charter-table-link13'),
        },
        {
            "year": t('sustainability-governance-charter-table-year14'),
            "title": t('sustainability-governance-charter-table-title14'),
            "downloadLink": t('sustainability-governance-charter-table-link14'),
        },
        {
            "year": t('sustainability-governance-charter-table-year15'),
            "title": t('sustainability-governance-charter-table-title15'),
            "downloadLink": t('sustainability-governance-charter-table-link15'),
        },
        {
            "year": t('sustainability-governance-charter-table-year16'),
            "title": t('sustainability-governance-charter-table-title16'),
            "downloadLink": t('sustainability-governance-charter-table-link16'),
        },
        {
            "year": t('sustainability-governance-charter-table-year17'),
            "title": t('sustainability-governance-charter-table-title17'),
            "downloadLink": t('sustainability-governance-charter-table-link17'),
        },
        {
            "year": t('sustainability-governance-charter-table-year18'),
            "title": t('sustainability-governance-charter-table-title18'),
            "downloadLink": t('sustainability-governance-charter-table-link18'),
        },
        {
            "year": t('sustainability-governance-charter-table-year19'),
            "title": t('sustainability-governance-charter-table-title19'),
            "downloadLink": t('sustainability-governance-charter-table-link19'),
        },
        {
            "year": t('sustainability-governance-charter-table-year20'),
            "title": t('sustainability-governance-charter-table-title20'),
            "downloadLink": t('sustainability-governance-charter-table-link20'),
        },
        {
            "year": t('sustainability-governance-charter-table-year21'),
            "title": t('sustainability-governance-charter-table-title21'),
            "downloadLink": t('sustainability-governance-charter-table-link21'),
        },
        {
            "year": t('sustainability-governance-charter-table-year22'),
            "title": t('sustainability-governance-charter-table-title22'),
            "downloadLink": t('sustainability-governance-charter-table-link22'),
        }
    ]


    return {
        charterData,
    }
}