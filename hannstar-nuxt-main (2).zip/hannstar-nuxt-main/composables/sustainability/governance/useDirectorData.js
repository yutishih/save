import { useI18n } from 'vue-i18n';

export const useDirectorData = () => {
    const { t } = useI18n();
    const directorData = [
        {
            "title": t('sustainability-governance-director-table-title01'),
            "name": t('sustainability-governance-director-table-name01'),
            "positions": t('sustainability-governance-director-table-detail01'),
        },
        {
            "title": t('sustainability-governance-director-table-title02'),
            "name": t('sustainability-governance-director-table-name02'),
            "positions": t('sustainability-governance-director-table-detail02'),
        },
        {
            "title": t('sustainability-governance-director-table-title03'),
            "name": t('sustainability-governance-director-table-name03'),
            "positions": t('sustainability-governance-director-table-detail03'),
        },
        {
            "title": t('sustainability-governance-director-table-title04'),
            "name": t('sustainability-governance-director-table-name04'),
            "positions": t('sustainability-governance-director-table-detail04'),
        },
        {
            "title": t('sustainability-governance-director-table-title05'),
            "name": t('sustainability-governance-director-table-name05'),
            "positions": t('sustainability-governance-director-table-detail05'),
        },
        {
            "title": t('sustainability-governance-director-table-title06'),
            "name": t('sustainability-governance-director-table-name06'),
            "positions": t('sustainability-governance-director-table-detail06'),
        },
        {
            "title": t('sustainability-governance-director-table-title07'),
            "name": t('sustainability-governance-director-table-name07'),
            "positions": t('sustainability-governance-director-table-detail07'),
        },
        {
            "title": t('sustainability-governance-director-table-title08'),
            "name": t('sustainability-governance-director-table-name08'),
            "positions": t('sustainability-governance-director-table-detail08'),
        },
    ]


    return {
        directorData,
    }
}