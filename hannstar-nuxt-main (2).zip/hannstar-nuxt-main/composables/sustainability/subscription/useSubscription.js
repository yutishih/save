//useSubscription.js
import { reactive, toRefs } from 'vue';
import axios from 'axios'

export const useSubscription = () => {
    const subscriptionState = reactive({
        isEmail: { data: [] },
        isLoading: false,
        error: null
    })

    const postSubscription = async (subscriptionBody, token) => {
        subscriptionState.isLoading = true
        const baseUrl = window.location.origin;
        try {
            // DEV API: https://magentodev.hannstar.com/index.php/rest/V1/ePaper
            // mock API: http://localhost:3001/index.php/rest/V1/ePaper
            // import.meta.env.VITE_ESG_SUBSCRIPTION_API_URL

            // const response = await axios.post("https://hannstar.com/index.php/rest/V1/ePaper", subscriptionBody, {
            const response = await axios.post(`${baseUrl}/api/ePaper`, subscriptionBody, {
                headers: {
                    "Authorization": `Bearer ${token}`,
                }
            })
            subscriptionState.isEmail = response.data
            console.log(subscriptionState.isEmail)
        } catch (error) {
            subscriptionState.error = error
            console.log(error.message)
        } finally {
            subscriptionState.isLoading = false
        }
    }

    return { ...toRefs(subscriptionState), postSubscription }
}