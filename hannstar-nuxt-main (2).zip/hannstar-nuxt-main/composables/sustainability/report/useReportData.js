import { useI18n } from 'vue-i18n';

export const useReport2022Data = () => {
    const { t } = useI18n();

    const report2022Data = [
        {
            "title": t('sustainability-report-table01-report01'),
            "downloadLink": t('sustainability-report-table01-link01'),
        },
        {
            "title": t('sustainability-report-table01-report02'),
            "downloadLink": t('sustainability-report-table01-link02'),
        },
        {
            "title": t('sustainability-report-table01-report03'),
            "downloadLink": t('sustainability-report-table01-link03'),
        },
        {
            "title": t('sustainability-report-table01-report04'),
            "downloadLink": t('sustainability-report-table01-link04'),
        },
        {
            "title": t('sustainability-report-table01-report05'),
            "downloadLink": t('sustainability-report-table01-link05'),
        },
        {
            "title": t('sustainability-report-table01-report06'),
            "downloadLink": t('sustainability-report-table01-link06'),
        },
        {
            "title": t('sustainability-report-table01-report07'),
            "downloadLink": t('sustainability-report-table01-link07'),
        },
    ]

    const reportHistoryData = [
        {
            "title": t('sustainability-report-table02-report01'),
            "downloadLink": t('sustainability-report-table02-link01'),
        },
        {
            "title": t('sustainability-report-table02-report02'),
            "downloadLink": t('sustainability-report-table02-link02'),
        },
        {
            "title": t('sustainability-report-table02-report03'),
            "downloadLink": t('sustainability-report-table02-link03'),
        },
        {
            "title": t('sustainability-report-table02-report04'),
            "downloadLink": t('sustainability-report-table02-link04'),
        },
        {
            "title": t('sustainability-report-table02-report05'),
            "downloadLink": t('sustainability-report-table02-link05'),
        },
        {
            "title": t('sustainability-report-table02-report06'),
            "downloadLink": t('sustainability-report-table02-link06'),
        },
        {
            "title": t('sustainability-report-table02-report07'),
            "downloadLink": t('sustainability-report-table02-link07'),
        },
        {
            "title": t('sustainability-report-table02-report08'),
            "downloadLink": t('sustainability-report-table02-link08'),
        },
        {
            "title": t('sustainability-report-table02-report09'),
            "downloadLink": t('sustainability-report-table02-link09'),
        },
        {
            "title": t('sustainability-report-table02-report10'),
            "downloadLink": t('sustainability-report-table02-link10'),
        },
        {
            "title": t('sustainability-report-table02-report11'),
            "downloadLink": t('sustainability-report-table02-link11'),
        },
        {
            "title": t('sustainability-report-table02-report12'),
            "downloadLink": t('sustainability-report-table02-link12'),
        },
        {
            "title": t('sustainability-report-table02-report13'),
            "downloadLink": t('sustainability-report-table02-link13'),
        },
    ]

    return {
        report2022Data,
        reportHistoryData
    }
}