//useNewsList.js
import { reactive, toRefs } from 'vue';
import axios from 'axios'

export const useNewsList = () => {
    const state = reactive({
        news: {}, //要確保news.data初始值不可以null
        isLoading: false,
        error: null
    });

    const fetchNews = async (tag = null, page = null, per_page = null) => {
        state.isLoading = true;
        state.error = null;

        const params = new URLSearchParams();

        // query參數是可選的，非必須
        if (tag) params.append('tag', tag);
        if (page) params.append('page', page);
        if (per_page) params.append('per_page', per_page);

        const baseUrl = window.location.origin;

        // NEW mock Api: http://localhost:3001/api/homepage_news
        // dev: https://magentodev.hannstar.com/rest/V1/getCMS
        // prd: https://www.hannstar.com/rest/V1/getCMS
        // console.log(import.meta.env.VITE_NEWS_API_URL);
        const url = `${baseUrl}/api/homepage_news?${params.toString()}`;
        // const url = "http://localhost:3001/api/homepage_news"

        try {
            const response = await axios.get(url);
            state.news = response.data;
            // console.log(state.news.data)
        } catch (error) {
            state.error = error;
            console.log(error.message)
        } finally {
            state.isLoading = false;
        }
    };

    return { ...toRefs(state), fetchNews };
}