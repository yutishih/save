//useSingleNews.js
import { reactive, toRefs } from 'vue';
import axios from 'axios'

export const useSingleNews = () => {
    const state = reactive({
        singleNews: {}, //singleNews.data初始值不可以null
        isLoading: false,
        error: null
    });

    const fetchSingleNews = async (postId) => {
        state.isLoading = true;
        state.error = null;

        const baseUrl = window.location.origin;

        // const url = `http://localhost:3001/api/homepage_news/${postId}`;
        const url = `${baseUrl}/api/homepage_news/${postId}`;

        // console.log(url)
        try {
            const response = await axios.get(url);
            state.singleNews = response.data;
            // console.log(state.singleNews)
        } catch (error) {
            state.error = error;
            console.log(error.message)
        } finally {
            state.isLoading = false;
        }
    };

    return { ...toRefs(state), fetchSingleNews };
}