import { useI18n } from 'vue-i18n';

export const useSitemap = () => {
    const { t } = useI18n();
    const data = [
        {
            "mainMenu": t('title-about'),
            "mainMenuLink": 'about',
            "subMenu": [
                { "text": t('hannstar-about'), "link": 'about', "targetBlank": false },
                { "text": t('hannstar-team'), "link": "about-team", "targetBlank": false },
                { "text": t('hannstar-related'), "link": "about-family", "targetBlank": false },
                { "text": t('hannstar-quality'), "link": "about-strategy", "targetBlank": false },
                { "text": t('hannstar-cert'), "link": "about-certification", "targetBlank": false },
                { "text": t('hannstar-global'), "link": "about-stronghold", "targetBlank": false },
            ]
        },
        {
            "mainMenu": t('product-title'),
            "mainMenuLink": "products-detail-automotive",
            "subMenu": [
                { "text": t('product-menu01'), "link": "products-detail-automotive", "targetBlank": false },
                { "text": t('product-menu02'), "link": "products-detail-industrial", "targetBlank": false },
                { "text": t('product-menu03'), "link": "products-detail-mobile", "targetBlank": false },
                { "text": t('product-menu04'), "link": "products-detail-wearable", "targetBlank": false },
                { "text": t('product-menu05'), "link": "products-detail-tablet", "targetBlank": false },
                { "text": t('product-menu06'), "link": "products-detail-touch", "targetBlank": false },
                { "text": t('product-menu07'), "link": "products-detail-monitor", "targetBlank": false },
                { "text": t('product-menu08'), "link": "products-detail-green-display", "targetBlank": false },
            ]
        },
        {
            "mainMenu": t('esg-title'),
            "mainMenuLink": "sustainability",
            "subMenu": [
                { "text": t('esg-menu01'), "link": "sustainability", "targetBlank": false },
                { "text": t('esg-menu02'), "link": "sustainability-corporation", "targetBlank": false },
                { "text": t('esg-menu03'), "link": "sustainability-governance", "targetBlank": false },
                { "text": t('esg-menu04'), "link": "sustainability-environment", "targetBlank": false },
                { "text": t('esg-menu05'), "link": "sustainability-social", "targetBlank": false },
                { "text": t('esg-menu06'), "link": "sustainability-report", "targetBlank": false },
                { "text": t('esg-menu07'), "link": "news-esg", "targetBlank": false },
            ]
        },
        {
            "mainMenu": t('investors-title'),
            "mainMenuLink": "investors-summary",
            "subMenu": [
                { "text": t('investors-menu01'), "link": "investors-summary", "targetBlank": false },
                { "text": t('investors-menu02'), "link": "investors-revenue", "targetBlank": false },
                { "text": t('investors-menu03'), "link": "investors-report", "targetBlank": false },
                { "text": t('investors-menu04'), "link": "investors-conference", "targetBlank": false },
                { "text": t('investors-menu05'), "link": "investors-shareholdermeeting", "targetBlank": false },
                { "text": t('investors-menu06'), "link": "investors-dividend", "targetBlank": false },
                { "text": t('investors-menu07'), "link": "https://tw.stock.yahoo.com/quote/6116", "targetBlank": true },
                { "text": t('investors-menu08'), "link": "investors-contacts", "targetBlank": false },
            ]
        },
        {
            "mainMenu": t('careers-title'),
            "mainMenuLink": "careers",
            "subMenu": [
                { "text": t('career-menu01'), "link": "careers-work", "targetBlank": false },
                { "text": t('career-menu02'), "link": "careers-growup", "targetBlank": false },
                { "text": t('career-menu03'), "link": "careers-join", "targetBlank": false },
            ]
        },
        {
            "mainMenu": t('news-title'),
            "mainMenuLink": "news-investors",
            "subMenu": [
                { "text": t('news-menu01'), "link": "news-investors", "targetBlank": false },
                { "text": t('news-menu02'), "link": "news-esg", "targetBlank": false },
                { "text": t('news-menu03'), "link": "news-campaign", "targetBlank": false },
            ]
        }
    ]

    return {
        data
    }
}