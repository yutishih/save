import { useI18n } from "vue-i18n"

export const useMilestone = () => {
    const { t } = useI18n();
    const mileStoneData = [
        {
            date: t("about-index-milestone-date1"),
            img: "",
            text: t("about-index-milestone-text1"),
        },
        {
            date: t("about-index-milestone-date2"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/November2021.jpg",
            text: t("about-index-milestone-text2"),
        },
        {
            date: t("about-index-milestone-date3"),
            img: "",
            text: t("about-index-milestone-text3"),
        },
        {
            date: t("about-index-milestone-date4"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/45001.jpg",
            text: t("about-index-milestone-text4"),
        },
        {
            date: t("about-index-milestone-date5"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/50001.jpg",
            text: t("about-index-milestone-text5"),
        },
        {
            date: t("about-index-milestone-date6"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/17025.jpg",
            text: t("about-index-milestone-text6"),
        },
        {
            date: t("about-index-milestone-date7"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/28000.jpg",
            text: t("about-index-milestone-text7"),
        },
        {
            date: t("about-index-milestone-date8"),
            img: "",
            text: t("about-index-milestone-text8"),
        },
        {
            date: t("about-index-milestone-date9"),
            img: "",
            text: t("about-index-milestone-text9"),
        },
        {
            date: t("about-index-milestone-date10"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/27001.jpg",
            text: t("about-index-milestone-text10"),
        },
        {
            date: t("about-index-milestone-date11"),
            img: "",
            text: t("about-index-milestone-text11"),
        },
        {
            date: t("about-index-milestone-date12"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/TWAEO.jpg",
            text: t("about-index-milestone-text12"),
        },
        {
            date: t("about-index-milestone-date13"),
            img: "",
            text: t("about-index-milestone-text13"),
        },
        {
            date: t("about-index-milestone-date14"),
            img: "",
            text: t("about-index-milestone-text14"),
        },
        {
            date: t("about-index-milestone-date15"),
            img: "",
            text: t("about-index-milestone-text15"),
        },
        {
            date: t("about-index-milestone-date16"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/office.jpg",
            text: t("about-index-milestone-text16"),
        },
        {
            date: t("about-index-milestone-date17"),
            img: "",
            text: t("about-index-milestone-text17"),
        },
        {
            date: t("about-index-milestone-date18"),
            img: "",
            text: t("about-index-milestone-text18"),
        },
        {
            date: t("about-index-milestone-date19"),
            img: "",
            text: t("about-index-milestone-text19"),
        },
        {
            date: t("about-index-milestone-date20"),
            img: "",
            text: t("about-index-milestone-text20"),
        },
        {
            date: t("about-index-milestone-date21"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/Sharp.jpg",
            text: t("about-index-milestone-text21"),
        },
        {
            date: t("about-index-milestone-date22"),
            img: "",
            text: t("about-index-milestone-text22"),
        },
        {
            date: t("about-index-milestone-date23"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/9001.jpg",
            text: t("about-index-milestone-text23"),
        },
        {
            date: t("about-index-milestone-date24"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/TainanLCD.jpg",
            text: t("about-index-milestone-text24"),
        },
        {
            date: t("about-index-milestone-date25"),
            img: "",
            text: t("about-index-milestone-text25"),
        },
        {
            date: t("about-index-milestone-date26"),
            img: "",
            text: t("about-index-milestone-text26"),
        },
        {
            date: t("about-index-milestone-date27"),
            img: "",
            text: t("about-index-milestone-text27"),
        },
        {
            date: t("about-index-milestone-date28"),
            img: "",
            text: t("about-index-milestone-text28"),
        },
        {
            date: t("about-index-milestone-date29"),
            img: "",
            text: t("about-index-milestone-text29"),
        },
        {
            date: t("about-index-milestone-date30"),
            img: "",
            text: t("about-index-milestone-text30"),
        },
        {
            date: t("about-index-milestone-date31"),
            img: "",
            text: t("about-index-milestone-text31"),
        },
        {
            date: t("about-index-milestone-date32"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/14001.jpg",
            text: t("about-index-milestone-text32"),
        },
        {
            date: t("about-index-milestone-date33"),
            img: "",
            text: t("about-index-milestone-text33"),
        },
        {
            date: t("about-index-milestone-date34"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/Toshiba.jpg",
            text: t("about-index-milestone-text34"),
        },
        {
            date: t("about-index-milestone-date35"),
            img: "https://media.hannstar.com/Image/hannstar/about/Profile/HannStarDisplay.png",
            text: t("about-index-milestone-text35"),
        }
    ]

    return {
        mileStoneData
    }
}