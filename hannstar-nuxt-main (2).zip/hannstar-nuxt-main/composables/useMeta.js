// useMeta.js
import { useI18n } from 'vue-i18n'

export function useMeta({ title, descriptionContent, ogTitleContent, ogDescriptionContent, ogImage, ogType }) {
    const { t } = useI18n();

    useHead({
        title: title ? `${title} - ${t("hannstar-full-name")}` : t("hannstar-full-name"),
        meta: [
            {
                name: "description",
                content: descriptionContent || t("hannstar-meta-property-name-content"),
            },
            {
                property: "og:title",
                content: ogTitleContent || t("hannstar-meta-property-ogtitle-content"),
            },
            {
                property: "og:description",
                content: ogDescriptionContent || t("hannstar-meta-property-ogdescription-content"),
            },
            { property: "og:image", content: ogImage || 'https://media.hannstar.com/Image/hannstar/ogcard.png' },
            { property: "og:type", content: ogType || 'website' },

        ],
        link: [{ rel: 'icon', type: 'image/png', href: 'https://www.hannstar.com/static/version1705884292/frontend/Smartwave/porto/zh_Hant_TW/Magento_Theme/favicon.ico' }]
    });
}
