//useRecaptcha.js
import { reactive, toRefs } from 'vue';
import axios from 'axios'

export const useRecaptcha = () => {
    const getTokenState = reactive({
        isData: null,
        isLoading: false,
        error: null
    })

    const tokenConfig = {
        "x-api-key": "i9H3IFYXWQ95zXDSsQj21148OFbGnS2r4j29Hb3T",
        "Content-Type": "application/json"
    }

    const getBearerToken = async (tokenBody) => {
        getTokenState.isLoading = true

        const baseUrl = window.location.origin;
        try {
            // mockAPI: http://localhost:3001/rest/V1/invite-member/token
            // import.meta.env.VITE_RECAPCHA_API_URL
            // const response = await axios.post("https://hannstar.com/rest/V1/invite-member/token", tokenBody, tokenConfig)
            const response = await axios.post(`${baseUrl}/api/token`, tokenBody, tokenConfig)
            getTokenState.isData = response.data
            // console.log(getTokenState.isData.data.token)
            return getTokenState.isData;
        } catch (error) {
            getTokenState.error = error
            console.log(error.message)
            return null
        } finally {
            getTokenState.isLoading = false
        }
    }

    return { ...toRefs(getTokenState), getBearerToken }
}