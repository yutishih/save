// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devtools: { enabled: true },
  app: {
    head: {
      charset: "utf-8",
      viewport: "width=device-width, initial-scale=1",
    },
    pageTransition: { name: "page", mode: "out-in" },
  },
  css: ["normalize.css/normalize.css", "~/assets/css/main.scss"],

  vite: {
    css: {
      preprocessorOptions: {
        scss: {
          additionalData: '@import "@/assets/css/global.scss";',
        },
      },
    },
  },
  imports: {
    dirs: [
      // Scan top-level modules
      "composables",
      // ... or scan modules nested one level deep with a specific name and file extension
      "composables/*/index.{ts,js,mjs,mts}",
      // ... or scan all modules within given directory
      "composables/**",
    ],
  },

  // generate: {
  //   fallback: true
  // },

  modules: ["@nuxtjs/i18n", "@nuxtjs/tailwindcss", "@nuxtjs/google-fonts"],
  components: [
    {
      path: "~/components",
      pathPrefix: false,
    },
  ],
  i18n: {
    customRoutes: "config",
    strategy: "prefix_and_default",
    locales: ["tw", "en", "cn"],
    defaultLocale: "tw",
    detectBrowserLanguage: false,
    vueI18n: "./nuxt-i18n.ts",
  },

  googleFonts: {
    families: {
      "Noto Sans TC": [400, 900],
      "Noto Sans SC": [400, 900],
      "Noto Sans": [400, 900],
    },
  },
});
