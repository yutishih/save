import SiteMap_tw from "./locales/tw/sitemap.json";
import Else_tw from "./locales/tw/else.json";
import Home_tw from "./locales/tw/home/main.json";
import AboutIndex_tw from "./locales/tw/about/index.json";
import AboutTeam_tw from "./locales/tw/about/team.json";
import AboutFamily_tw from "./locales/tw/about/family.json";
import AboutStrategy_tw from "./locales/tw/about/strategy.json";
import AboutCertification_tw from "./locales/tw/about/certification.json";
import AboutStronghold_tw from "./locales/tw/about/stronghold.json";
import ProductAutomotive_tw from "./locales/tw/product/automotive.json";
import ProductIndustrial_tw from "./locales/tw/product/industrial.json";
import ProductMobile_tw from "./locales/tw/product/mobile.json";
import ProductWearable_tw from "./locales/tw/product/wearable.json";
import ProductTablet_tw from "./locales/tw/product/tablet.json";
import ProductTouch_tw from "./locales/tw/product/touch.json";
import ProductMonitor_tw from "./locales/tw/product/monitor.json";
import ProductGreenDisplay_tw from "./locales/tw/product/greenDisplay.json";
import SustainabilityIndex_tw from "./locales/tw/sustainability/index.json";
import SustainabilityCorporation_tw from "./locales/tw/sustainability/corporation.json";
import SustainabilityGovernance_tw from "./locales/tw/sustainability/governance.json";
import SustainabilityEnvironment_tw from "./locales/tw/sustainability/environment.json";
import SustainabilitySocial_tw from "./locales/tw/sustainability/social.json";
import SustainabilityReport_tw from "./locales/tw/sustainability/report.json";
import InvestorsSummary_tw from "./locales/tw/investors/summary.json";
import InvestorsRevenue_tw from "./locales/tw/investors/revenue.json";
import InvestorsReport_tw from "./locales/tw/investors/report.json";
import InvestorsConference_tw from "./locales/tw/investors/conference.json";
import InvestorsShareholdermeeting_tw from "./locales/tw/investors/shareholdermeeting.json";
import InvestorsDividend_tw from "./locales/tw/investors/dividend.json";
import InvestorsContacts_tw from "./locales/tw/investors/contacts.json";
import CareersIndex_tw from "./locales/tw/careers/index.json";
import CareersWork_tw from "./locales/tw/careers/work.json";
import CareersGrowup_tw from "./locales/tw/careers/growup.json";
import CareersJoin_tw from "./locales/tw/careers/join.json";
import NewsInvestors_tw from "./locales/tw/news/investors.json";
import NewsEsg_tw from "./locales/tw/news/esg.json";
import NewsCampaign_tw from "./locales/tw/news/campaign.json";
import InformationContactUs_tw from "./locales/tw/information/contactUs.json";
import InformationLegalnotices_tw from "./locales/tw/information/legalnotices.json";
import InformationPrivacy_tw from "./locales/tw/information/privacy.json";
import ContactUsIndex_tw from "./locales/tw/contactUs/index.json";
import Search_tw from "./locales/tw/search.json";
import PageNotFound_tw from "./locales/tw/404.json";

import SiteMap_en from "./locales/en/sitemap.json";
import Else_en from "./locales/en/else.json";
import Home_en from "./locales/en/home/main.json";
import AboutIndex_en from "./locales/en/about/index.json";
import AboutTeam_en from "./locales/en/about/team.json";
import AboutFamily_en from "./locales/en/about/family.json";
import AboutStrategy_en from "./locales/en/about/strategy.json";
import AboutCertification_en from "./locales/en/about/certification.json";
import AboutStronghold_en from "./locales/en/about/stronghold.json";
import ProductAutomotive_en from "./locales/en/product/automotive.json";
import ProductIndustrial_en from "./locales/en/product/industrial.json";
import ProductMobile_en from "./locales/en/product/mobile.json";
import ProductWearable_en from "./locales/en/product/wearable.json";
import ProductTablet_en from "./locales/en/product/tablet.json";
import ProductTouch_en from "./locales/en/product/touch.json";
import ProductMonitor_en from "./locales/en/product/monitor.json";
import ProductGreenDisplay_en from "./locales/en/product/greenDisplay.json";
import SustainabilityIndex_en from "./locales/en/sustainability/index.json";
import SustainabilityCorporation_en from "./locales/en/sustainability/corporation.json";
import SustainabilityGovernance_en from "./locales/en/sustainability/governance.json";
import SustainabilityEnvironment_en from "./locales/en/sustainability/environment.json";
import SustainabilitySocial_en from "./locales/en/sustainability/social.json";
import SustainabilityReport_en from "./locales/en/sustainability/report.json";
import InvestorsSummary_en from "./locales/en/investors/summary.json";
import InvestorsRevenue_en from "./locales/en/investors/revenue.json";
import InvestorsReport_en from "./locales/en/investors/report.json";
import InvestorsConference_en from "./locales/en/investors/conference.json";
import InvestorsShareholdermeeting_en from "./locales/en/investors/shareholdermeeting.json";
import InvestorsDividend_en from "./locales/en/investors/dividend.json";
import InvestorsContacts_en from "./locales/en/investors/contacts.json";
import CareersIndex_en from "./locales/en/careers/index.json";
import CareersWork_en from "./locales/en/careers/work.json";
import CareersGrowup_en from "./locales/en/careers/growup.json";
import CareersJoin_en from "./locales/en/careers/join.json";
import NewsInvestors_en from "./locales/en/news/investors.json";
import NewsEsg_en from "./locales/en/news/esg.json";
import NewsCampaign_en from "./locales/en/news/campaign.json";
import InformationContactUs_en from "./locales/en/information/contactUs.json";
import InformationLegalnotices_en from "./locales/en/information/legalnotices.json";
import InformationPrivacy_en from "./locales/en/information/privacy.json";
import ContactUsIndex_en from "./locales/en/contactUs/index.json";
import Search_en from "./locales/en/search.json";
import PageNotFound_en from "./locales/en/404.json";

import SiteMap_cn from "./locales/cn/sitemap.json";
import Else_cn from "./locales/cn/else.json";
import Home_cn from "./locales/cn/home/main.json";
import AboutIndex_cn from "./locales/cn/about/index.json";
import AboutTeam_cn from "./locales/cn/about/team.json";
import AboutFamily_cn from "./locales/cn/about/family.json";
import AboutStrategy_cn from "./locales/cn/about/strategy.json";
import AboutCertification_cn from "./locales/cn/about/certification.json";
import AboutStronghold_cn from "./locales/cn/about/stronghold.json";
import ProductAutomotive_cn from "./locales/cn/product/automotive.json";
import ProductIndustrial_cn from "./locales/cn/product/industrial.json";
import ProductMobile_cn from "./locales/cn/product/mobile.json";
import ProductWearable_cn from "./locales/cn/product/wearable.json";
import ProductTablet_cn from "./locales/cn/product/tablet.json";
import ProductTouch_cn from "./locales/cn/product/touch.json";
import ProductMonitor_cn from "./locales/cn/product/monitor.json";
import ProductGreenDisplay_cn from "./locales/cn/product/greenDisplay.json";
import SustainabilityIndex_cn from "./locales/cn/sustainability/index.json";
import SustainabilityCorporation_cn from "./locales/cn/sustainability/corporation.json";
import SustainabilityGovernance_cn from "./locales/cn/sustainability/governance.json";
import SustainabilityEnvironment_cn from "./locales/cn/sustainability/environment.json";
import SustainabilitySocial_cn from "./locales/cn/sustainability/social.json";
import SustainabilityReport_cn from "./locales/cn/sustainability/report.json";
import InvestorsSummary_cn from "./locales/cn/investors/summary.json";
import InvestorsRevenue_cn from "./locales/cn/investors/revenue.json";
import InvestorsReport_cn from "./locales/cn/investors/report.json";
import InvestorsConference_cn from "./locales/cn/investors/conference.json";
import InvestorsShareholdermeeting_cn from "./locales/cn/investors/shareholdermeeting.json";
import InvestorsDividend_cn from "./locales/cn/investors/dividend.json";
import InvestorsContacts_cn from "./locales/cn/investors/contacts.json";
import CareersIndex_cn from "./locales/cn/careers/index.json";
import CareersWork_cn from "./locales/cn/careers/work.json";
import CareersGrowup_cn from "./locales/cn/careers/growup.json";
import CareersJoin_cn from "./locales/cn/careers/join.json";
import NewsInvestors_cn from "./locales/cn/news/investors.json";
import NewsEsg_cn from "./locales/cn/news/esg.json";
import NewsCampaign_cn from "./locales/cn/news/campaign.json";
import InformationContactUs_cn from "./locales/cn/information/contactUs.json";
import InformationLegalnotices_cn from "./locales/cn/information/legalnotices.json";
import InformationPrivacy_cn from "./locales/cn/information/privacy.json";
import ContactUsIndex_cn from "./locales/cn/contactUs/index.json";
import Search_cn from "./locales/cn/search.json";
import PageNotFound_cn from "./locales/cn/404.json";

export default defineI18nConfig(() => ({
  legacy: false,
  locale: "tw",
  fallbackLocale: "tw",
  messages: {
    tw: {
      ...SiteMap_tw,
      ...Else_tw,
      ...Home_tw,
      ...AboutIndex_tw,
      ...AboutTeam_tw,
      ...AboutFamily_tw,
      ...AboutStrategy_tw,
      ...AboutCertification_tw,
      ...AboutStronghold_tw,
      ...ProductAutomotive_tw,
      ...ProductIndustrial_tw,
      ...ProductMobile_tw,
      ...ProductWearable_tw,
      ...ProductTablet_tw,
      ...ProductTouch_tw,
      ...ProductMonitor_tw,
      ...ProductGreenDisplay_tw,
      ...SustainabilityIndex_tw,
      ...SustainabilityCorporation_tw,
      ...SustainabilityGovernance_tw,
      ...SustainabilityEnvironment_tw,
      ...SustainabilitySocial_tw,
      ...SustainabilityReport_tw,
      ...InvestorsSummary_tw,
      ...InvestorsRevenue_tw,
      ...InvestorsReport_tw,
      ...InvestorsConference_tw,
      ...InvestorsShareholdermeeting_tw,
      ...InvestorsDividend_tw,
      ...InvestorsContacts_tw,
      ...CareersIndex_tw,
      ...CareersWork_tw,
      ...CareersGrowup_tw,
      ...CareersJoin_tw,
      ...NewsInvestors_tw,
      ...NewsEsg_tw,
      ...NewsCampaign_tw,
      ...InformationContactUs_tw,
      ...InformationLegalnotices_tw,
      ...InformationPrivacy_tw,
      ...ContactUsIndex_tw,
      ...Search_tw,
      ...PageNotFound_tw,
    },

    en: {
      ...SiteMap_en,
      ...Else_en,
      ...Home_en,
      ...AboutIndex_en,
      ...AboutTeam_en,
      ...AboutFamily_en,
      ...AboutStrategy_en,
      ...AboutCertification_en,
      ...AboutStronghold_en,
      ...ProductAutomotive_en,
      ...ProductIndustrial_en,
      ...ProductMobile_en,
      ...ProductWearable_en,
      ...ProductTablet_en,
      ...ProductTouch_en,
      ...ProductMonitor_en,
      ...ProductGreenDisplay_en,
      ...SustainabilityIndex_en,
      ...SustainabilityCorporation_en,
      ...SustainabilityGovernance_en,
      ...SustainabilityEnvironment_en,
      ...SustainabilitySocial_en,
      ...SustainabilityReport_en,
      ...InvestorsSummary_en,
      ...InvestorsRevenue_en,
      ...InvestorsReport_en,
      ...InvestorsConference_en,
      ...InvestorsShareholdermeeting_en,
      ...InvestorsDividend_en,
      ...InvestorsContacts_en,
      ...CareersIndex_en,
      ...CareersWork_en,
      ...CareersGrowup_en,
      ...CareersJoin_en,
      ...NewsInvestors_en,
      ...NewsEsg_en,
      ...NewsCampaign_en,
      ...InformationContactUs_en,
      ...InformationLegalnotices_en,
      ...InformationPrivacy_en,
      ...ContactUsIndex_en,
      ...Search_en,
      ...PageNotFound_en,
    },

    cn: {
      ...SiteMap_cn,
      ...Else_cn,
      ...Home_cn,
      ...AboutIndex_cn,
      ...AboutTeam_cn,
      ...AboutFamily_cn,
      ...AboutStrategy_cn,
      ...AboutCertification_cn,
      ...AboutStronghold_cn,
      ...ProductAutomotive_cn,
      ...ProductIndustrial_cn,
      ...ProductMobile_cn,
      ...ProductWearable_cn,
      ...ProductTablet_cn,
      ...ProductTouch_cn,
      ...ProductMonitor_cn,
      ...ProductGreenDisplay_cn,
      ...SustainabilityIndex_cn,
      ...SustainabilityCorporation_cn,
      ...SustainabilityGovernance_cn,
      ...SustainabilityEnvironment_cn,
      ...SustainabilitySocial_cn,
      ...SustainabilityReport_cn,
      ...InvestorsSummary_cn,
      ...InvestorsRevenue_cn,
      ...InvestorsReport_cn,
      ...InvestorsConference_cn,
      ...InvestorsShareholdermeeting_cn,
      ...InvestorsDividend_cn,
      ...InvestorsContacts_cn,
      ...CareersIndex_cn,
      ...CareersWork_cn,
      ...CareersGrowup_cn,
      ...CareersJoin_cn,
      ...NewsInvestors_cn,
      ...NewsEsg_cn,
      ...NewsCampaign_cn,
      ...InformationContactUs_cn,
      ...InformationLegalnotices_cn,
      ...InformationPrivacy_cn,
      ...ContactUsIndex_cn,
      ...Search_cn,
      ...PageNotFound_cn,
    },
  },
}));
